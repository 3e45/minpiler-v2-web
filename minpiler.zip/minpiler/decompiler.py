"""
A partially implemented mostly broken decompiler.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass

from minpiler import m_parse, object_data

# https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/world/blocks/logic/LogicBlock.java#L72-L72
block_name_set: set[str] = set()
for block_name in object_data.block.split(','):
    if block_name.endswith('_large'):
        block_name = block_name[:-len('_large')]
    else:
        block_name = block_name.rstrip('0123456789')
    block_name_set.add(block_name.split('_')[-1])


def value(val: m_parse.Value):
    match val:
        case m_parse.Literal():
            if val.decopilation_hint is not None:
                return val.decopilation_hint
            return json.dumps(val.value)
        case m_parse.Name():
            if val.name.startswith('@'):
                name = val.name[1:].replace('-', '_')
                if name == 'null':
                    return 'None'
                if name in 'counter,time,unit,this,tick,mapw,maph,links,ipt,thisx,thisy'.split(','):
                    return f'M.at.const.{name}'
                if name in object_data.liquid.split(','):
                    return f'M.at.Liquid.{name}'
                if name in object_data.item.split(','):
                    return f'M.at.Item.{name}'
                if name in object_data.unit_type.split(','):
                    return f'M.at.UnitType.{name}'
                if name in object_data.block.split(','):
                    return f'M.at.Block.{name}'
                if name in object_data.l_access.split(','):
                    return f'M.at.LAccess.{name}'
                return f'M.at.any.{name}'
            elif val.name.rstrip('0123456789') in block_name_set:
                return f'L.{val.name}'
            return val.name
        case _:
            raise Exception(val)


def decompile_math(ins: m_parse.Call, a: list[str]):
    op_name = ins.op.split(' ')[1]
    op_symbol = {'add': '+', 'sub': '-', 'mul': '*', 'div': '/', 'idiv': '//', 'mod': '%', 'pow': '**'}.get(op_name)
    if op_symbol is not None:
        if a[0] == a[2] and op_symbol in ('+', '-', '*'):
            return f'{a[0]} {op_symbol}= {a[1]}'
        if a[0] == a[1]:
            return f'{a[0]} {op_symbol}= {a[2]}'
        return f'{a[0]} = {a[1]} {op_symbol} {a[2]}'

    for unary in ('not_', 'abs', 'log', 'log10', 'floor', 'ceil', 'sqrt', 'rand', 'sin', 'cos', 'tan', 'asin', 'acos', 'atan'):
        if op_name == unary.replace("_", ""):
            return f'{a[0]} = M.math.{unary}({a[1]})'

    for binary in ('add', 'sub', 'mul', 'div', 'idiv', 'mod', 'pow', 'equal', 'notEqual', 'land', 'lessThan', 'lessThanEq', 'greaterThan', 'greaterThanEq', 'strictEqual', 'shl', 'shr', 'or_', 'and_', 'xor', 'max', 'min', 'angle', 'len', 'noise'):
        if op_name == binary.replace("_", ""):
            return f'{a[0]} = M.math.{binary}({a[1]}, {a[2]})'

    raise ValueError(f'Unsupported operator {ins.op}')


@dataclass(frozen=True)
class Label:
    id: int


@dataclass(frozen=True)
class LabelJump:
    label: Label
    op: str  # condition
    args: list[m_parse.Value]


LabeledInstruction = m_parse.Call | Label | LabelJump


def insert_labels(instructions: list[m_parse.Instruction]) -> list[LabeledInstruction]:
    # List the targets of the gotos
    labels: dict[int, Label] = {}
    for ins in instructions:
        if isinstance(ins, m_parse.Jump) and ins.label not in labels:
            labels[ins.label] = Label(len(labels))

    # Replace the jumps and insert labels
    result: list[LabeledInstruction] = []
    for i, ins in enumerate(instructions):
        if i in labels:
            result.append(labels[i])
        if isinstance(ins, m_parse.Jump):
            result.append(LabelJump(labels[ins.label], ins.op, ins.args))
        else:
            result.append(ins)
    return result


@dataclass(frozen=True)
class Result:
    '''decompiler.Result'''
    main: str
    processors: dict[str, str]

    def __str__(self) -> str:
        if self.processors == {}:
            return self.main
        t = ''
        for k, v in self.processors.items():
            t += f'# Processor {json.dumps(k)}\n{v}\n'
        return t


def decompile(instructions: list[m_parse.Instruction]):
    labeled_instructions = insert_labels(instructions)

    # eliminate gotos
    for ins in labeled_instructions:
        if isinstance(ins, LabelJump):
            # We can convert
            # `[*A, LabelJump(label=Label(id=0), op='notEqual', args=[LocalName(name='a'), LocalName(name='b')]), *B, Label(id=0), *C]`
            # to
            # `[*A, If(op='equal', args=[LocalName(name='a'), LocalName(name='b')], body=B), *C]`
            # if
            # - all instructions in B is deeper than the LabelJump and Label(id=0), and
            # - the LabelJump and Label(id=0) has same depth.
            pass

    # translate to Python
    code: list[str] = []
    for ins in labeled_instructions:
        match ins:
            case m_parse.Call():
                a = list(map(value, ins.args))
                match ins.op:
                    case 'set':
                        code.append(f'{a[0]} = {a[1]}')
                    case 'print':
                        code.append(f'M.print({a[0]})')
                    case 'end':
                        code.append(f'M.end()')
                    case 'read':
                        code.append(f'{a[0]} = {a[1]}[{a[2]}]')
                    case 'write':
                        code.append(f'{a[1]}[{a[2]}] = {a[0]}')
                    case 'getlink':
                        code.append(f'{a[0]} = M.get_link({a[1]})')
                    case 'draw clear':
                        code.append(f'M.draw.clear({a[0]}, {a[1]}, {a[2]})')
                    case 'draw color':
                        code.append(f'M.draw.color({a[0]}, {a[1]}, {a[2]}, {a[3]})')
                    case 'draw stroke':
                        code.append(f'M.draw.stroke({a[0]})')
                    case 'draw line':
                        code.append(f'M.draw.line({a[0]}, {a[1]}, {a[2]}, {a[3]})')
                    case 'draw rect':
                        code.append(f'M.draw.rect({a[0]}, {a[1]}, {a[2]}, {a[3]})')
                    case 'draw lineRect':
                        code.append(f'M.draw.line_rect({a[0]}, {a[1]}, {a[2]}, {a[3]})')
                    case 'draw poly':
                        code.append(f'M.draw.poly({a[0]}, {a[1]}, {a[2]}, {a[3]}, {a[4]})')
                    case 'draw linePoly':
                        code.append(f'M.draw.line_poly({a[0]}, {a[1]}, {a[2]}, {a[3]}, {a[4]})')
                    case 'draw triangle':
                        code.append(f'M.draw.triangle({a[0]}, {a[1]}, {a[2]}, {a[3]}, {a[4]}, {a[5]})')
                    case 'draw image':
                        code.append(f'M.draw.image({a[0]}, {a[1]}, {a[2]}, {a[3]}, {a[4]})')
                    case 'ubind':
                        code.append(f'M.unit.bind({a[0]})')
                    case 'ucontrol stop':
                        code.append(f'M.unit.stop()')
                    case 'ucontrol move':
                        code.append(f'M.unit.move({a[0]}, {a[1]})')
                    case 'ucontrol approach':
                        code.append(f'M.unit.approach({a[0]}, {a[1]}, {a[2]})')
                    case 'ucontrol boost':
                        code.append(f'M.unit.boost({a[0]})')
                    case 'ucontrol pathfind':
                        code.append(f'M.unit.pathfind()')
                    case 'ucontrol target':
                        code.append(f'M.unit.target({a[0]}, {a[1]}, {a[2]})')
                    case 'ucontrol targetp':
                        code.append(f'M.unit.targetp({a[0]}, {a[1]})')
                    case 'ucontrol itemDrop':
                        code.append(f'M.unit.item_drop({a[0]}, {a[1]})')
                    case 'ucontrol itemTake':
                        code.append(f'M.unit.item_take({a[0]}, {a[1]}, {a[2]})')
                    case 'ucontrol pay_drop':
                        code.append(f'M.unit.payDrop()')
                    case 'ucontrol pay_take':
                        code.append(f'M.unit.payTake({a[0]})')
                    case 'ucontrol mine':
                        code.append(f'M.unit.mine({a[0]}, {a[1]})')
                    case 'ucontrol flag':
                        code.append(f'M.unit.set_flag({a[0]})')
                    case 'ucontrol build':
                        code.append(f'M.unit.build({a[0]}, {a[1]}, {a[2]}, {a[3]}, {a[4]})')
                    case 'ucontrol getBlock':
                        code.append(f'{a[2]}, {a[3]} = M.unit.get_block({a[0]}, {a[1]})')
                    case 'ucontrol within':
                        code.append(f'{a[3]} = M.unit.within({a[0]}, {a[1]}, {a[2]})')
                    case 'printflush':
                        code.append(f'M.print_flush({a[0]})')
                    case 'sensor':
                        if isinstance(ins.args[2], m_parse.Name) and ins.args[2].name.startswith('@'):
                            code.append(f'{a[0]} = {a[1]}.{ins.args[2].name[1:]}')
                        else:
                            code.append(f'{a[0]} = {a[1]}.sense({a[2]})')
                    case 'drawflush':
                        code.append(f'M.draw_flush({a[0]})')
                    case 'control enabled':
                        code.append(f'M.control.set_enabled({a[0]}, {a[1]})')
                    case 'control shoot':
                        code.append(f'M.control.shoot({a[0]}, {a[1]}, {a[2]}, {a[3]})')
                    case 'control shootp':
                        code.append(f'M.control.shootp({a[0]}, {a[1]}, {a[2]})')
                    case 'control configure':
                        code.append(f'M.control.configure({a[0]}, {a[1]})')
                    case _ if ins.op.startswith('op '):
                        code.append(decompile_math(ins, a))
                    case _ if ins.op.startswith('ulocate building '):
                        code.append(f'{a[4]}, {a[2]}, {a[3]}, {a[5]} = M.unit.locate.building(M.BlockFlag.{ins.op.split(" ")[2]}, {a[0]})')
                    case _ if ins.op.startswith('ulocate ore '):
                        code.append(f'{a[4]}, {a[2]}, {a[3]} = M.unit.locate.ore({ins.op.split(" ")[2]})')
                    case _ if ins.op.startswith('ulocate spawn '):
                        code.append(f'{a[4]}, {a[2]}, {a[3]} = M.unit.locate.spawn()')
                    case _ if ins.op.startswith('ulocate damaged '):
                        code.append(f'{a[4]}, {a[2]}, {a[3]}, {a[5]} = M.unit.locate.damaged()')
                    case _ if ins.op.startswith('uradar '):
                        code.append(f'{a[2]} = M.unit.radar(M.RadarTarget.{ins.op.split(" ")[1]}, M.RadarTarget.{ins.op.split(" ")[2]}, M.RadarTarget.{ins.op.split(" ")[3]}, M.RadarSort.{ins.op.split(" ")[4]}, {a[1]})')
                    case _ if ins.op.startswith('radar '):
                        code.append(f'{a[2]} = M.radar({a[0]}, M.RadarTarget.{ins.op.split(" ")[1]}, M.RadarTarget.{ins.op.split(" ")[2]}, M.RadarTarget.{ins.op.split(" ")[3]}, M.RadarSort.{ins.op.split(" ")[4]}, {a[1]})')
                    case _:
                        print(f'{ins} is not implemented', file=sys.stderr)
            case LabelJump():
                if ins.op == 'always':
                    code.append(f"M.jump .label{ins.label.id}")
                else:
                    a = list(map(value, ins.args))
                    op_symbol = {'notEqual': '!=', 'equal': '==', 'greaterThanEq': '>=', 'greaterThan': '>', 'lessThanEq': '<=', 'lessThan': '<', 'strictEqual': 'is'}[ins.op]
                    code.append(f"if {a[0]} {op_symbol} {a[1]}:\n    M.jump .label{ins.label.id}")
            case Label():
                code.append(f"M.label .label{ins.id}")
            case _:
                raise Exception(ins)

    return Result('from minpiler.std import M, L\n\n' + '\n'.join(code), {})
