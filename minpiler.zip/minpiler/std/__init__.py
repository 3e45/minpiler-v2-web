# minpiler.nobuiltins
from __future__ import annotations

import enum as _enum
import typing as _typing

from minpiler.std import _typeshed_generated

# minpiler.typedef _T
_T = _typing.TypeVar('_T')


def _builtin(marker: str):
    def _builtin_inner(f: _T) -> _T:
        return f
    return _builtin_inner


@_builtin('ignore')
def _overwrite(cls: _T) -> _typing.Callable[[_typing.Any], _T]:
    def _overwrite_inner(cls: _typing.Any) -> _T:
        return cls

    return _overwrite_inner


@_builtin('ignore')
@_overwrite(_typeshed_generated._AnyMObject)
class MObject:
    pass


# minpiler.typedef ConstExpr
ConstExpr = _typing.Annotated[_T, "ConstExpr"]


@_builtin('inline')
def inline(f: _T) -> _T:
    return f


@_builtin('macro')
def macro(relative_path: str, function_name: str):
    def macro_(f: _T) -> _T:
        return f
    return macro_


@_builtin('syntactic_macro')
def syntactic_macro(relative_path: str, function_name: str):
    def syntactic_macro_(f: _T) -> _T:
        return f
    return syntactic_macro_


@_builtin('ignore')
def dst(index: int, prefix: str | None = None):
    """Creates a temporary variable for a return value."""
    pass


@_builtin('ignore')
def _instantiate(f: _typing.Type[_T]) -> _T:
    return f()


@_builtin('ignore')
class Const:
    pass


@syntactic_macro('_syntactic_macro', 'static_malloc')
def static_malloc(size: ConstExpr[int]) -> tuple[MObject, int]:
    """
    Allocates memory addresses at compile time. The return values don't change when it is called multiple times at runtime.
    """
    raise NotImplementedError


@inline
def static_calloc(size: ConstExpr[int]) -> tuple[MObject, int]:
    mem, addr = static_malloc(size)
    for i in range(addr, addr + size):
        mem[i] = 0
    return mem, addr


# minpiler.typedef _P
_P = _typing.ParamSpec("_P")


class Processors:
    @_builtin('Processors.add')
    @syntactic_macro('_syntactic_macro', 'Processors_add')
    @staticmethod
    def add(f: _typing.Callable[_P, None], *args: ConstExpr[_P.args], **kwargs__ignore: ConstExpr[_P.kwargs]) -> None:
        raise NotImplementedError

    @_builtin('Processors.parameterized')
    @staticmethod
    def parameterized(f: _typing.Callable[_P, None]) -> _typing.Callable[_P, None]:
        raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'use_value')
def use_float() -> float:
    raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'use_value')
def use_int() -> int:
    raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'use_value')
def use_object() -> MObject:
    raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'use_value')
def use_laccess() -> _typeshed_generated.LAccess:
    raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'memory_of')
def memory_of(shared_name: _typing.Any) -> MObject:
    raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'address_of')
def address_of(shared_name: _typing.Any) -> int:
    raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'asm')
def asm(op: str, *args: _typing.Any) -> _typing.Any:
    raise NotImplementedError


@syntactic_macro('_syntactic_macro', 'ident')
def ident(f_string: str) -> _typing.Any:
    raise NotImplementedError


@_builtin('ignore')
def unrolled(iter: _typing.Sequence[_T] | _typing.Iterator[_T]) -> _typing.Iterator[_T]:
    raise NotImplementedError


@_builtin('L')
@_instantiate
class L:
    """Links"""

    def __getattr__(self, _name: str) -> MObject:
        raise NotImplementedError


class emulator:
    """
    Commands that work only on the emulator. In a normal build, those commands will be removed.
    """

    @inline
    @staticmethod
    def kill() -> _typing.NoReturn:  # type: ignore
        asm('emulator.kill')


class M:
    @syntactic_macro('_syntactic_macro', 'M_print')
    @staticmethod
    def print(*args: _typing.Any) -> None:
        pass

    @inline
    @staticmethod
    def end() -> _typing.NoReturn:  # type: ignore
        asm('end')

    @inline
    @staticmethod
    def get_link(index: int) -> MObject:
        return asm('getlink', dst(0, 'get_link'), index)

    @inline
    @staticmethod
    def draw_flush(obj: MObject) -> None:
        asm('drawflush', obj)

    @inline
    @staticmethod
    def print_flush(obj: MObject) -> None:
        """
        Example
        ```
        from minpiler.std import M, L

        M.print("hello")
        M.print_flush(L.message1)
        ```
        """
        asm('printflush', obj)

    @inline
    @staticmethod
    def radar(obj: MObject, target1: _typeshed_generated.RadarTarget, target2: _typeshed_generated.RadarTarget, target3: _typeshed_generated.RadarTarget, sort_type: _typeshed_generated.RadarSort, sort_dir: int) -> MObject | None:
        return asm(f'radar {target1} {target2} {target3} {sort_type}', obj, sort_dir, dst(0, 'radar'))

    @inline
    @staticmethod
    def sense(obj: MObject, laccess: _typeshed_generated.LAccess | _typing.Any) -> None:
        return asm(f'sensor', dst(0, 'sensor'), obj, laccess)

    @inline
    @staticmethod
    def wait(sec: float) -> None:
        """@since v7"""
        return asm('wait', sec)

    class lookup:
        @inline
        @staticmethod
        def block(index: int) -> MObject:
            """@since v7"""
            return asm('lookup block', dst(0, 'lookup'), index)

        @inline
        @staticmethod
        def unit(index: int) -> MObject:
            """@since v7"""
            return asm('lookup unit', dst(0, 'lookup'), index)

        @inline
        @staticmethod
        def item(index: int) -> MObject:
            """@since v7"""
            return asm('lookup item', dst(0, 'lookup'), index)

        @inline
        @staticmethod
        def liquid(index: int) -> MObject:
            """@since v7"""
            return asm('lookup liquid', dst(0, 'lookup'), index)

    @inline
    @staticmethod
    def pack_color(r: float, g: float, b: float, a: float) -> int:
        """@since v7"""
        return asm('packcolor', dst(0, 'color'), r, g, b, a)

    class control:
        @inline
        @staticmethod
        def set_enabled(obj: MObject, is_enabled: bool | float) -> None:
            asm('control enabled', obj, is_enabled)

        @inline
        @staticmethod
        def shoot(obj: MObject, x: float, y: float, shoot: bool | float) -> None:
            asm('control shoot', obj, x, y, shoot)

        @inline
        @staticmethod
        def shootp(obj: MObject, target: _typeshed_generated.UnknownMObject, shoot: bool | float) -> None:
            asm('control shootp', obj, target, shoot)

        @inline
        @staticmethod
        def configure(obj: MObject, value: _typeshed_generated.UnknownMObject) -> None:
            asm('control configure', obj, value)

    class math:
        @inline
        @staticmethod
        def add(a: float, b: float) -> float:
            return asm('op add', dst(0, 'add'), a, b)

        @inline
        @staticmethod
        def sub(a: float, b: float) -> float:
            return asm('op sub', dst(0, 'sub'), a, b)

        @inline
        @staticmethod
        def mul(a: float, b: float) -> float:
            return asm('op mul', dst(0, 'mul'), a, b)

        @inline
        @staticmethod
        def div(a: float, b: float) -> float:
            return asm('op div', dst(0, 'div'), a, b)

        @inline
        @staticmethod
        def idiv(a: float, b: float) -> float:
            return asm('op idiv', dst(0, 'idiv'), a, b)

        @inline
        @staticmethod
        def mod(a: float, b: float) -> float:
            return asm('op mod', dst(0, 'mod'), a, b)

        @inline
        @staticmethod
        def pow(a: float, b: float) -> float:
            return asm('op pow', dst(0, 'pow'), a, b)

        @inline
        @staticmethod
        def equal(a: float, b: float) -> float:
            return asm('op equal', dst(0, 'equal'), a, b)

        @inline
        @staticmethod
        def not_equal(a: float, b: float) -> float:
            return asm('op notEqual', dst(0, 'notEqual'), a, b)

        @inline
        @staticmethod
        def land(a: float, b: float) -> float:
            return asm('op land', dst(0, 'land'), a, b)

        @inline
        @staticmethod
        def less_than(a: float, b: float) -> float:
            return asm('op lessThan', dst(0, 'lessThan'), a, b)

        @inline
        @staticmethod
        def less_than_eq(a: float, b: float) -> float:
            return asm('op lessThanEq', dst(0, 'lessThanEq'), a, b)

        @inline
        @staticmethod
        def greater_than(a: float, b: float) -> float:
            return asm('op greaterThan', dst(0, 'greaterThan'), a, b)

        @inline
        @staticmethod
        def greater_than_eq(a: float, b: float) -> float:
            return asm('op greaterThanEq', dst(0, 'greaterThanEq'), a, b)

        @inline
        @staticmethod
        def strict_equal(a: float, b: float) -> float:
            return asm('op strictEqual', dst(0, 'strictEqual'), a, b)

        @inline
        @staticmethod
        def shl(a: float, b: float) -> float:
            return asm('op shl', dst(0, 'shl'), a, b)

        @inline
        @staticmethod
        def shr(a: float, b: float) -> float:
            return asm('op shr', dst(0, 'shr'), a, b)

        @inline
        @staticmethod
        def or_(a: float, b: float) -> float:
            return asm('op or', dst(0, 'or'), a, b)

        @inline
        @staticmethod
        def and_(a: float, b: float) -> float:
            return asm('op and', dst(0, 'and'), a, b)

        @inline
        @staticmethod
        def xor(a: float, b: float) -> float:
            return asm('op xor', dst(0, 'xor'), a, b)

        @inline
        @staticmethod
        def max(a: float, b: float) -> float:
            return asm('op max', dst(0, 'max'), a, b)

        @inline
        @staticmethod
        def min(a: float, b: float) -> float:
            return asm('op min', dst(0, 'min'), a, b)

        @inline
        @staticmethod
        def angle(a: float, b: float) -> float:
            return asm('op angle', dst(0, 'angle'), a, b)

        @inline
        @staticmethod
        def len(a: float, b: float) -> float:
            return asm('op len', dst(0, 'len'), a, b)

        @inline
        @staticmethod
        def noise(a: float, b: float) -> float:
            return asm('op noise', dst(0, 'noise'), a, b)

        @inline
        @staticmethod
        def flip(a: float) -> float:
            return asm('op not', dst(0, 'not'), a)

        @inline
        @staticmethod
        def abs(a: float) -> float:
            return asm('op abs', dst(0, 'abs'), a)

        @inline
        @staticmethod
        def log(a: float) -> float:
            return asm('op log', dst(0, 'log'), a)

        @inline
        @staticmethod
        def log10(a: float) -> float:
            return asm('op log10', dst(0, 'log10'), a)

        @inline
        @staticmethod
        def floor(a: float) -> int:
            return asm('op floor', dst(0, 'floor'), a)

        @inline
        @staticmethod
        def ceil(a: float) -> int:
            return asm('op ceil', dst(0, 'ceil'), a)

        @inline
        @staticmethod
        def sqrt(a: float) -> float:
            return asm('op sqrt', dst(0, 'sqrt'), a)

        @inline
        @staticmethod
        def rand(a: float) -> float:
            return asm('op rand', dst(0, 'rand'), a)

        @inline
        @staticmethod
        def sin(a: float) -> float:
            return asm('op sin', dst(0, 'sin'), a)

        @inline
        @staticmethod
        def cos(a: float) -> float:
            return asm('op cos', dst(0, 'cos'), a)

        @inline
        @staticmethod
        def tan(a: float) -> float:
            return asm('op tan', dst(0, 'tan'), a)

        @inline
        @staticmethod
        def asin(a: float) -> float:
            return asm('op asin', dst(0, 'asin'), a)

        @inline
        @staticmethod
        def acos(a: float) -> float:
            return asm('op acos', dst(0, 'acos'), a)

        @inline
        @staticmethod
        def atan(a: float) -> float:
            return asm('op atan', dst(0, 'atan'), a)

    class draw:
        @inline
        @staticmethod
        def clear(r: float, g: float, b: float) -> None:
            return asm('draw clear', r, g, b)

        @inline
        @staticmethod
        def color(r: float, g: float, b: float, a: float) -> None:
            return asm('draw color', r, g, b, a)

        @inline
        @staticmethod
        def col(color: int) -> None:
            """@since v7"""
            return asm('draw col', color, 0, 0, 0, 0, 0)

        @inline
        @staticmethod
        def stroke(width: float) -> None:
            return asm('draw stroke', width)

        @inline
        @staticmethod
        def line(x: float, y: float, x2: float, y2: float) -> None:
            return asm('draw line', x, y, x2, y2)

        @inline
        @staticmethod
        def rect(x: float, y: float, width: float, height: float) -> None:
            return asm('draw rect', x, y, width, height)

        @inline
        @staticmethod
        def line_rect(x: float, y: float, width: float, height: float) -> None:
            return asm('draw lineRect', x, y, width, height)

        @inline
        @staticmethod
        def poly(x: float, y: float, sides: float, radius: float, rotation: float) -> None:
            return asm('draw poly', x, y, sides, radius, rotation)

        @inline
        @staticmethod
        def line_poly(x: float, y: float, sides: float, radius: float, rotation: float) -> None:
            return asm('draw linePoly', x, y, sides, radius, rotation)

        @inline
        @staticmethod
        def triangle(x: float, y: float, x2: float, y2: float, x3: float, y3: float) -> None:
            return asm('draw triangle', x, y, x2, y2, x3, y3)

        @inline
        @staticmethod
        def image(x: float, y: float, image: _typing.Any, size: float, rotation: float) -> None:
            return asm('draw image', x, y, image, size, rotation)

    class unit:
        @inline
        @staticmethod
        def bind(utype: M.at.UnitType | MObject | None) -> None:
            return asm('ubind', utype)

        @inline
        @staticmethod
        def radar(target1: 'M.RadarTarget', target2: M.RadarTarget, target3: 'M.RadarTarget', sort_type: 'M.RadarSort', sort_dir: int) -> MObject | None:
            return asm(f'uradar {target1} {target2} {target3} {sort_type}', L.turret1, sort_dir, dst(0, 'uradar'))

        @inline
        @staticmethod
        def idle() -> None:
            return asm('ucontrol idle', 0, 0, 0, 0, 0)

        @inline
        @staticmethod
        def stop() -> None:
            return asm('ucontrol stop', 0, 0, 0, 0, 0)

        @inline
        @staticmethod
        def move(x: float, y: float) -> None:
            return asm('ucontrol move', x, y, 0, 0, 0)

        @inline
        @staticmethod
        def approach(x: float, y: float, radius: float) -> None:
            return asm('ucontrol approach', x, y, radius, 0, 0)

        @inline
        @staticmethod
        def boost(value: float) -> None:
            return asm('ucontrol boost', value, 0, 0, 0, 0)

        @inline
        @staticmethod
        def pathfind() -> None:
            return asm('ucontrol pathfind', 0, 0, 0, 0, 0)

        @inline
        @staticmethod
        def target(x: float, y: float, shoot: bool | float) -> None:
            return asm('ucontrol target', x, y, shoot, 0, 0)

        @inline
        @staticmethod
        def targetp(unit: _typeshed_generated.UnknownMObject, shoot: bool | float) -> None:
            return asm('ucontrol targetp', unit, shoot, 0, 0, 0)

        @inline
        @staticmethod
        def item_drop(target: _typeshed_generated.UnknownMObject, amount: float) -> None:
            return asm('ucontrol itemDrop', target, amount, 0, 0, 0)

        @inline
        @staticmethod
        def item_take(target: _typeshed_generated.UnknownMObject, material: 'M.at.Item', amount: float) -> None:
            return asm('ucontrol itemTake', target, material, amount, 0, 0)

        @inline
        @staticmethod
        def pay_drop() -> None:
            return asm('ucontrol payDrop', 0, 0, 0, 0, 0)

        @inline
        @staticmethod
        def pay_take(amount: float) -> None:
            return asm('ucontrol payTake', amount, 0, 0, 0, 0)

        @inline
        @staticmethod
        def mine(x: float, y: float) -> None:
            return asm('ucontrol mine', x, y, 0, 0, 0)

        @inline
        @staticmethod
        def set_flag(value: float) -> None:
            return asm('ucontrol flag', value, 0, 0, 0, 0)

        @inline
        @staticmethod
        def build(x: float, y: float, block: 'M.at.Block', rotation: float, config: _typeshed_generated.UnknownMObject | None) -> None:
            return asm('ucontrol build', x, y, block, rotation, config)

        @inline
        @staticmethod
        def get_block(x: float, y: float) -> tuple['M.at.Block', MObject]:
            """Returns (block_type, building)"""
            return asm('ucontrol getBlock', x, y, dst(0, 'btype'), dst(1, 'building'), 0)

        @inline
        @staticmethod
        def within(x: float, y: float, radius: float) -> float:
            return asm('ucontrol within', x, y, radius, dst(0, 'within'), 0)

        class locate:
            @inline
            @staticmethod
            def building(block_flag: 'M.BlockFlag', enemy: bool) -> tuple[bool, float, float, MObject]:
                """Returns (found, x, y, building)"""
                return asm(f'ulocate building {block_flag}', enemy, M.at.any.copper, dst(1, 'x'), dst(2, 'y'), dst(0, 'found'), dst(3, 'building'))

            @inline
            @staticmethod
            def ore(material: 'M.at.Item') -> tuple[bool, float, float]:
                """Returns (found, x, y)"""
                return asm('ulocate ore core', True, material, dst(1, 'x'), dst(2, 'y'), dst(0, 'found'), None)

            @inline
            @staticmethod
            def spawn() -> tuple[bool, float, float, MObject]:
                """Returns (found, x, y)"""
                return asm('ulocate spawn core', True, M.at.any.copper, dst(1, 'x'), dst(2, 'y'), dst(0, 'found'), dst(3, 'building'))

            @inline
            @staticmethod
            def damaged() -> tuple[bool, float, float, MObject]:
                """Returns (found, x, y, building)"""
                return asm('ulocate damaged core', True, M.at.any.copper, dst(1, 'x'), dst(2, 'y'), dst(0, 'found'), dst(3, 'building'))

    class world:
        """@since v7"""
        class get_block:
            @inline
            @staticmethod
            def floor(x: float, y: float) -> M.at.Block:
                return asm('getblock floor', dst(0, 'getblock'), x, y)

            @inline
            @staticmethod
            def ore(x: float, y: float) -> M.at.Item:
                return asm('getblock ore', dst(0, 'getblock'), x, y)

            @inline
            @staticmethod
            def block(x: float, y: float) -> M.at.Block:
                return asm('getblock block', dst(0, 'getblock'), x, y)

            @inline
            @staticmethod
            def building(x: float, y: float) -> MObject:
                return asm('getblock building', dst(0, 'getblock'), x, y)

        class set_block:
            @inline
            @staticmethod
            def floor(x: float, y: float, block: M.at.Block) -> None:
                return asm('setblock floor', block, x, y, 0, 0)

            @inline
            @staticmethod
            def ore(x: float, y: float, block: M.at.Block) -> None:
                return asm('setblock ore', block, x, y)

            @inline
            @staticmethod
            def block(x: float, y: float, block: M.at.Block, team: M.at.Team, rotation: float) -> None:
                return asm('setblock block', block, x, y, team, rotation)

        @inline
        @staticmethod
        def spawn(unit: M.at.UnitType, x: float, y: float, team: M.at.Team, rotation: float) -> None:
            return asm('spawn', unit, x, y, team, rotation)

        @inline
        @staticmethod
        def apply_status(unit: MObject, status: M.at.StatusEffect, sec: float) -> None:
            return asm('status false', status, unit, sec)

        @inline
        @staticmethod
        def clear_status(unit: MObject, status: M.at.StatusEffect) -> None:
            return asm('status true', status, unit, 0)

        @inline
        @staticmethod
        def spawn_wave(x: float, y: float) -> None:
            return asm('spawnwave', x, y)

        class set_rule:
            @inline
            @staticmethod
            def current_wave_time(value: float) -> None:
                return asm('setrule currentWaveTime', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def wave_timer(value: float) -> None:
                return asm('setrule waveTimer', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def waves(value: float) -> None:
                return asm('setrule waves', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def wave(value: float) -> None:
                return asm('setrule wave', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def wave_spacing(value: float) -> None:
                return asm('setrule waveSpacing', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def attack_mode(value: float) -> None:
                return asm('setrule attackMode', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def enemy_core_build_radius(value: float) -> None:
                return asm('setrule enemyCoreBuildRadius', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def drop_zone_radius(value: float) -> None:
                return asm('setrule dropZoneRadius', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def unit_cap(value: float) -> None:
                return asm('setrule unitCap', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def map_area(x: float, y: float, w: float, h: float) -> None:
                return asm('setrule mapArea', 0, x, y, w, h)

            @inline
            @staticmethod
            def lighting(value: float) -> None:
                return asm('setrule lighting', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def ambient_light(value: float) -> None:
                return asm('setrule ambientLight', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def solar_multiplier(value: float) -> None:
                return asm('setrule solarMultiplier', value, 0, 0, 0, 0)

            @inline
            @staticmethod
            def build_speed(team: M.at.Team, value: float) -> None:
                return asm('setrule buildSpeed', value, team, 0, 0, 0)

            @inline
            @staticmethod
            def unit_build_speed(team: M.at.Team, value: float) -> None:
                return asm('setrule unitBuildSpeed', value, team, 0, 0, 0)

            @inline
            @staticmethod
            def unit_damage(team: M.at.Team, value: float) -> None:
                return asm('setrule unitDamage', value, team, 0, 0, 0)

            @inline
            @staticmethod
            def block_health(team: M.at.Team, value: float) -> None:
                return asm('setrule blockHealth', value, team, 0, 0, 0)

            @inline
            @staticmethod
            def block_damage(team: M.at.Team, value: float) -> None:
                return asm('setrule blockDamage', value, team, 0, 0, 0)

            @inline
            @staticmethod
            def rts_min_weight(team: M.at.Team, value: float) -> None:
                return asm('setrule rtsMinWeight', value, team, 0, 0, 0)

            @inline
            @staticmethod
            def rts_min_squad(team: M.at.Team, value: float) -> None:
                return asm('setrule rtsMinSquad', value, team, 0, 0, 0)

        class flush_message:
            @inline
            @staticmethod
            def notify() -> None:
                return asm('message notify')

            @inline
            @staticmethod
            def announce(sec: float) -> None:
                return asm('message announce', sec)

            @inline
            @staticmethod
            def toast(sec: float) -> None:
                return asm('message toast', sec)

            @inline
            @staticmethod
            def mission() -> None:
                return asm('message mission')

        class cutscene:
            @inline
            @staticmethod
            def pan(x: float, y: float, speed: float) -> None:
                return asm('cutscene pan', x, y, speed, 0)

            @inline
            @staticmethod
            def zoom(level: float) -> None:
                return asm('cutscene zoom', level, 0, 0, 0)

            @inline
            @staticmethod
            def stop() -> None:
                return asm('cutscene stop', 0, 0, 0, 0)

        @inline
        @staticmethod
        def explosion(team: M.at.Team, x: float, y: float, radius: float, damage: float, air: bool, ground: bool, pierce: bool) -> None:
            return asm('explosion', team, x, y, radius, damage, air, ground, pierce)

        @inline
        @staticmethod
        def set_rate(ipt: float) -> None:
            return asm('setrate', ipt)

        class fetch:
            @inline
            @staticmethod
            def unit(team: M.at.Team, index: int) -> MObject:
                return asm('fetch unit', dst(0, 'fetch'), team, index, 0)

            @inline
            @staticmethod
            def unitCount(team: M.at.Team) -> int:
                return asm('fetch unitCount', dst(0, 'fetch'), team, 0, 0)

            @inline
            @staticmethod
            def player(team: M.at.Team, index: int) -> MObject:
                return asm('fetch player', dst(0, 'fetch'), team, index, 0)

            @inline
            @staticmethod
            def playerCount(team: M.at.Team) -> int:
                return asm('fetch playerCount', dst(0, 'fetch'), team, 0, 0)

            @inline
            @staticmethod
            def core(team: M.at.Team, index: int) -> MObject:
                return asm('fetch core', dst(0, 'fetch'), team, index, 0)

            @inline
            @staticmethod
            def coreCount(team: M.at.Team) -> int:
                return asm('fetch coreCount', dst(0, 'fetch'), team, 0, 0)

            @inline
            @staticmethod
            def build(team: M.at.Team, index: int, block: M.at.Block) -> MObject:
                return asm('fetch build', dst(0, 'fetch'), team, index, block)

            @inline
            @staticmethod
            def buildCount(team: M.at.Team, block: M.at.Block) -> int:
                return asm('fetch buildCount', dst(0, 'fetch'), team, 0, block)

        @inline
        @staticmethod
        def get_flag(name: str) -> None:
            return asm('getflag', name)

        @inline
        @staticmethod
        def set_flag(name: str, value: bool) -> None:
            return asm('setflag', name, value)

    class at:
        @_builtin('at')
        @_overwrite(_typeshed_generated.Item)
        class Item(_enum.Enum):
            pass

        @_builtin('at')
        @_overwrite(_typeshed_generated.Liquid)
        class Liquid(_enum.Enum):
            pass

        @_builtin('at')
        @_overwrite(_typeshed_generated.LAccess)
        class LAccess(_enum.Enum):
            pass

        @_builtin('at')
        @_overwrite(_typeshed_generated.UnitType)
        class UnitType(_enum.Enum):
            pass

        @_builtin('at')
        @_overwrite(_typeshed_generated.Block)
        class Block(_enum.Enum):
            pass

        @_builtin('at')
        @_overwrite(_typeshed_generated.Team)
        class Team(_enum.Enum):
            pass

        @_builtin('at')
        @_overwrite(_typeshed_generated.StatusEffect)
        class StatusEffect(_enum.Enum):
            pass

        @_builtin('at')
        class const:
            # https://github.com/Anuken/Mindustry/blob/2f7c5994a78eba4d9d06df1158da6442c40d92fa/core/src/mindustry/logic/LAssembler.java#L24-L24
            counter: int  # instruction counter
            time: int  # unix timestamp
            unit: _typeshed_generated._AnyMObject  # currently controlled unit
            this: _typeshed_generated._AnyMObject  # reference to self
            tick: float  # global tick

            # https://github.com/Anuken/Mindustry/blob/2f7c5994a78eba4d9d06df1158da6442c40d92fa/core/src/mindustry/world/blocks/logic/LogicBlock.java#L315-L315
            mapw: int
            maph: int
            links: int  # the number of links
            ipt: int  # instructions per tick

            # https://github.com/Anuken/Mindustry/blob/2f7c5994a78eba4d9d06df1158da6442c40d92fa/core/src/mindustry/world/blocks/logic/LogicBlock.java#L338-L338
            thisx: float
            thisy: float

            # TODO: https://github.com/Anuken/Mindustry/blob/2f7c5994a78eba4d9d06df1158da6442c40d92fa/core/src/mindustry/logic/GlobalConstants.java#L28-L28

        @_builtin('at')
        @_instantiate
        class any(_typing.Generic[_T]):
            def __getattr__(self, name: str) -> _T:
                raise NotImplementedError

    @_builtin('enum')
    @_overwrite(_typeshed_generated.RadarTarget)
    class RadarTarget(_enum.Enum):
        pass

    @_builtin('enum')
    @_overwrite(_typeshed_generated.RadarSort)
    class RadarSort(_enum.Enum):
        pass

    @_builtin('enum')
    @_overwrite(_typeshed_generated.BlockFlag)
    class BlockFlag(_enum.Enum):
        pass

    @_builtin('jump')
    @_instantiate
    class jump(_typing.Generic[_T]):
        def __getattr__(self, name: str) -> _T:
            raise NotImplementedError

    @_builtin('label')
    @_instantiate
    class label(_typing.Generic[_T]):
        def __getattr__(self, name: str) -> _T:
            raise NotImplementedError
