import ast

import minpiler.compiler_helper as helper
from minpiler import compiler, m_ast
from minpiler.m_ast import BuildContext, LogicError, Object


def M_print(*args: ast.expr, ctx: BuildContext) -> Object | None:
    for arg in args:
        # >>> ast.dump(ast.parse("f'a{1}b'").body[0].value)
        # "JoinedStr(values=[Constant(value='a'), FormattedValue(value=Constant(value=1), conversion=-1), Constant(value='b')])"
        if isinstance(arg, ast.JoinedStr):
            for value in arg.values:
                if isinstance(value, ast.FormattedValue):
                    if value.conversion != -1:
                        raise ctx.CompileError("FormattedValue.conversions is not supported")
                    if value.format_spec is not None:
                        raise ctx.CompileError("FormattedValue.format_specs is not supported")
                    ctx.asm_out('print').append(m_ast.Call(ctx.freeze(), 'print', [compiler.translate_node(ctx, value.value, as_operand=True)], [m_ast.UseDef.Use]))
                else:
                    ctx.asm_out('print').append(m_ast.Call(ctx.freeze(), 'print', [compiler.translate_node(ctx, value, as_operand=True)], [m_ast.UseDef.Use]))
        else:
            ctx.asm_out('print').append(m_ast.Call(ctx.freeze(), 'print', [compiler.translate_node(ctx, arg, as_operand=True)], [m_ast.UseDef.Use]))
    return None


def Processors_add(*args: ast.expr, ctx: BuildContext) -> Object | None:
    if len(args) < 1:
        raise ctx.CompileError('Insufficient arguments')
    base = args[0]
    if not isinstance(base, ast.Name):
        raise ctx.CompileError(f'{ast.dump(base)} is not a parameterized processor.')
    base2 = ctx.scope.get(ctx, base.id)
    if not isinstance(base2, m_ast.ParameterizedProcessor):
        raise ctx.CompileError(f'{ast.dump(base)} is not a parameterized processor.')
    with ctx.set(constexpr=True):
        compiler._add_processor(ctx, base2, [compiler.translate_node(ctx, a, as_operand=True) for a in args[1:]])
    return None


def _join_f_strings_in_inline_assembly(ctx: BuildContext, joined_str: ast.JoinedStr):
    op = ''
    for v in joined_str.values:
        match v:
            case ast.Constant():
                op += str(v.value)
            case ast.FormattedValue():
                with ctx.set(constexpr=True):
                    c = compiler.translate_node(ctx, v.value)
                match c:
                    case m_ast.PrimitiveValue():
                        op += str(c.value)
                    case m_ast.EnumValue():
                        op += str(c.value)
                    case _:
                        raise ctx.CompileError(f'{c!r} is not a primitive value or a enum value')
            case _:
                raise ctx.CompileError(f'{ast.dump(v)} is not a constant expression')
    return op


def memory_of(name: ast.Name, *, ctx: BuildContext) -> Object | None:
    shared_name = ctx.scope.get(ctx, name.id)
    if not isinstance(shared_name, m_ast.SharedName):
        raise ctx.CompileError(f'{shared_name!r} is not a shared memory')
    return m_ast.MemoryOf(shared_name, processor=ctx.scope.processor)


def address_of(name: ast.Name, *, ctx: BuildContext) -> Object | None:
    shared_name = ctx.scope.get(ctx, name.id)
    if not isinstance(shared_name, m_ast.SharedName):
        raise ctx.CompileError(f'{shared_name!r} is not a shared memory')
    return m_ast.AddressOf(ctx.freeze(), shared_name, processor=ctx.scope.processor)


def static_malloc(size_: ast.expr, *, ctx: BuildContext) -> Object | None:
    """Static memory allocation"""
    with ctx.set(constexpr=True):
        size = compiler.translate_node(ctx, size_)
        s = m_ast.MemorySlice(helper.as_integer(ctx, size))
        return m_ast.Tuple.wrap((m_ast.MemoryOf(s, processor=ctx.scope.processor), m_ast.AddressOf(ctx.freeze(), s, processor=ctx.scope.processor)))


def ident(arg: ast.JoinedStr, *, ctx: BuildContext) -> Object | None:
    """Token pasting"""
    return m_ast.LocalName(name=_join_f_strings_in_inline_assembly(ctx, arg), processor=ctx.scope.processor)


def asm(op_: ast.JoinedStr | ast.Constant, *args_: ast.expr, ctx: BuildContext) -> Object | None:
    """Inline assembly"""
    # Parse the first argument
    match op_:
        case ast.JoinedStr():
            # Example: asm(f'radar {target1} {target2} {target3} {sort_type}', ...)
            op = _join_f_strings_in_inline_assembly(ctx, op_)
        case ast.Constant():
            # Example: asm('control enabled', ...)
            op = op_.value
            if not isinstance(op, str):
                raise ctx.CompileError(f'{op} is not a string')
        case _:
            raise LogicError

    # Parse the variable length arguments
    args: list[m_ast.OperandValue] = []
    use_def: list[m_ast.UseDef] = []
    dsts: list[m_ast.OperandValue] = []
    for arg in args_:
        match arg:
            # dst()
            case ast.Call() if isinstance(arg.func, ast.Name) and arg.func.id == 'dst':
                if len(arg.args) not in (1, 2):
                    raise ctx.CompileError(f'dst() takes 1-2 arguments but {len(arg.args)} were passed')
                if not (isinstance(arg.args[0], ast.Constant) and isinstance(arg.args[0].value, int)):
                    raise ctx.CompileError(f'{arg.args[0]} is not an integer')
                if len(arg.args) < 2:
                    dst = m_ast.LocalName(processor=ctx.scope.processor)
                else:
                    if not (isinstance(arg.args[1], ast.Constant) and isinstance(arg.args[1].value, str)):
                        raise ctx.CompileError(f'{arg.args[1]} is not a string')
                    dst = m_ast.LocalName(prefix=arg.args[1].value, processor=ctx.scope.processor)
                index = arg.args[0].value
                while len(dsts) <= index:
                    dsts.append(m_ast.PrimitiveValue(ctx.freeze(), None))
                dsts[index] = dst
                args.append(dst)
                use_def.append(m_ast.UseDef.Def)
            # *args
            case ast.Starred():
                value = compiler.translate_node(ctx, arg.value, as_operand=True)
                if not isinstance(value, m_ast.Tuple):
                    raise ctx.CompileError(f'{value!r} can not be expanded')
                for v in value.values:
                    if not isinstance(v, m_ast.OperandValue):
                        raise ctx.CompileError(f'{v} is not a value')
                    args.append(v)
                    use_def.append(m_ast.UseDef.Use)
            # generate an identifier, like C's ## operator
            case ast.JoinedStr():
                args.append(m_ast.LocalName(name=_join_f_strings_in_inline_assembly(ctx, arg), processor=ctx.scope.processor))
                use_def.append(m_ast.UseDef.Def)  # example: asm('set', f'var1', 1)
            # arg
            case _:
                args.append(compiler.translate_node(ctx, arg, as_operand=True))
                use_def.append(m_ast.UseDef.Use)

    if op.startswith('op ') and len(dsts) == 1 and args[0] == dsts[0]:
        # optimize asm('op <operator>', dst(...), ...)
        return helper.operator(ctx, op[len('op '):], args[1:])
    else:
        ctx.asm_out('asm').append(m_ast.Call(ctx.freeze(), op, args, use_def))
        return m_ast.Tuple.wrap(dsts)


def use_value(*, ctx: BuildContext) -> Object | None:
    return m_ast.LocalName(prefix='use_value()', marker='use_value()', processor=ctx.scope.processor)
