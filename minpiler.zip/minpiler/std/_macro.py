import json
import math
import textwrap
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final

from minpiler.m_ast import FrozenBuildContext
from minpiler.std import _tripy


def render_svg(filepath: str, x: None, y: None, size: float, *, ctx: FrozenBuildContext):
    import svgpathtools
    filepath = str(ctx.filepath.parent / filepath)

    def _is_closable_fixed(self: Any):
        """https://github.com/mathandy/svgpathtools/issues/71#issuecomment-736125722"""
        try:
            return _is_closable(self)
        except IndexError:
            return True

    _is_closable = svgpathtools.Path._is_closable
    svgpathtools.Path._is_closable = _is_closable_fixed

    paths, attributes = svgpathtools.svg2paths(filepath)  # type: ignore
    lines: list[str] = ["from minpiler.std import M"]
    xmin = math.inf
    xmax = -math.inf
    ymin = math.inf
    ymax = -math.inf
    for path in paths:
        for segment in path:
            xmin = min(xmin, segment.start.real, segment.end.real)
            xmax = max(xmax, segment.start.real, segment.end.real)
            ymin = min(ymin, segment.start.imag, segment.end.imag)
            ymax = max(ymax, segment.start.imag, segment.end.imag)
    scale = 1 / max(xmax - xmin, ymax - ymin) * size

    def scale_segment(segment: Any) -> tuple[tuple[float, float], tuple[float, float]]:
        start = (segment.start - xmin - ymin * 1j) * scale
        end = (segment.end - xmin - ymin * 1j) * scale
        return (
            (start.real, size - start.imag),
            (end.real, size - end.imag),
        )
    for path, attr in zip(paths, attributes):
        if len(path) == 0:
            continue
        style: dict[str, str] = {key_value.split(':')[0]: key_value.split(':')[1] for key_value in attr['style'].split(';')}
        stroke_str = style['stroke-width']
        if style['stroke'] != 'none':
            if stroke_str.endswith('px'):
                stroke_str = stroke_str[:-2]
            stroke = max(1, int(float(stroke_str) * scale))
            lines.append(f'M.draw.stroke({stroke})')
            for segment in path:
                (x0, y0), (x1, y1) = scale_segment(segment)
                lines.append(f'M.draw.line({x0} + x, {y0} + y, {x1} + x, {y1} + y)')
        if style['fill'] != 'none':
            assert style['fill'].startswith('#')
            h = style['fill'][1:]
            lines.append(f'M.draw.color({int(h[:2], 16)}, {int(h[2:4], 16)}, {int(h[4:6], 16)}, 255)')
            points: list[tuple[float, float]] = []
            for v in path[:-1]:
                points.append(scale_segment(v)[0])
            points.extend(scale_segment(path[-1]))
            for (x0, y0), (x1, y1), (x2, y2) in _tripy.earclip(points):
                lines.append(f'M.draw.triangle({x0} + x, {y0} + y, {x1} + x, {y1} + y, {x2} + x, {y2} + y)')
    assert len(lines) >= 2, f"Failed to parse {filepath}"
    return "\n".join(lines)


def _shift(font: Any):
    for char in font:
        char['right'] -= char['left']
        if char['bbox'] is not None:
            for point in char['bbox']:
                point[0] -= char['left']
        for line in char['lines']:
            for point in line:
                point[0] -= char['left']
        char['left'] = 0


# Converted the font data to json with python-hershey by scruss https://github.com/scruss/python-hershey
# and reduced the number of points by hand
font = json.loads((Path(__file__).parent / 'hershey-futural.json').read_text(encoding='utf-8'))
_shift(font)

char_table: Final = r''' !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~'''
font_data: dict[str, list[str]] = {}
char_advance: dict[str, str] = {}

for font_char, char_name in zip(font, char_table):
    lines: list[tuple[int, int, int, int]] = []
    xs: set[int] = set()
    ys: set[int] = set()
    for line in font_char['lines']:
        for (x0, y0), (x1, y1) in zip(line[:-1], line[1:]):
            points = (int(x0), int(-y0 + 13), int(x1), int(-y1 + 13))
            lines.append(points)
            xs.add(points[0])
            ys.add(points[1])
            xs.add(points[2])
            ys.add(points[3])

    if char_name == "'":
        char_name = "\\'"
    if char_name == '\\':
        char_name = '\\\\'
    font_data[char_name] = []
    if len(lines) == 0:
        font_data[char_name].append('pass')
    else:
        def name(v: int): return str(v).replace('-', '_')
        for x in sorted(xs):
            font_data[char_name].append(f'x{name(x)} = x + {x} * size')
        for y in sorted(ys):
            font_data[char_name].append(f'y{name(y)} = y + {y} * size')
        for x0, y0, x1, y1 in lines:
            font_data[char_name].append(f'M.draw.line(x{name(x0)}, y{name(y0)}, x{name(x1)}, y{name(y1)})')
    char_advance[char_name] = f"{font_char['right']} * size"

font_lowercase = r''' !?,.0123456789abcdefghijklmnopqrstuvwxyz'''


def render_char_lowercase(char: None, x: None, y: None, size: None, *, ctx: FrozenBuildContext):
    lines: list[str] = ["from minpiler.std import M"]
    for k, v in font_data.items():
        if k in font_lowercase:
            lines.append(('if' if len(lines) == 1 else 'elif') + f' char == {json.dumps(k)}:')
            for line in v:
                lines.append('    ' + line)
    return "\n".join(lines)


def render_char(char: None, x: None, y: None, size: None, *, ctx: FrozenBuildContext):
    lines: list[str] = ["from minpiler.std import M"]
    for k, v in font_data.items():
        lines.append(('if' if len(lines) == 1 else 'elif') + f' char == {json.dumps(k)}:')
        for line in v:
            lines.append('    ' + line)
    return "\n".join(lines)


def get_char_advance(char: None, size: None, *, ctx: FrozenBuildContext):
    lines: list[str] = ["from minpiler.std import M"]
    for k, v in char_advance.items():
        lines.append(('if' if len(lines) == 1 else 'elif') + f' char == {json.dumps(k)}:')
        lines.append(f'    advance = {v}')
    lines.append('else:')
    lines.append(f'    advance = 0')
    lines.append(f'return advance')
    return "\n".join(lines)


def render_text(text: str, x: None, y: None, size: float, *, ctx: FrozenBuildContext):
    lines: list[str] = ["from minpiler.std import util"]

    if len(text) > 0:
        lines.append(f'util.render_char({json.dumps(text[0])}, x, y, size)')

        left = 0
        font_data = json.loads((Path(__file__).parent / 'hershey-futural.json').read_text(encoding='utf-8'))
        for prev, char in zip(text[:-1], text[1:]):
            advance = font_data[char_table.index(prev)]['right'] - font_data[char_table.index(prev)]['left']
            left += float(advance * size)
            lines.append(f'util.render_char({json.dumps(char)}, x + {left}, y, size)')

    return "\n".join(lines)


color_palette_cache: dict[Path, Any] = {}  # dict[Path, np.ndarray]


def _render_image_file(filepath: str, resolution_x: int, resolution_y: int, src_y_start: int, src_y_stop: int, num_colors: int, dst_left: None, dst_top: None, dst_width: float, dst_height: float, display: None, once: bool, *, ctx: FrozenBuildContext):
    import numpy as np
    import PIL.Image
    import PIL.ImageOps
    import scipy.cluster.vq
    import scipy.spatial
    import skimage.color

    scale_x: float = dst_width / resolution_x
    scale_y: float = dst_height / resolution_y

    real_filepath = (ctx.filepath.parent / filepath).absolute().resolve()
    if not Path(real_filepath).exists():
        raise ctx.CompileError(f'{real_filepath!r} does not exist')

    def quantize_pixels(color_palette_: np.ndarray, pixels_: np.ndarray) -> np.ndarray:
        return scipy.spatial.KDTree(color_palette_).query(pixels_[np.arange(pixels_.shape[0])])[1]  # type: ignore # pixel_id -> color_id

    lines: list[str] = ["from minpiler.std import M, L"]
    if real_filepath not in color_palette_cache:
        pixels = np.array(PIL.Image.open(real_filepath).convert('RGB').getdata())

        def median_cut(bucket: np.ndarray, n: int = num_colors) -> np.ndarray:
            assert n & (n - 1) == 0, f'num_colors must be a power of 2: {num_colors}'
            if n < 2:
                return np.expand_dims(np.mean(bucket, axis=0), axis=0)
            axis = (np.max(bucket, axis=0) - np.min(bucket, axis=0)).argmax()
            median = np.median(bucket, axis=0)[axis]
            children = bucket[np.where(bucket[:, axis] < median)], bucket[np.where(bucket[:, axis] >= median)]
            return np.concatenate((median_cut(children[0], n // 2), median_cut(children[1], n - n // 2)))

        def k_means(pixels: np.ndarray):
            stdev = np.std(pixels, axis=0)
            stdev[stdev == 0] = 1.0
            return scipy.cluster.vq.kmeans(pixels / stdev, num_colors, iter=20, seed=0)[0] * stdev

        # clustering
        np.random.seed(0)
        color_quantization_algorithm = k_means  # median_cut or k_means
        color_palette = skimage.color.lab2rgb(color_quantization_algorithm(skimage.color.rgb2lab(pixels.astype(np.float32) / 255))) * 255  # color_id -> color
        indexed_pixels = quantize_pixels(color_palette, pixels)

        # sort the color palette by frequency of use
        rank_to_color_id = np.array([color_id for color_id, _ in sorted([(color_id, np.count_nonzero(indexed_pixels == color_id)) for color_id in range(color_palette.shape[0])], key=lambda v: -v[1])])
        color_palette_cache[real_filepath] = color_palette[rank_to_color_id]

    pixels = np.array(PIL.ImageOps.flip(PIL.Image.open(real_filepath).convert('RGB').resize((resolution_x, resolution_y), PIL.Image.BICUBIC)).getdata())
    color_palette: np.ndarray = color_palette_cache[real_filepath]
    indexed_pixels = quantize_pixels(color_palette, pixels)

    command_count = 0
    lines.append(f'M.draw_flush(display)')
    last_color_command: str | None = None

    def add_draw_command(line: str, set_color: bool):
        nonlocal command_count, last_color_command
        if set_color:
            last_color_command = line
        lines.append(line)
        command_count += 1
        if command_count > 250:  # max_graphics_buffer = 256
            lines.append(f'M.draw_flush(display)')
            command_count = 0
            if last_color_command is not None:
                lines.append(last_color_command)  # TODO: not the processor but the display holds current color? or is it the emulator's bug?

    # for each color
    for color_id in range(color_palette.shape[0]):
        r, g, b = color_palette[color_id]
        add_draw_command(f'M.draw.color({r}, {g}, {b}, 255)', True)

        def to_segments(swap_axis: bool):
            segments: list[tuple[int, int, int, int, int]] = []  # list[(x_start_min, x_start_max, x_end_min, x_end_max, y)]

            INF = max(resolution_x, resolution_y) * 2

            @dataclass
            class State1:
                x_start_min: None | int

            @dataclass
            class State2:
                x_start_min: int
                x_start_max: int
                x_end_min: int
                x_end_max: int

            for y in range(resolution_x) if swap_axis else range(src_y_start, src_y_stop):
                state: State1 | State2 = State1(None)
                for x in range(src_y_start, src_y_stop) if swap_axis else range(resolution_x):
                    i = x * resolution_x + y if swap_axis else y * resolution_x + x
                    if isinstance(state, State1):
                        if indexed_pixels[i] < color_id:
                            if state.x_start_min is not None:
                                segments.append((state.x_start_min, INF, -INF, x - 1, y))
                            state.x_start_min = None
                        elif indexed_pixels[i] > color_id:
                            if state.x_start_min is None:
                                state.x_start_min = x
                        else:
                            if state.x_start_min is None:
                                state = State2(x, x, x, x)
                            else:
                                state = State2(state.x_start_min, x, x, x)
                    else:
                        if indexed_pixels[i] < color_id:
                            segments.append((state.x_start_min, state.x_start_max, state.x_end_min, state.x_end_max, y))  # type: ignore
                            state = State1(None)
                        elif indexed_pixels[i] > color_id:
                            if once:
                                state.x_end_max = x
                            else:
                                segments.append((state.x_start_min, state.x_start_max, state.x_end_min, state.x_end_max, y))  # type: ignore
                                state = State1(None)
                        else:
                            state.x_end_min = x
                            state.x_end_max = x
                if isinstance(state, State1):
                    if state.x_start_min is not None:
                        segments.append((state.x_start_min, INF, -INF, (src_y_stop if swap_axis else resolution_x) - 1, y))
                else:
                    segments.append((state.x_start_min, state.x_start_max, state.x_end_min, state.x_end_max, y))  # type: ignore

            def merge_rects(from_bottom: bool = True):
                rects: dict[int, set[tuple[int, int, int, int, int]]] = defaultdict(lambda: set())  # (y_min if from_bottom else y_max) -> set[(x_start_min, x_start_max, x_end_min, x_end_max, height)]

                for x_start_min, x_start_max, x_end_min, x_end_max, y in reversed(segments) if from_bottom else segments:
                    for (x_start_min2, x_start_max2, x_end_min2, x_end_max2, height2) in rects[y + 1 if from_bottom else y - 1] if once else []:
                        if x_start_min2 <= x_start_max and \
                                x_start_min <= x_start_max2 and \
                                x_end_min <= x_end_max2 and \
                                x_end_min2 <= x_end_max:
                            rects[y + 1 if from_bottom else y - 1].remove((x_start_min2, x_start_max2, x_end_min2, x_end_max2, height2))
                            rects[y].add((max(x_start_min, x_start_min2), min(x_start_max, x_start_max2), max(x_end_min, x_end_min2), min(x_end_max, x_end_max2), height2 + 1))
                            break
                    else:
                        rects[y].add((x_start_min, x_start_max, x_end_min, x_end_max, 1))

                # convert to set[(x, y, width, height)]
                if from_bottom:
                    return {(x_start_max, y_min, x_end_min - x_start_max + 1, height) for y_min, v in rects.items() for _x_start_min, x_start_max, x_end_min, _x_end_max, height in v if x_start_max <= x_end_min}
                else:
                    return {(x_start_max, y_max - height + 1, x_end_min - x_start_max + 1, height) for y_max, v in rects.items() for _x_start_min, x_start_max, x_end_min, _x_end_max, height in v if x_start_max <= x_end_min}

            rectsA = merge_rects(False)
            rectsB = merge_rects(True)
            rects_xywh = rectsA if len(rectsA) < len(rectsB) else rectsB
            del segments

            diagonal_lines: set[tuple[int, int, int, int]] = set()  # x0, y0, x1, y1

            # Merge known shapes
            def merge_diagonal_line(x0: int, y0: int, x1: int, y1: int):
                if (x0, y0, 1, 1) in rects_xywh and (x1, y1, 1, 1) in rects_xywh:
                    diagonal_lines.add((x0, y0, x1, y1))
                    rects_xywh.remove((x0, y0, 1, 1))
                    rects_xywh.remove((x1, y1, 1, 1))

            # TODO: need to be tested and add shapes if it works
            if False and once:
                if scale_x == 1 and scale_y == 1:
                    for y in range(src_y_start, src_y_stop):
                        for x in range(resolution_x):
                            merge_diagonal_line(x, y, x + 1, y + 1)
                            merge_diagonal_line(x, y, x - 1, y + 1)

            if swap_axis:
                return {(y, x, height, width) for x, y, width, height in rects_xywh}, {(y0, x0, y1, x1) for x0, y0, x1, y1 in diagonal_lines}
            else:
                return rects_xywh, diagonal_lines

        round_points_x = np.floor(np.arange(resolution_x + 1) * scale_x)
        round_points_y = np.floor(np.arange(resolution_y + 1) * scale_y)

        def round_x(x: float):
            return round_points_x[np.abs(round_points_x - x).argmin()]

        def round_y(y: float):
            return round_points_y[np.abs(round_points_y - y).argmin()]

        A = to_segments(False)
        B = to_segments(True)
        shapes = A if len(A[0]) + len(A[1]) < len(B[0]) + len(B[1]) else B

        # rects
        for x, y, width, height in shapes[0]:
            x_int = round_x(x * scale_x)
            y_int = round_y(y * scale_y)
            add_draw_command(f'M.draw.rect(dst_left + {x_int}, dst_top + {y_int}, {round_x((x + width) * scale_x) - x_int}, {round_y((y + height) * scale_y) - y_int})', False)

        # diagonal lines
        for x0, y0, x1, y1 in shapes[1]:
            add_draw_command(f'M.draw.line(dst_left + {round_x(x0 * scale_x)}, dst_top + {round_y(y0 * scale_y)}, {round_y(x1 * scale_x)}, {round_y(y1 * scale_y)})', False)

    lines.append(f'M.draw_flush(display)')
    return "\n".join(lines)


def render_image_file(filepath: str, resolution_x: int, resolution_y: int, num_colors: int, dst_left: None, dst_top: None, dst_width: float, dst_height: float, display: None, once: bool, *, ctx: FrozenBuildContext):
    return _render_image_file(filepath, resolution_x, resolution_y, 0, resolution_y, num_colors, dst_left, dst_top, dst_width, dst_height, display, once, ctx=ctx)


image_parts: dict[str, list[tuple[int, int]]] = {}


def split_image_file(filepath: str, resolution_x: int, resolution_y: int, num_colors: int, dst_left: None, dst_top: None, dst_width: float, dst_height: float, display: None, once: bool, *, ctx: FrozenBuildContext) -> int:
    def f(start: int, end: int):
        return _render_image_file(filepath, resolution_x, resolution_y, start, end, num_colors, dst_left, dst_top, dst_width, dst_height, display, once, ctx=ctx)

    if filepath not in image_parts:
        parts: list[tuple[int, int]] = []
        size = len(f(0, resolution_y).splitlines())
        if size <= 950:
            parts.append((0, resolution_y))
        else:
            mean = resolution_y * 950 // size
            assert mean > 0, f"resolution = {(resolution_x, resolution_y)} is too large: {filepath}"

            start = 0
            end = mean
            while start < end:
                size = len(f(start, resolution_y).splitlines())
                while size > 950:
                    end = max(start + (end - start) * 950 // size, end - 1)
                    assert start < end, f"resolution = {(resolution_x, resolution_y)} is too large: {filepath}"
                    size = len(f(start, end).splitlines())
                parts.append((start, end))
                start = end
                end = min(start + mean, resolution_y)

        image_parts[filepath] = parts

    return len(image_parts[filepath])


def render_image_file_multiprocessing(filepath: str, resolution_x: int, resolution_y: int, num_colors: int, dst_left: None, dst_top: None, dst_width: float, dst_height: float, display: None, once: bool, *, ctx: FrozenBuildContext):
    num_parts = split_image_file(filepath, resolution_x, resolution_y, num_colors, dst_left, dst_top, dst_width, dst_height, display, once, ctx=ctx)
    result = f'''\
from minpiler.std import Processors

'''
    for i in range(num_parts):
        result += f'''\
@Processors.add
def f{i}():
{textwrap.indent(_render_image_file(filepath, resolution_x, resolution_y, *image_parts[filepath][i], num_colors, dst_left, dst_top, dst_width, dst_height, display, once, ctx=ctx), "    ")}
'''
    if once:
        result += '''\
while True:
    pass
'''
    return result
