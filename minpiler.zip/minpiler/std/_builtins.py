# minpiler.nobuiltins
import typing as _typing

# builtin functions cannot be used in minpiler.std
from minpiler.std import M, inline, syntactic_macro


@inline
def abs(a: float):
    return M.math.abs(a)


@inline
def divmod(x: float, y: float):
    return x // y, x % y


@inline
def pow(base: float, exp: float):
    # unimplemented: pow(base, exp, mod)
    return base ** exp


@inline
def max(*args: float) -> float:
    max_value = args[0]
    for x in args[1:]:
        max_value = M.math.max(max_value, x)
    return max_value


@inline
def min(*args: float) -> float:
    min_value = args[0]
    for x in args[1:]:
        min_value = M.math.min(min_value, x)
    return min_value


@inline
def float(x: _typing.Any) -> float:
    return x + 0


@inline
def int(x: _typing.Any) -> int:
    return M.math.floor(x)


@inline
def bool(x: _typing.Any) -> bool:
    return not not x
