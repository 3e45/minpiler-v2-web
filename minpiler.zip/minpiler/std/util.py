import typing as _typing

from minpiler.std import ConstExpr, M, MObject, _typeshed_generated, inline, macro


@inline
def memory_capacity(memory_block: _typeshed_generated._AnyMObject):
    return 64 if memory_block.size == 1 else 512


@inline
def find_player_with_links():
    player = M.radar(M.get_link(0), M.RadarTarget.player, M.RadarTarget.any, M.RadarTarget.any, M.RadarSort.distance, 1)
    i = 1
    while player is None and i < M.at.const.links:
        player = M.radar(M.get_link(i), M.RadarTarget.player, M.RadarTarget.any, M.RadarTarget.any, M.RadarSort.distance, 1)
        i += 1
    return player


@inline
def find_player_by_name(name: str):
    while True:
        M.unit.bind(M.at.UnitType.gamma)
        if M.at.const.unit.name == name:
            break
        M.unit.bind(M.at.UnitType.beta)
        if M.at.const.unit.name == name:
            break
        M.unit.bind(M.at.UnitType.alpha)
        if M.at.const.unit.name == name:
            break
    return M.at.const.unit


@inline
def world_coord_to_display_coord(display_x: float, display_y: float, x: float, y: float, size: _typing.Literal[3, 6]) -> tuple[float, float]:
    """
    display_x: display.x
    display_y: display.y
    size: display.size (logic-display=3, large-logic-display=6)
    """
    return (x - display_x) * 32 + (-8 + size / 2 * 32), (y - display_y) * 32 + (-8 + size / 2 * 32)


@inline
def render_uint(n: float, x: float, y: float, size: float) -> float:
    if n == 0:
        render_char('0', x, y, size)
        right = 0
    else:
        # Count the number of digits
        m = n
        num_digits_sub_1 = -1
        while m > 0:
            m //= 10
            num_digits_sub_1 += 1

        right = 18 * size * num_digits_sub_1
        left = right
        m = n  # Assignments to function parameters of inline functions are not allowed
        while m > 0:
            ones = m % 10
            m //= 10
            if ones == 0:
                render_char('0', left + x, y, size)
            elif ones == 1:
                render_char('1', left + x, y, size)
            elif ones == 2:
                render_char('2', left + x, y, size)
            elif ones == 3:
                render_char('3', left + x, y, size)
            elif ones == 4:
                render_char('4', left + x, y, size)
            elif ones == 5:
                render_char('5', left + x, y, size)
            elif ones == 6:
                render_char('6', left + x, y, size)
            elif ones == 7:
                render_char('7', left + x, y, size)
            elif ones == 8:
                render_char('8', left + x, y, size)
            elif ones == 9:
                render_char('9', left + x, y, size)
            left -= 18 * size
    return right


@inline
def render_uint_with_metric_prefix(n: float, x: float, y: float, size: float):
    if n < 1_000:
        m = n
    elif n < 1_000_000:
        m = M.math.floor(n / 1_000)
    else:
        m = M.math.floor(n / 1_000_000)
    right = render_uint(m, x, y, size)  # Calling only in one place to reduce code length
    if n < 1_000:
        pass
    elif n < 1_000_000:
        render_char('k', x + right + size * 22, y, size)
    else:
        render_char('M', x + right + size * 22, y, size)


@macro('_macro', 'render_text')
def render_text(text: ConstExpr[str], x: float, y: float, size: ConstExpr[float]) -> None:
    """
    This function renders 'futural' font in Hershey fonts.
    https://www.ghostscript.com/doc/current/Hershey.htm

    Use restriction of Hershey font:
    > This distribution of the Hershey Fonts may be used by anyone for any purpose, commercial or otherwise, providing that:
    > - The Hershey Fonts were originally created by Dr. A. V. Hershey while working at the U. S. National Bureau of Standards.
    > - The format of the Font data in this distribution was originally created by James Hurt Cognition, Inc. 900 Technology Park Drive Billerica, MA 01821 (mit-eddie!ci-dandelion!hurt)

    `util.render_text('foo', 0, 0, 1.2)` is same as the following code.

    ```
    x = 0
    util.render_text('f', x, 0, 1.2)
    x += util.get_char_advance('f', 1.2)
    util.render_text('o', x, 0, 1.2)
    x += util.get_char_advance('o', 1.2)
    util.render_text('o', x, 0, 1.2)
    ```
    """
    raise NotImplementedError


@macro('_macro', 'render_svg')
def render_svg(filepath: ConstExpr[str], x: float, y: float, size: ConstExpr[float]) -> None:
    raise NotImplementedError


@macro('_macro', 'render_image_file')
def render_image_file(filepath: ConstExpr[str], resolution_x: ConstExpr[int], resolution_y: ConstExpr[int], num_colors: ConstExpr[int], dst_left: int, dst_top: int, dst_width: ConstExpr[float], dst_height: ConstExpr[float], display: MObject, once: ConstExpr[bool]) -> None:
    raise NotImplementedError


@macro('_macro', 'render_image_file_multiprocessing')
def render_image_file_multiprocessing(filepath: ConstExpr[str], resolution_x: ConstExpr[int], resolution_y: ConstExpr[int], num_colors: ConstExpr[int], dst_left: int, dst_top: int, dst_width: ConstExpr[float], dst_height: ConstExpr[float], display: MObject, once: ConstExpr[bool]) -> None:
    raise NotImplementedError


@inline
def mod(a: float, b: float) -> float:
    return ((a % b) + b) % b


@macro('_macro', 'render_char_lowercase')
def render_char_lowercase(char: str, x: float, y: float, size: float) -> None:
    """
    This function renders a subset of 'futural' font in Hershey fonts.
    https://www.ghostscript.com/doc/current/Hershey.htm

    Characters:  !?,.0123456789abcdefghijklmnopqrstuvwxyz

    Use restriction of Hershey font:
    > This distribution of the Hershey Fonts may be used by anyone for any purpose, commercial or otherwise, providing that:
    > - The Hershey Fonts were originally created by Dr. A. V. Hershey while working at the U. S. National Bureau of Standards.
    > - The format of the Font data in this distribution was originally created by James Hurt Cognition, Inc. 900 Technology Park Drive Billerica, MA 01821 (mit-eddie!ci-dandelion!hurt)
    """
    raise NotImplementedError


@macro('_macro', 'render_char')
def render_char(char: str, x: float, y: float, size: float) -> None:
    r"""
    This function renders 'futural' font in Hershey fonts.
    https://www.ghostscript.com/doc/current/Hershey.htm

    Characters:  !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~

    Use restriction of Hershey font:
    > This distribution of the Hershey Fonts may be used by anyone for any purpose, commercial or otherwise, providing that:
    > - The Hershey Fonts were originally created by Dr. A. V. Hershey while working at the U. S. National Bureau of Standards.
    > - The format of the Font data in this distribution was originally created by James Hurt Cognition, Inc. 900 Technology Park Drive Billerica, MA 01821 (mit-eddie!ci-dandelion!hurt)
    """
    raise NotImplementedError


@macro('_macro', 'get_char_advance')
def get_char_advance(char: str, size: float) -> float:
    raise NotImplementedError


@inline
def get_uncontrolled_unit(prev_unit: MObject | None, flag: int | float, unit_type: _typeshed_generated.UnitType) -> MObject | None:
    """
    Example:
    ```
    unit1 = use_object()
    state1 = 0
    flag = M.math.floor(M.math.rand(100000000))
    while True:
        unit1 = util.get_uncontrolled_unit(unit1, flag, M.at.UnitType.flare)
        if unit1 is None:
            continue
        found, x, y, core = M.unit.locate.building(M.BlockFlag.core, False)
        state1 = util.bring(unit1, core, M.at.Item.sand, L.container1, core, state1)
    ```
    """
    unit = prev_unit
    if unit is None or unit.dead or unit.flag != flag:
        unit = None
        i = 0
        while i < 1000:
            M.unit.bind(unit_type)
            if M.at.const.unit is None:
                break
            if not M.at.const.unit.controlled:
                M.unit.move(M.at.const.thisx, M.at.const.thisy)  # make the unit controlled
                M.unit.set_flag(flag)
                unit = M.at.const.unit
                break
            i += 1
    return unit


@inline
def get_random_flare(prev_unit: MObject | None, flag: int | float) -> MObject | None:
    """
    Example:
    ```
    unit1 = use_object()
    state1 = 0
    flag = M.math.floor(M.math.rand(100000000))
    while True:
        unit1 = util.get_random_flare(unit1, flag)
        if unit1 is None:
            continue
        found, x, y, core = M.unit.locate.building(M.BlockFlag.core, False)
        state1 = util.bring(unit1, core, M.at.Item.sand, L.container1, core, state1)
    ```
    """
    unit = prev_unit
    if unit is None or unit.dead or unit.flag != flag:
        M.unit.bind(M.at.UnitType.flare)
        unit = M.at.const.unit
        if unit is not None:
            M.unit.move(M.at.const.thisx, M.at.const.thisy)  # make the unit controlled
            M.unit.set_flag(flag)
    return unit


@inline
def bring(unit: MObject, take_from: MObject, target_item: M.at.Item, drop_at: MObject, trash: MObject, state: float) -> float:
    """
    Example:
    ```
    unit1 = use_object()
    state1 = 0
    flag = M.math.floor(M.math.rand(100000000))
    while True:
        unit1 = util.get_uncontrolled_unit(unit1, flag, M.at.UnitType.flare)
        found, x, y, core = M.unit.locate.building(M.BlockFlag.core, False)
        state1 = util.bring(unit1, core, M.at.Item.sand, L.container1, core, state1)
    ```
    """
    new_state = state
    M.unit.bind(unit)
    if drop_at is not None:
        total_items = M.at.const.unit.totalItems
        if total_items > 0 and M.at.const.unit.firstItem != target_item:
            # `item_drop(M.at.Block.air)` should work in v7
            M.unit.approach(trash.x, trash.y, 6)
            M.unit.item_drop(trash, M.at.const.unit.itemCapacity)
            new_state = 0
        elif total_items < M.at.const.unit.itemCapacity:
            if M.math.abs(M.at.const.time - state) > 5000:
                M.unit.approach(take_from.x, take_from.y, 6)
                new_state = M.at.const.time
            M.unit.item_take(take_from, target_item, M.at.const.unit.itemCapacity)
        else:
            if M.math.abs(M.at.const.time + state) > 5000:
                M.unit.approach(drop_at.x, drop_at.y, 6)
                new_state = -M.at.const.time
            M.unit.item_drop(drop_at, M.at.const.unit.itemCapacity)
    return new_state


@inline
def bring_hard(unit: MObject, take_from: MObject, target_item: M.at.Item, drop_at: MObject, trash: MObject):
    M.unit.bind(unit)
    if drop_at is not None:
        total_items = M.at.const.unit.totalItems
        if total_items > 0 and M.at.const.unit.firstItem != target_item:
            # `item_drop(M.at.Block.air)` should work in v7
            M.unit.approach(trash.x, trash.y, 6)
            M.unit.item_drop(trash, M.at.const.unit.itemCapacity)
        elif total_items < M.at.const.unit.itemCapacity:
            M.unit.item_take(take_from, target_item, M.at.const.unit.itemCapacity)
            M.unit.approach(take_from.x, take_from.y, 6)
        else:
            M.unit.item_drop(drop_at, M.at.const.unit.itemCapacity)
            M.unit.approach(drop_at.x, drop_at.y, 6)
