from minpiler.std import M, MObject, inline


class DynamicMemoryAllocation:
    """
    The unoptimized human-readable code:
    https://gist.github.com/3e45/0b71d900350d8e8c61b7dda7daee66bf

    ```python
    from minpiler.std import M, emulator, experimental, static_malloc

    mem, _ = static_malloc(512)

    experimental.DynamicMemoryAllocation.init(mem)

    # Allocate mem[addr1:addr1+10]
    addr1 = experimental.DynamicMemoryAllocation.malloc(mem, 10)
    if addr1 is None:
        M.end()

    mem[addr1] = 1
    mem[addr1 + 1] = 10
    mem[addr1 + 2] = 100
    M.print(mem[addr1 + 1])

    # Allocate mem[addr2:addr2+5]
    addr2 = experimental.DynamicMemoryAllocation.malloc(mem, 5)
    if addr2 is None:
        M.end()

    experimental.DynamicMemoryAllocation.free(mem, addr1)
    experimental.DynamicMemoryAllocation.free(mem, addr2)

    emulator.kill()
    ```
    """

    @inline
    @staticmethod
    def init(mem: MObject):
        mem[0] = 1  # the address of the first block
        if mem.size == 1:
            mem[1] = 64 - 1  # size
        else:
            mem[1] = 512 - 1
        mem[2] = -1  # next

    @inline
    @staticmethod
    def malloc(mem: MObject, n: int):
        prev_link = 0
        i: int = mem[prev_link]  # type: ignore
        result: int | None = None
        n_1 = n + 1
        n_3 = n + 3
        while i != -1:
            i_1 = i + 1

            mem_i = mem[i]
            if mem_i >= n_1:
                # Allocate with splitting
                mem_i_1 = mem[i_1]
                mem[prev_link] = mem_i_1
                if mem_i >= n_3:  # (n + 1) + 2
                    # Allocate with splitting
                    size = mem_i
                    mem[i] = n_1
                    mem[i + n_1] = size - n - 1
                    mem[prev_link] = i + n_1
                    mem[i_1 + n_1] = mem_i_1
                result = i_1
                break

            prev_link = i_1
            i = mem[prev_link]  # type: ignore

        return result

    @inline
    @staticmethod
    def free(mem: MObject, freed_address: int):
        freed_block_address = freed_address - 1
        mem_freed_block_address = mem[freed_block_address]
        freed_block_address_plus_mem_freed_block_address = freed_block_address + mem_freed_block_address
        prev_address: int = -1  # type: ignore
        prev_address_1 = prev_address + 1
        i: int = mem[prev_address_1]  # type: ignore
        while i != -1:
            if i > freed_block_address:
                # If the next block exists
                mem_prev_address = mem[prev_address]
                coalesce_prev_lhs = prev_address + mem_prev_address
                mem_prev_address_mem_plus_freed_block_address = mem_prev_address + mem_freed_block_address
                mem_i_1 = mem[i + 1]
                mem_i = mem[i]
                if freed_block_address_plus_mem_freed_block_address == i:  # coalesce_next
                    if coalesce_prev_lhs == freed_block_address:  # coalesce_prev
                        mem[prev_address] = mem_prev_address_mem_plus_freed_block_address + mem_i
                        mem[prev_address_1] = mem_i_1
                    else:
                        mem[prev_address_1] = freed_block_address
                        mem[freed_block_address] = mem_freed_block_address + mem_i
                        mem[freed_address] = mem_i_1
                elif coalesce_prev_lhs == freed_block_address:  # coalesce_prev
                    mem[prev_address] = mem_prev_address_mem_plus_freed_block_address
                else:
                    mem[prev_address_1] = freed_block_address
                    mem[freed_address] = i
                M.jump .exit
            prev_address = i
            prev_address_1 = prev_address + 1
            i = mem[prev_address_1]  # type: ignore

        # If the next block doesn't exist
        mem_prev_address = mem[prev_address]
        if prev_address + mem_prev_address == freed_block_address:
            # coalesce
            mem[prev_address] = mem_prev_address + mem_freed_block_address
        else:
            mem[prev_address_1] = freed_block_address
            mem[freed_address] = -1
        M.label .exit


class WaitMainProcessor:
    """
    mem: ConstExpr[MObject]
    addr: ConstExpr[int]
    mem, addr = static_malloc(1)

    ...

    @Processors.add
    def processor1():
        WaitMainProcessor.wait(mem, addr)
        while True:
            ...

    @Processors.add
    def processor2():
        WaitMainProcessor.wait(mem, addr)
        while True:
            ...

    WaitMainProcessor.start(mem, addr)
    """
    @inline
    @staticmethod
    def wait(mem: MObject, addr: int):
        M.label .retry
        base = mem[addr]
        if base is None:
            M.jump .retry

        M.label .wait
        value = mem[addr]
        if value == base:
            M.jump .wait
        if value is None:
            M.jump .retry

        mem[addr + 1] = 0

    @inline
    @staticmethod
    def start(mem: MObject, addr: int):
        while True:
            mem[addr] = M.math.rand(100000000)
