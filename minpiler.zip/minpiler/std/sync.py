import minpiler.std

# minpiler.typedef SharedInt
SharedInt = int

# minpiler.typedef SharedFloat
SharedFloat = float

# minpiler.typedef SharedBool
SharedBool = float
