"""
This module assembles schematics.
"""

from __future__ import annotations

import base64
import struct
import zlib


def text_io(obj: object) -> bytes:
    # https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/io/TypeIO.java#L61-L61
    if isinstance(obj, bytes):
        return struct.pack('>bi', 14, len(obj)) + obj
    else:
        raise NotImplementedError(obj)


class config:
    @staticmethod
    def logic_block(code: str) -> bytes:
        # https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/world/blocks/logic/LogicBlock.java#L443-L443
        # https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/world/blocks/logic/LogicBlock.java#L90-L90
        # version, code, the number of active links
        return text_io(zlib.compress(struct.pack('>bi', 1, len(code)) + code.encode('utf-8') + struct.pack('>i', 0)))


class Schematics:
    def __init__(self, name: str, description: str) -> None:
        self.height = 0
        self.width = 0
        self.tags = {'name': name, 'description': description}
        self.blocks: list[str] = []
        self.tiles: list[bytes] = []

    def add_tile(self, x: int, y: int, rotation: int, block: str, config: bytes):
        # https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/game/Schematics.java#L587
        assert x >= 0
        assert y >= 0
        self.width = max(self.width, x + 1)
        self.height = max(self.height, y + 1)
        if block not in self.blocks:
            self.blocks.append(block)
        self.tiles.append(struct.pack('>bHH', self.blocks.index(block), y, x) + config + struct.pack('>b', rotation))

    def dump(self):
        # https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/game/Schematics.java#L564-L564
        w = bytearray()

        w += struct.pack('>HHb', self.height, self.width, len(self.tags))
        for k, v in self.tags.items():
            w += struct.pack('>H', len(k)) + k.encode('utf-8') + struct.pack('>H', len(v)) + v.encode('utf-8')

        w += struct.pack('>b', len(self.blocks))
        for block in self.blocks:
            w += struct.pack('>H', len(block)) + block.encode('utf-8')

        w += struct.pack('>i', len(self.tiles))
        for tile in self.tiles:
            w += tile

        header = b'msch'  # https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/game/Schematics.java#L49-L49
        version = b'\x01'  # https://github.com/Anuken/Mindustry/blob/d79ab3ec3ee68c738e612942befddfca7106712b/core/src/mindustry/game/Schematics.java#L50-L50
        return header + version + zlib.compress(w)

    def dump_base64(self):
        return base64.standard_b64encode(self.dump()).decode()
