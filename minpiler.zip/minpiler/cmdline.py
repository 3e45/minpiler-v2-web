"""
The cmdline module parses the command line arguments and executes the corresponding module.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import traceback
from pathlib import Path

from minpiler import compiler, decompiler, emulator, m_ast, m_parse, optimizer, schematics


def clip_text(text: str):
    try:
        import pyperclip
    except ImportError:
        print('Install pyperclip to use --clip option', file=sys.stderr)
        exit(1)
    pyperclip.copy(text)
    print(f'Copied {len([line for line in text.splitlines() if line != ""])} lines to clipboard', file=sys.stderr)


def run():
    parser = argparse.ArgumentParser()

    subparsers = parser.add_subparsers(dest='subcommand', required=True)

    parser_run = subparsers.add_parser('run', help='run a program on the emulator')
    parser_run.add_argument('-g', '--debug', action='store_true', help='enables debugger for emulator')
    parser_run.add_argument('-t', '--ticks-per-sec', type=float, default=60.0)
    parser_run.add_argument('-p', '--processor', type=str, choices=['micro-processor', 'logic-processor', 'hyper-processor'], default='hyper-processor', help='specifies the processor type')
    parser_run.add_argument('-d', '--overdrive', type=float, default=2.5, help='multiplies the execution speed. instructions_per_tick = floor((micro-processor: 2; logic-processor: 8; hyper-processor: 25) * overdrive)')

    parser_build = subparsers.add_parser('build', help='build a program into assembly code or schematics')
    parser_build.add_argument('-s', '--schematics', action='store_true', help='outputs schematics rather than assembly code. requires either --clip or --output')
    parser_build.add_argument('-o', '--output', type=str, default=None, help='writes the result to files')
    parser_build.add_argument('-c', '--clip', action='store_true', help='stores the result in the clipboard')

    parser_decompile = subparsers.add_parser('decompile', help='decompile a program')
    parser_decompile.add_argument('-o', '--output', type=str, default=None, help='writes the result to files')
    parser_decompile.add_argument('-c', '--clip', action='store_true', help='stores the result in the clipboard')

    parser.add_argument("-e", "--show-error", default=False, action="store_true")
    parser.add_argument("-O0", default=False, action="store_true", help="disable optimization")
    parser.add_argument('file', type=argparse.FileType('r', encoding='utf-8'))

    args = parser.parse_args()

    filepath = Path(args.file.name)
    optimize = (lambda a, b: b) if args.O0 else optimizer.optimize
    try:
        match args.subcommand:
            case 'build':
                assert not (args.schematics and not (args.output or args.clip)), '--schematics requires either --output or --clip'
                code_input = args.file.read()
                code = compiler.build(code_input, filepath, use_emulator_instructions=True, optimize=optimize)
                code.print_stat()

                if args.schematics:
                    s = schematics.Schematics(filepath.name, '')
                    if len(code) == 1:
                        s.add_tile(0, 0, 0, 'micro-processor', schematics.config.logic_block(str(code['__main__'])))
                    else:
                        s = schematics.Schematics(filepath.name, '')
                        for i, v in enumerate(code.values()):
                            s.add_tile(i % 33, i // 33, 0, 'micro-processor', schematics.config.logic_block(str(v)))
                    if args.clip:
                        clip_text(s.dump_base64())
                    elif args.output:
                        Path(args.output).write_bytes(s.dump())
                    else:
                        raise Exception
                elif args.clip:
                    clip_text(str(code))
                elif args.output is not None:
                    if len(code) == 0:
                        Path(args.output).write_text(str(code))
                    else:
                        Path(args.output).mkdir(parents=True, exist_ok=True)
                        for k, v in code.items():
                            (Path(args.output) / f'{k}.masm').write_text(str(v))
                else:
                    print(str(code), file=sys.stdout)
            case 'run':
                if not filepath.name.endswith('.py'):
                    print('The filename has to end with ".py"', file=sys.stderr)
                    quit(1)
                emu_yaml_path = filepath.parent / (filepath.name[:-len('.py')] + '.emu.yaml')
                if not emu_yaml_path.exists():
                    if input(f'"{emu_yaml_path}" does not exist. Do you want to create a new configuration file? [Y/n]').lower() in ('n', 'no'):
                        return
                    print(f'Created "{emu_yaml_path}"', file=sys.stderr)
                    emu_yaml_path.write_text('''\
message1:
  type: 'message'
  link: true
''')

                emu_yaml = emulator.parse_emu_yaml(emu_yaml_path.read_text(encoding='utf-8'))
                world = emulator.World(256, 256, [emulator.Gamma()], emu_yaml.buildings)

                def parse():
                    debugger = emulator.Debugger() if args.debug else None
                    code = compiler.build(filepath.read_text(encoding='utf-8'), filepath, use_emulator_instructions=True, optimize=optimize)
                    code.print_stat()
                    return [
                        emulator.LogicBlock(args.processor, m_parse.parse(str(v)), str(emu_yaml_path), emu_yaml.list_links(k), {}, world, processor_name=k, debugger=debugger, overdrive=args.overdrive)
                        for k, v in code.items()
                    ]

                mtime = os.stat(filepath).st_mtime
                emu = emulator.Emulator(parse(), world)
                disabled = False
                while not emu.killed:
                    if not disabled:
                        try:
                            emu.update()
                        except InterruptedError:
                            traceback.print_exc()
                            break
                        except Exception as err:
                            print("\033[91mError\033[0m", file=sys.stderr)
                            if args.show_error:
                                print(err, file=sys.stderr)
                            else:
                                traceback.print_exc()
                            disabled = True
                    try:
                        time.sleep(1 / args.ticks_per_sec)
                    except KeyboardInterrupt:
                        return
                    new_mtime = os.stat(filepath).st_mtime
                    if new_mtime != mtime:
                        mtime = new_mtime
                        emu.logic_blocks = parse()
                        disabled = False
            case 'decompile':
                if filepath.name.endswith('.py'):  # Compile the code then decompile it
                    py_code = str(compiler.build(args.file.read(), filepath, use_emulator_instructions=False, optimize=optimize)['__main__'])
                else:
                    py_code = args.file.read()
                code = decompiler.decompile(m_parse.parse(py_code))
                print(str(code), file=sys.stdout)
            case _:
                raise NotImplementedError
    except m_ast.CompileError as err:
        if args.show_error:
            raise err
        print(f'CompileError: {err}', file=sys.stderr)
        quit(1)
