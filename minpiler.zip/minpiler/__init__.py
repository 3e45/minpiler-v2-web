"""Compile python code to Mindustry microprocessor instructions"""

__version__ = '2.0.0'
