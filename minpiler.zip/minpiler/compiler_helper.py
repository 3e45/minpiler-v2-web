from __future__ import annotations

import ast
import enum
from typing import Final, TypeVar

from minpiler import emulator, m_ast
from minpiler.m_ast import BuildContext, Instance


class JumpPrecalculation(enum.Enum):
    always: Final = enum.auto()
    never: Final = enum.auto()
    runtime: Final = enum.auto()


T = TypeVar("T")


def reverse_comparison_operator(ctx: BuildContext, op: ast.cmpop, lineno: int, col_offset: int) -> ast.cmpop:
    a: Final = {"lineno": lineno, "col_offset": col_offset}
    match op:
        case ast.Eq(): return ast.NotEq(**a)
        case ast.NotEq(): return ast.Eq(**a)
        case ast.Lt(): return ast.GtE(**a)
        case ast.LtE(): return ast.Gt(**a)
        case ast.Gt(): return ast.LtE(**a)
        case ast.GtE(): return ast.Lt(**a)
        case ast.IsNot(): return ast.Is(**a)
        case ast.Is(): return ast.IsNot(**a)
        case _: raise ctx.CompileError(f'Unsupported comparison operator {op!r}')


def dump_comparison_operator(ctx: BuildContext, op: ast.cmpop) -> str:
    match op:
        case ast.Eq(): return 'equal'
        case ast.NotEq(): return 'notEqual'
        case ast.Lt(): return 'lessThan'
        case ast.LtE(): return 'lessThanEq'
        case ast.Gt(): return 'greaterThan'
        case ast.GtE(): return 'greaterThanEq'
        case ast.Is(): return 'strictEqual'
        case _: raise ctx.CompileError(f'Unsupported comparison operator {op!r}')


def dump_unary_operator(ctx: BuildContext, op: ast.unaryop, val: m_ast.OperandValue) -> tuple[str, list[m_ast.OperandValue]]:
    with ctx.set(node=op):
        match op:
            case ast.Invert(): return ('not', [val])
            case ast.Not(): return ('equal', [m_ast.PrimitiveValue(ctx.freeze(), 0), val])
            case ast.UAdd(): return ('add', [m_ast.PrimitiveValue(ctx.freeze(), 0), val])
            case ast.USub(): return ('sub', [m_ast.PrimitiveValue(ctx.freeze(), 0), val])
            case _: raise ctx.CompileError(f'Unsupported unary operator {op!r}')


def dump_binary_operator(ctx: BuildContext, op: ast.operator):
    match op:
        case ast.Add(): return 'add'
        case ast.Sub(): return 'sub'
        case ast.Mult(): return 'mul'
        case ast.Div(): return 'div'
        case ast.FloorDiv(): return 'idiv'
        case ast.Mod(): return 'mod'
        case ast.Pow(): return 'pow'
        case ast.LShift(): return 'shl'
        case ast.RShift(): return 'shr'
        case ast.BitOr(): return 'or'
        case ast.BitXor(): return 'xor'
        case ast.BitAnd(): return 'and'
        case _: raise ctx.CompileError(f'Unsupported binary operator {op!r}')


def as_integer(ctx: BuildContext, x: m_ast.Object | None):
    if not (isinstance(x, m_ast.PrimitiveValue) and (isinstance(x.value, int) or isinstance(x.value, float) and abs(x.value - round(x.value)) < 0.00001)):
        raise ctx.CompileError(f'{x!r} is not an integer')
    return round(x.value)


def assign(ctx: BuildContext, lhs: m_ast.LocalName | m_ast.SharedName, rhs: m_ast.OperandValue, merge_names: bool = False) -> None:
    """Assigns rhs to lhs. Outputs either the `set` or `write` instruction, depending on the context."""
    asm = ctx.asm_out('_assign')
    if isinstance(lhs, m_ast.LocalName):
        match rhs:
            case m_ast.LocalName(name=None, do_not_optimize_out=False) if merge_names:
                rhs.name = lhs.name  # Optimize `out = (_out = a + b)` to `out = a + b`
                return
            case _:
                asm.append(m_ast.Call(ctx.freeze(), 'set', [lhs, rhs], None))
                return
    else:
        asm.append(m_ast.Call(ctx.freeze(), 'write', [rhs, m_ast.MemoryOf(lhs, processor=ctx.scope.processor), m_ast.AddressOf(ctx.freeze(), lhs, processor=ctx.scope.processor)], None))
        return


def operator(ctx: BuildContext, op: str, args: list[m_ast.OperandValue], dst: m_ast.LocalName | None = None):
    """
    Executes an unary/binary operator. Writes the instructions to `asm_out` and returns a variable in which the result of the calculation is stored.
    If both operands are literals, the calculation is performed at compile time and the resulting is returned without writing anything to `asm_out`.
    """
    def return_value(value: m_ast.OperandValue):
        # assign to `dst` if it exists
        if dst is None:
            return value
        ctx.asm_out('_call_operator').append(m_ast.Call(ctx.freeze(), 'set', [dst, value], None))
        return dst

    # Pre-calculate constant expressions
    instruction_name: Final = f'op {op}'
    if (instruction_name in emulator.unary_op_func or instruction_name in emulator.binary_op_func) and instruction_name not in emulator.impure_operators and all(map(lambda a: isinstance(a, m_ast.PrimitiveValue), args)):
        literal_args: list[m_ast.PrimitiveValue] = args  # type: ignore
        return return_value(m_ast.PrimitiveValue(ctx.freeze(), emulator.eval_op(instruction_name, [emulator.LExecutor.Var(a.value, True) for a in literal_args])))

    # x + 0, x - 0 = x, x or false = x | 0 = x
    if op in ('add', 'sub', 'or') and isinstance(args[1], m_ast.PrimitiveValue) and args[1].value == 0:
        if len(args) != 2:
            raise ctx.CompileError(f'"{op}" takes 2 arguments but {len(args)} were passed')
        return return_value(args[0])

    # x ** 0 = 1
    if op in ('pow',) and isinstance(args[1], m_ast.PrimitiveValue) and args[1].value == 0:
        if len(args) != 2:
            raise ctx.CompileError(f'"{op}" takes 2 arguments but {len(args)} were passed')
        return return_value(m_ast.PrimitiveValue(ctx.freeze(), 1))

    # x * 1, x / 1, x ** 1 = x
    if op in ('mul', 'div', 'pow') and isinstance(args[1], m_ast.PrimitiveValue) and args[1].value == 1:
        if len(args) != 2:
            raise ctx.CompileError(f'"{op}" takes 2 arguments but {len(args)} were passed')
        return return_value(args[0])

    # 1 * x = x
    if op in ('mul',) and isinstance(args[0], m_ast.PrimitiveValue) and args[0].value == 1:
        if len(args) != 2:
            raise ctx.CompileError(f'"{op}" takes 2 arguments but {len(args)} were passed')
        return return_value(args[1])

    # 0 + x = x, false or x = 0 | x = x
    if op in ('add', 'or') and isinstance(args[0], m_ast.PrimitiveValue) and args[0].value == 0:
        if len(args) != 2:
            raise ctx.CompileError(f'"{op}" takes 2 arguments but {len(args)} were passed')
        return return_value(args[1])

    # 0.0 land x = 0.0
    if op in ('land',) and isinstance(args[0], m_ast.PrimitiveValue) and emulator.LExecutor.Var(args[0].value, True).numval == 0:
        return return_value(m_ast.PrimitiveValue(ctx.freeze(), 0.0))

    if dst is None:
        dst = m_ast.LocalName(prefix=op, processor=ctx.scope.processor)
    ctx.asm_out('_call_operator').append(m_ast.Call(ctx.freeze(), instruction_name, [dst, *args], [m_ast.UseDef.Def] + [m_ast.UseDef.Use] * len(args)))
    return dst


def jump_if_binary_operator(ctx: BuildContext, label: m_ast.Label, op: ast.cmpop, left: m_ast.OperandValue, right: m_ast.OperandValue) -> tuple[list[m_ast.Instruction], JumpPrecalculation]:
    """
    jumps to `label` if the expression `<left> <op> <right>` is met.
    Pre-calculates the expression if possible, and transforms `a is not a` into `not (a === b)`.
    Returns the resulting instructions.
    """
    if isinstance(op, ast.IsNot):
        asm: Final[list[m_ast.Instruction]] = []
        strict_eq = operator(ctx, 'strictEqual', [left, right])
        if isinstance(strict_eq, m_ast.PrimitiveValue):
            if emulator.LExecutor.Var(strict_eq.value, True).bool:  # jump if not strict equal
                return [], JumpPrecalculation.never
            else:
                return [m_ast.Jump(ctx.freeze(), label, 'always', [])], JumpPrecalculation.always
        return [*asm, m_ast.Jump(ctx.freeze(), label, 'equal', [strict_eq, m_ast.PrimitiveValue(ctx.freeze(), False)])], JumpPrecalculation.runtime
    else:
        op_name: Final = dump_comparison_operator(ctx, op)
        if isinstance(left, m_ast.PrimitiveValue) and isinstance(right, m_ast.PrimitiveValue):
            if emulator.LExecutor.Var(emulator.eval_op(f'op {op_name}', [emulator.LExecutor.Var(left.value, True), emulator.LExecutor.Var(right.value, True)]), True).bool:
                return [m_ast.Jump(ctx.freeze(), label, 'always', [])], JumpPrecalculation.always
            else:
                return [], JumpPrecalculation.never
        return [m_ast.Jump(ctx.freeze(), label, op_name, [left, right])], JumpPrecalculation.runtime


def deref(ctx: BuildContext, r_value: T | m_ast.SharedName) -> T | m_ast.LocalName:
    if isinstance(r_value, m_ast.SharedName):
        dst: Final = m_ast.LocalName(prefix=r_value.prefix, processor=ctx.scope.processor)
        ctx.asm_out('Dereferencing a shared name').append(m_ast.Call(ctx.freeze(), 'read', [dst, m_ast.MemoryOf(r_value, processor=ctx.scope.processor), m_ast.AddressOf(ctx.freeze(), r_value, processor=ctx.scope.processor)], None))
        return dst
    return r_value


def as_operand(ctx: BuildContext, obj: m_ast.Object | None) -> m_ast.OperandValue:
    match obj:
        case None: return m_ast.PrimitiveValue(ctx.freeze(), None)
        case m_ast.Tuple(values) if len(values) == 0: return m_ast.PrimitiveValue(ctx.freeze(), None)
        case m_ast.Tuple(values) if len(values) == 1:
            x = obj.values[0]
            if not isinstance(x, m_ast.OperandValue):
                raise ctx.CompileError(f'{x} is not a value')
            return x
        case _ if isinstance(obj, m_ast.OperandValue): return obj
        case _: raise ctx.CompileError(f'{obj!r} can not be used here')


def as_operands(ctx: BuildContext, obj: m_ast.Object | None) -> list[m_ast.OperandValue]:
    match obj:
        case None: return []
        case m_ast.Tuple(values): return list(map(lambda v: as_operand(ctx, v), values))
        case _: return [as_operand(ctx, obj)]


def as_r_value(ctx: BuildContext, obj: m_ast.Object | None) -> m_ast.RValue:
    match obj:
        case None: return m_ast.PrimitiveValue(ctx.freeze(), None)
        case m_ast.Tuple(values) if len(values) == 0: return m_ast.PrimitiveValue(ctx.freeze(), None)
        case m_ast.Tuple(values) if len(values) == 1: return obj.values[0]
        case _ if isinstance(obj, m_ast.OperandValue): return obj
        case m_ast.Instance(): return obj
        case _: raise ctx.CompileError(f'{obj!r} is not a r-value')


def as_r_values(ctx: BuildContext, obj: m_ast.Object | None) -> list[m_ast.RValue]:
    match obj:
        case None: return []
        case m_ast.Tuple(values): return list(map(lambda v: as_r_value(ctx, v), values))
        case _: return [as_r_value(ctx, obj)]
