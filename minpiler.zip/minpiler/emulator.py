"""
The emulator module emulates logic processors and a world that contains it.
"""

from __future__ import annotations

import logging
import math
import os
import random
import sys
import time
from dataclasses import dataclass
from typing import Any, Callable, Final, Literal, Type, TypeVar

from minpiler import m_parse

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'


class DuplicateFilter(logging.Filter):
    def __init__(self):
        self.msgs = set()

    def filter(self, record: Any):
        # https://stackoverflow.com/a/31953563/10710682
        rv = record.msg not in self.msgs
        self.msgs.add(record.msg)
        return rv


logging.root.addFilter(DuplicateFilter())


@dataclass(frozen=True)
class BuildingOrUnit:
    """Building & Unit"""
    name: str

    def __str__(self):
        return self.name

    def __eq__(self, o: object) -> bool:
        return isinstance(o, BuildingOrUnit) and self.name == o.name


class Senseable(dict[str, Any]):
    def __init__(self, type_name: str, attrs: dict[str, Any]) -> None:
        super().__init__()
        for k, v in attrs.items():
            self[k] = v
        self['@type'] = BuildingOrUnit(type_name)

    def __str__(self) -> str:
        return str(self['@type'])

    def __repr__(self) -> str:
        return str(self['@type'])


def _eq_func(a: 'LExecutor.Var', b: 'LExecutor.Var') -> bool:
    if a.isobj and b.isobj:
        return a.objval == b.objval
    return a.numval == b.numval


def _strict_eq_func(a: 'LExecutor.Var', b: 'LExecutor.Var') -> bool:
    if a.isobj and b.isobj:
        return a.objval == b.objval
    is_a_null = a.isobj and a.objval is None
    is_b_null = b.isobj and b.objval is None
    if is_a_null and not is_b_null or not is_a_null and is_b_null:
        return False
    return a.numval == b.numval


unary_op_func: Final[dict[str, Callable[['LExecutor.Var'], float]]] = {
    'op not': lambda a: float(~a.numi),
    # TODO: implement 'op noise' and add it to `impure_operators`
    'op abs': lambda a: abs(a.numval),
    'op log': lambda a: math.log(a.numval),
    'op log10': lambda a: math.log10(a.numval),
    'op sin': lambda a: math.sin(math.pi / 180 * a.numval),
    'op cos': lambda a: math.cos(math.pi / 180 * a.numval),
    'op tan': lambda a: math.tan(math.pi / 180 * a.numval),
    'op floor': lambda a: float(math.floor(a.numval)),
    'op ceil': lambda a: float(math.ceil(a.numval)),
    'op sqrt': lambda a: math.sqrt(a.numval),
    'op rand': lambda a: random.random() * a.numval,
}

binary_op_func: Final[dict[str, Callable[['LExecutor.Var', 'LExecutor.Var'], float]]] = {
    'op add': lambda a, b: a.numval + b.numval,
    'op sub': lambda a, b: a.numval - b.numval,
    'op mul': lambda a, b: a.numval * b.numval,
    'op div': lambda a, b: a.numval / b.numval,
    'op idiv': lambda a, b: a.numval // b.numval,
    'op mod': lambda a, b: a.numval - int(a.numval / b.numval) * b.numval,  # https://stackoverflow.com/a/60182730/10710682
    'op pow': lambda a, b: a.numval ** b.numval,
    'op shl': lambda a, b: float(a.numi << b.numi),
    'op shr': lambda a, b: float(a.numi >> b.numi),
    'op or': lambda a, b: float(a.numi | b.numi),
    'op xor': lambda a, b: float(a.numi ^ b.numi),
    'op and': lambda a, b: float(a.numi & b.numi),
    'op land': lambda a, b: float(bool(a.numval and b.numval)),
    'op equal': lambda a, b: float(_eq_func(a, b)),
    'op notEqual': lambda a, b: float(not _eq_func(a, b)),
    'op lessThan': lambda a, b: float(a.numval < b.numval),
    'op lessThanEq': lambda a, b: float(a.numval <= b.numval),
    'op greaterThan': lambda a, b: float(a.numval > b.numval),
    'op greaterThanEq': lambda a, b: float(a.numval >= b.numval),
    'op strictEqual': lambda a, b: float(_strict_eq_func(a, b)),
    'op min': lambda a, b: min(a.numval, b.numval),
    'op max': lambda a, b: max(a.numval, b.numval),
    'op atan2': lambda a, b: 180 / math.pi * math.atan2(a.numval, b.numval),
    'op len': lambda a, b: math.sqrt(a.numval ** 2 + b.numval ** 2),
}

# operators that should not be computed at compile time
impure_operators: Final = ['op rand']

jump_conds: Final = {'equal', 'notEqual', 'lessThan', 'lessThanEq', 'greaterThan', 'greaterThanEq', 'strictEqual'}


class Message(Senseable):
    def __init__(self, printflush: Callable[[str], None], attrs: dict[str, Any]) -> None:
        super().__init__('message', {'@x': 0, '@y': 0, **attrs})
        self.printflush = printflush


class SwitchBuild(Senseable):
    def __init__(self, attrs: dict[str, Any]):
        super().__init__('switch', {'@x': 0, '@y': 0, '@size': 1, '@enabled': False, **attrs})


class LogicDisplay(Senseable):
    max_display_buffer = 1024  # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L40

    def __init__(self, name: Literal['logic-display', 'large-logic-display'], attrs: dict[str, Any]) -> None:
        size = {'logic-display': 3, 'large-logic-display': 6}[name]  # https://github.com/Anuken/Mindustry/blob/e4e1bac2aa934a3b212435c53709fc57920c4b3a/core/src/mindustry/content/Blocks.java#L2218-L2218
        super().__init__(name, {'@x': 1 + size / 2, '@y': 1 + size / 2, '@size': size, **attrs})
        import pygame
        self.stroke = 1
        self.color = (255, 255, 255, 255)
        self.__commands: list[tuple[str, list[int | None]]] = []
        self.display_size = {'logic-display': 80, 'large-logic-display': 176}[name]  # https://github.com/Anuken/Mindustry/blob/e4e1bac2aa934a3b212435c53709fc57920c4b3a/core/src/mindustry/content/Blocks.java#L2216-L2216
        self.surface = pygame.Surface((self.display_size, self.display_size))
        self.surface.fill(((86, 86, 102)))  # darkerMetal https://github.com/Anuken/Mindustry/blob/e4e1bac2aa934a3b212435c53709fc57920c4b3a/core/src/mindustry/world/blocks/logic/LogicDisplay.java#L62-L62
        self.has_surface = True

    def append_commands(self, commands: list[tuple[str, list[int | None]]]):
        self.__commands.extend(commands)

    def draw(self):
        import pygame
        import pygame.draw

        if len(self.__commands) > self.max_display_buffer:
            logging.warning(f'The number of instructions in the command queue in the display has exceeded maxDisplayBuffer = {self.max_display_buffer}')

        for op, args in self.__commands:
            if op == 'draw clear':
                r, g, b = args
                assert r is not None and g is not None and b is not None
                self.surface.fill((int(r), int(g), int(b)))

        for op, args in self.__commands:
            # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/world/blocks/logic/LogicDisplay.java#L81-L81
            if op == 'draw line':
                x, y, x2, y2 = args
                assert x is not None and y is not None and x2 is not None and y2 is not None
                buf = pygame.Surface((self.display_size, self.display_size), pygame.SRCALPHA)
                buf.set_alpha(self.color[3])
                pygame.draw.line(buf, self.color[:3], (x, self.display_size - y), (x2, self.display_size - y2), self.stroke)
                self.surface.blit(buf, (0, 0))
            elif op == 'draw rect':
                x, y, w, h = args
                assert x is not None and y is not None and w is not None and h is not None
                buf = pygame.Surface((self.display_size, self.display_size), pygame.SRCALPHA)
                buf.set_alpha(self.color[3])
                pygame.draw.rect(buf, self.color[:3], pygame.Rect((x, self.display_size - y - h), (w, h)))
                self.surface.blit(buf, (0, 0))
            elif op == 'draw lineRect':
                x, y, w, h = args
                assert x is not None and y is not None and w is not None and h is not None
                if self.stroke >= 1:
                    buf = pygame.Surface((self.display_size, self.display_size), pygame.SRCALPHA)
                    buf.set_alpha(self.color[3])
                    pygame.draw.rect(buf, self.color[:3], pygame.Rect((x, self.display_size - y - h), (w, h)), self.stroke)
                    self.surface.blit(buf, (0, 0))
            elif op == 'draw poly':
                x, y, sides, radius, rotation = args
                assert x is not None and y is not None and sides is not None and radius is not None and rotation is not None
                points: list[tuple[int, int]] = []
                for i in range(0, sides + 1):
                    theta = (i / sides + rotation / 360) * 2 * math.pi
                    points.append((int(x + math.cos(theta) * radius), int(self.display_size - y - math.sin(theta) * radius)))
                buf = pygame.Surface((self.display_size, self.display_size), pygame.SRCALPHA)
                buf.set_alpha(self.color[3])
                pygame.draw.polygon(buf, self.color[:3], points)
                self.surface.blit(buf, (0, 0))
            elif op == 'draw linePoly':
                x, y, sides, radius, rotation = args
                assert x is not None and y is not None and sides is not None and radius is not None and rotation is not None
                points: list[tuple[int, int]] = []
                for i in range(0, sides + 1):
                    theta = (i / sides + rotation / 360) * 2 * math.pi
                    points.append((int(x + math.cos(theta) * radius), int(self.display_size - y - math.sin(theta) * radius)))
                buf = pygame.Surface((self.display_size, self.display_size), pygame.SRCALPHA)
                buf.set_alpha(self.color[3])
                pygame.draw.polygon(buf, self.color[:3], points, self.stroke)
                self.surface.blit(buf, (0, 0))
            elif op == 'draw triangle':
                x, y, x2, y2, x3, y3 = args
                assert x is not None and y is not None and x2 is not None and y2 is not None and x3 is not None and y3 is not None
                buf = pygame.Surface((self.display_size, self.display_size), pygame.SRCALPHA)
                buf.set_alpha(self.color[3])
                pygame.draw.polygon(buf, self.color[:3], [(x, self.display_size - y), (x2, self.display_size - y2), (x3, self.display_size - y3)])
                self.surface.blit(buf, (0, 0))
            elif op == 'draw color':
                r, g, b, a = args
                assert r is not None and g is not None and b is not None and a is not None
                if a == 0:
                    logging.warning(f'a = 0 is recognized as a = 255: draw color {args}')
                if not (0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255 and 1 <= a <= 255):
                    logging.warning(f'Invalid color ({r}, {g}, {b}, {a})')
                    r %= 256
                    g %= 256
                    b %= 256
                    a %= 256
                self.color = (r, g, b, a)
            elif op == 'draw stroke':
                width, = args
                assert width is not None
                self.stroke = width
            elif op == 'draw image':
                pass  # TODO:

        self.__commands = []

    def __hash__(self):
        return id(self)


class MemoryBuild(Senseable):
    """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/world/blocks/logic/MemoryBlock.java#L26-L26"""

    class Memory(list[float]):
        __length = 0

        def __setitem__(self, i: int, o: float):
            super().__setitem__(i, o)
            self.__length = max(self.__length, i + 1)

        def __repr__(self):
            return '[' + ', '.join([str(self[i]) for i in range(self.__length)]) + ']'

    def __init__(self, name: Literal['memory-cell', 'memory-bank'], attrs: dict[str, Any]) -> None:
        super().__init__(name, {'@size': {'memory-cell': 1, 'memory-bank': 2}[name], **attrs})
        self.memory = self.Memory([0.0 for _ in range({'memory-cell': 64, 'memory-bank': 512}[name])])  # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/content/Blocks.java#L2207-L2207

    def __repr__(self):
        return f'{str(self["@type"])}({repr(self.memory)})'


class LAssembler:
    """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LAssembler.java#L22-L22"""

    def __init__(self, instructions: list[m_parse.Instruction], processor_name: str) -> None:
        self.instructions = instructions
        self.vars: dict[str, 'LExecutor.Var'] = {
            '@counter': LExecutor.Var(0, False),
            '@time': LExecutor.Var(0, True),
            '@unit': LExecutor.Var(None, True),
            '@this': LExecutor.Var(None, True),
            '@tick': LExecutor.Var(0, True),
        }
        self.processor_name = processor_name


def eval_op(op: str, args: list['LExecutor.Var']):
    if op in unary_op_func:
        assert len(args) == 1
        try:
            return unary_op_func[op](args[0])
        except (ZeroDivisionError, OverflowError) as e:
            logging.warning(str(e))
            return 0.0
    elif op in binary_op_func:
        assert len(args) == 2
        try:
            return binary_op_func[op](args[0], args[1])
        except (ZeroDivisionError, OverflowError) as e:
            logging.warning(str(e))
            return 0.0


class GraphicsBuffer(list[tuple[str, list[int | None]]]):
    max_graphics_buffer = 256

    def append_command(self, op: str, args: list['LExecutor.Var']):
        if op == 'draw image':
            raise NotImplementedError  # TODO: Pass the string argument as is https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L873-L873
        self.append((op, [self.__pack_sign(a.numi) for a in args]))
        if len(self) > self.max_graphics_buffer:
            logging.warning(f'The number of commands in the graphics buffer has exceeded max_graphics_buffer = {self.max_graphics_buffer}')

    @staticmethod
    def __pack_sign(value: int) -> int:
        """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L882-L882"""
        # This means `value % 512 if value >= 0 else abs(value) % 512 + 512`, so only numbers in [-511, 511] are safe.
        return (abs(value) & 0b0111111111) | (0b1000000000 if value < 0 else 0)


T = TypeVar('T', bound=Senseable)


class LExecutor:
    """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L27-L27"""

    # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L28-L28
    max_instructions = 1000
    max_text_buffer = 256

    def __init__(self, builder: LAssembler, global_constants: dict[str, 'LExecutor.Var'], links: list[Senseable], world: 'World', emu_file_path: str) -> None:
        self.global_constants = global_constants  # constants: GlobalConstants https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/GlobalConstants.java#L18-L18
        self.text_buffer: str = ''
        self.graphics_buffer = GraphicsBuffer()
        self.links = links  # used in the getlink instruction
        self.world = world
        self.emu_file_path = emu_file_path
        self.load(builder)

    def assert_building_type(self, link_var: m_parse.Value, obj: None | str | Senseable, building_type: Type[T], building_type_name: str) -> T:
        if isinstance(link_var, m_parse.Name) and obj is None:
            extra_attrs = ''
            if link_var.name.startswith('display'):
                block_type = 'large-logic-display'
                extra_attrs = "\n  '@x': 0\n  '@y': 0"
            elif link_var.name.startswith('cell'):
                block_type = 'memory-cell'
            elif link_var.name.startswith('bank'):
                block_type = 'memory-bank'
            elif link_var.name.startswith('message'):
                block_type = 'message'
            else:
                block_type = link_var.name.rstrip('0123456789')
            raise ValueError(f'''\
processor "{self.processor_name}" does not have link "{link_var.name}". Consider adding the following code to "{self.emu_file_path}".

```
{link_var.name}:
  type: '{block_type}'{extra_attrs}
  link: true
```
''')
        assert isinstance(obj, building_type), f'{obj} is not {building_type_name}.'
        return obj

    def load(self, builder: LAssembler):
        """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L79-L79"""
        self.vars = builder.vars.copy()
        self.instructions = builder.instructions.copy()
        if len(self.instructions) > self.max_instructions:
            logging.warning(f'The number of instructions exceeds max_instructions = {self.max_instructions}')

        # if all instructions are emulator instructions add an loop to avoid infinite loop as emulator instructions doesn't consume instruction_per_tick.
        if all(map(lambda ins: ins.op.startswith('emulator.'), self.instructions)):
            self.instructions.append(m_parse.Jump(len(self.instructions), 'always', []))

        self.processor_name = builder.processor_name

    @staticmethod
    def invalid(value: float) -> bool:
        """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L101-L101"""
        return math.isnan(value) or math.isinf(value)

    class Var:
        """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L171-L171"""
        __value: float | None | str | Senseable | BuildingOrUnit

        def __init__(self, value: int | float | None | str | Senseable | BuildingOrUnit, constant: bool) -> None:
            self.constant = constant
            self.__set(value)

        def __set(self, value: int | float | None | str | Senseable | BuildingOrUnit):
            match value:
                case bool() if value is True:
                    self.__value = 1.0  # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/GlobalConstants.java#L30-L30
                case bool() if value is False:
                    self.__value = 0.0
                case int():
                    self.__value = float(value)
                case _:
                    self.__value = value

        def set(self, value: int | float | None | str | Senseable | BuildingOrUnit, hard: bool):
            if not self.constant or hard:
                self.__set(value)

        @property
        def isobj(self) -> bool:
            v = self.__value
            if v is None:
                return True
            if isinstance(v, float):
                return False
            return True

        @property
        def objval(self) -> None | str | Senseable:
            if self.isobj:
                return self.__value  # type: ignore
            else:
                return None

        @property
        def numval(self) -> float:
            """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L124-L124"""
            v = self.__value
            if self.isobj:
                return 0.0 if v is None else 1.0
            else:
                assert isinstance(v, float)
                return 0.0 if LExecutor.invalid(v) else float(v)

        @property
        def bool(self):
            """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L119-L119"""
            if self.isobj:
                return self.__value is not None
            assert isinstance(self.__value, float)
            return abs(self.__value) >= 0.00001

        @property
        def numi(self):
            """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L134-L134"""
            return int(self.numval)

        def __repr__(self) -> str:
            return repr(self.__value)

        def __str__(self) -> str:
            """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L930-L930"""
            if self.isobj:
                # partially implemented
                if self.__value is None:
                    return 'null'
                if isinstance(self.__value, str):
                    return self.__value
                if isinstance(self.__value, Senseable):
                    return str(self.__value)
                if isinstance(self.__value, BuildingOrUnit):
                    return str(self.__value)
                return '[object]'
            elif abs(self.numval - int(self.numval)) < 0.000001:
                return str(int(self.numval))
            else:
                return str(self.numval)

    def var(self, key: str) -> 'LExecutor.Var':
        """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L104-L104"""
        if key in self.global_constants:
            return self.global_constants[key]
        if key not in self.vars:
            if key.startswith('@'):
                return LExecutor.Var(BuildingOrUnit(key[1:]), True)
            self.vars[key] = LExecutor.Var(None, False)
        return self.vars[key]

    def __eval_operand(self, value: m_parse.Value) -> 'LExecutor.Var':
        match value:
            case m_parse.Literal(): return LExecutor.Var(value.value, True)
            case m_parse.Name(): return self.var(value.name)
            case _: raise TypeError('Unable to evaluate argument')

    def run_once(self, tick: float) -> int | None:
        """
        https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L58-L58

        Returns the line number of the instruction executed.
        """
        self.vars['@time'].set(int(time.time() * 1000), hard=True)
        self.vars['@tick'].set(tick, hard=True)
        if len(self.instructions) == 0:
            return None
        if self.vars['@counter'].numi >= len(self.instructions) or self.vars['@counter'].numi < 0:
            self.vars['@counter'].set(0, True)
        counter = self.vars['@counter'].numi
        self.vars['@counter'].set(counter + 1, True)

        ins = self.instructions[counter]

        match ins:
            case m_parse.Call():
                args = list(map(self.__eval_operand, ins.args))
                match ins.op:
                    case 'end':
                        self.vars['@counter'].set(0, True)
                    case 'emulator.kill':
                        pass
                    case 'print':
                        self.text_buffer += str(args[0])
                        if len(self.text_buffer) > self.max_text_buffer:
                            logging.warning(f'The number of characters in the text buffer has exceeded max_text_buffer = {self.max_text_buffer}')
                    case 'printflush':
                        message = self.assert_building_type(ins.args[0], args[0].objval, Message, 'a message block')
                        message.printflush(self.text_buffer)
                        self.text_buffer = ''
                    case 'sensor':
                        if not args[1].isobj or args[1].objval is None:
                            logging.warning(f'ignored an instruction `{ins}` because {args[1]} is not an object. If that is not what you intended, you should link the object to the processor "{self.processor_name}" in "{self.emu_file_path}".')
                            args[0].set(None, False)
                        else:
                            assert isinstance(ins.args[2], m_parse.Name)
                            building = self.assert_building_type(ins.args[1], args[1].objval, Senseable, 'a building')
                            args[0].set(building.get(ins.args[2].name), False)
                    case 'drawflush':
                        display = self.assert_building_type(ins.args[0], args[0].objval, LogicDisplay, 'a logic display')
                        display.append_commands(self.graphics_buffer)
                        self.graphics_buffer.clear()
                    case 'getlink':
                        assert isinstance(ins.args[0], m_parse.Name)
                        index = args[1].numi
                        if index >= len(self.links):
                            logging.warning(f'link {index} does not exist. (links = {self.links})')
                            args[0].set(None, False)
                        else:
                            args[0].set(self.links[index], False)
                    case 'radar player any any distance':
                        assert isinstance(ins.args[2], m_parse.Name)
                        for unit in self.world.units:
                            if str(unit) in ('alpha', 'beta', 'gamma'):
                                args[2].set(unit, False)
                                break
                    case 'control enabled':
                        # https://github.com/Anuken/Mindustry/blob/7dce2ee9ec177d6b7a1e53206650c11934dc1ef2/core/src/mindustry/logic/LExecutor.java#L556-L556
                        # https://github.com/Anuken/Mindustry/blob/7dce2ee9ec177d6b7a1e53206650c11934dc1ef2/core/src/mindustry/entities/comp/BuildingComp.java#L1502-L1502
                        # TODO: enabledControlTime
                        if isinstance(args[0].objval, Senseable):
                            args[0].objval['@enabled'] = args[1].bool
                    case 'set':
                        if args[1].isobj:
                            args[0].set(args[1].objval, False)
                        else:
                            args[0].set(0.0 if LExecutor.invalid(args[1].numval) else args[1].numval, False)
                    case 'write':
                        cell = self.assert_building_type(ins.args[1], args[1].objval, MemoryBuild, 'a memory block')
                        value = args[0].numval
                        index = args[2].numi
                        assert isinstance(cell, MemoryBuild)
                        cell.memory[index] = value
                    case 'read':
                        # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/logic/LExecutor.java#L785-L785
                        cell = self.assert_building_type(ins.args[1], args[1].objval, MemoryBuild, 'a memory block')
                        args[0].set(cell.memory[args[2].numi] if 0 <= args[2].numi < len(cell.memory) else 0.0, False)
                    case _ if ins.op.startswith('draw '):
                        self.graphics_buffer.append_command(ins.op, args)
                    case _ if ins.op in unary_op_func or ins.op in binary_op_func:
                        args[0].set(eval_op(ins.op, args[1:]), False)
                    case _:
                        raise ValueError(f'Unknown instruction: {ins.op}')
            case m_parse.Jump():
                apply = False
                if ins.op == 'always':
                    apply = True
                elif ins.op in jump_conds:
                    apply = eval_op(f'op {ins.op}', list(map(self.__eval_operand, ins.args)))
                else:
                    raise ValueError(f'Unknown jump condition: {ins.op}')
                if apply:
                    self.vars['@counter'].set(ins.label, True)
            case _:
                raise ValueError('Unknown instruction')

        if self.vars['@counter'].numval >= len(self.instructions):
            self.vars['@counter'].set(0, True)

        return counter


@dataclass(frozen=True)
class World:
    mapw: int
    maph: int
    units: list[Senseable]
    buildings: dict[str, Senseable]


class Debugger:
    def stepped(self, processor_name: str, line_number: int, instruction: m_parse.Instruction, instructions_per_tick: int, count: int, variables: dict[str, LExecutor.Var]):
        print(f'{instruction}\n    at {processor_name}:{line_number}\n    instruction {count}/{instructions_per_tick}', file=sys.stderr)
        print('variables:', file=sys.stderr)
        for k, v in variables.items():
            if not k.startswith('@'):
                print(f'    {k}: {v!r}', file=sys.stderr)
        command = input('[S]tep/[q]uit/[i]nspect  ')
        print("", file=sys.stderr)
        if command == '' or 'step'.startswith(command):
            return  # step
        if 'quit'.startswith(command):
            quit(1)
        print(f'invalid command: "{command}"', file=sys.stderr)


class LogicBlock(Senseable):
    def __init__(self, name: Literal['micro-processor', 'logic-processor', 'hyper-processor'], code: list[m_parse.Instruction], emu_file_path: str, links: dict[str, str], global_constants: dict[str, Any], world: World, overdrive: float = 2.5, processor_name: str = '__main__', debugger: Debugger | None = None) -> None:
        """
        links: link_name -> object_id
        """
        super().__init__(name, {'@x': 0, '@y': 0})
        self.instructions_per_tick = int({'micro-processor': 2, 'logic-processor': 8, 'hyper-processor': 25}[name] * overdrive)  # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/content/Blocks.java#L2167-L2167
        self.links = links
        self.lexecutor: LExecutor | None = None
        self.global_constants = global_constants
        self.world = world
        self.processor_name = processor_name
        self.debugger = debugger
        self.update_code(code, emu_file_path)

    def update_tile(self, tick: float, kill_on_end: bool = False) -> Literal['emulator.kill'] | None:
        """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/world/blocks/logic/LogicBlock.java#L434-L434"""
        if self.lexecutor is not None:
            count = 0
            while count < self.instructions_per_tick:
                line_number_executed = self.lexecutor.run_once(tick)
                if line_number_executed is not None:
                    if self.debugger is not None:
                        self.debugger.stepped(self.processor_name, line_number_executed, self.lexecutor.instructions[line_number_executed], self.instructions_per_tick, count, self.lexecutor.vars)
                    instruction_executed = self.lexecutor.instructions[line_number_executed]
                    if isinstance(instruction_executed, m_parse.Call):
                        if instruction_executed.op in (('emulator.kill', 'end') if kill_on_end else ('emulator.kill',)):
                            return 'emulator.kill'
                        if instruction_executed.op.startswith('emulator.'):
                            continue  # do not consume the count
                count += 1
        return None

    def update_code(self, instructions: list[m_parse.Instruction], emu_file_path: str):
        """https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/world/blocks/logic/LogicBlock.java#L287-L287"""
        asm = LAssembler(instructions, self.processor_name)

        # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/world/blocks/logic/LogicBlock.java#L298-L298
        for k, v in self.links.items():
            asm.vars[k] = LExecutor.Var(self.world.buildings[v], True)

        # https://github.com/Anuken/Mindustry/blob/a3b3745d01f700833d6643c8d552f7996ab95083/core/src/mindustry/world/blocks/logic/LogicBlock.java#L315-L315
        asm.vars['@mapw'] = LExecutor.Var(self.world.mapw, True)
        asm.vars['@maph'] = LExecutor.Var(self.world.maph, True)
        asm.vars['@links'] = LExecutor.Var(len(self.links), True)
        asm.vars['@ipt'] = LExecutor.Var(self.instructions_per_tick, True)

        asm.vars['@this'] = LExecutor.Var(self, True)
        asm.vars['@thisx'] = LExecutor.Var(self['@x'], True)
        asm.vars['@thisy'] = LExecutor.Var(self['@y'], True)

        self.lexecutor = LExecutor(asm, self.global_constants, [self.world.buildings[object_id] for object_id in self.links.values()], self.world, emu_file_path)


class Gamma(Senseable):
    """Player character"""

    def __init__(self) -> None:
        super().__init__('gamma', {'@shootX': 0, '@shootY': 0, '@x': 0, '@y': 0, '@shooting': False})


class Emulator:
    def __init__(self, logic_blocks: list[LogicBlock], world: World) -> None:
        self.logic_blocks = logic_blocks
        self.__has_screen = False
        self.__tick = 23456.7
        self.killed = False
        self.world = world

    def _get_player(self):
        for unit in self.world.units:
            if str(unit) in ('alpha', 'beta', 'gamma'):
                return unit

    def _update_window(self):
        if not self.__has_screen:
            return
        import pygame
        import pygame.event

        for event in pygame.event.get():
            def get_mouse_position():
                x__screen_px: int
                y__screen_px: int
                x__screen_px, y__screen_px = event.pos
                return self.screen_left_tile + x__screen_px / self.tile_px, self.screen_top_tile - y__screen_px / self.tile_px

            if event.type == pygame.QUIT:
                raise InterruptedError
            elif event.type == pygame.MOUSEBUTTONDOWN:
                unit = self._get_player()
                if unit is not None:
                    unit['@shooting'] = True
                    mouse_pos = get_mouse_position()
                    for switch in self.__find_objects_by_type(SwitchBuild):
                        if switch['@x'] - switch['@size'] / 2 <= mouse_pos[0] < switch['@x'] + switch['@size'] / 2 and \
                                switch['@y'] - switch['@size'] / 2 <= mouse_pos[1] < switch['@y'] + switch['@size'] / 2:
                            switch['@enabled'] = not switch['@enabled']
            elif event.type == pygame.MOUSEBUTTONUP:
                unit = self._get_player()
                if unit is not None:
                    unit['@shooting'] = False
            elif event.type == pygame.MOUSEMOTION:
                unit = self._get_player()
                if unit is not None:
                    unit['@shootX'], unit['@shootY'] = get_mouse_position()
            elif event.type == pygame.MOUSEWHEEL:
                pass

    def __find_objects_by_type(self, t: Type[T]) -> list[T]:
        result: dict[int, T] = {}
        for block in self.logic_blocks:
            for object_id in block.links.values():
                link = self.world.buildings[object_id]
                if isinstance(link, t):
                    result[id(link)] = link

        return list(result.values())

    tile_px: Final = 32
    display_border_px: Final = 8

    def update(self, kill_on_end: bool = False):
        if self.killed:
            raise ValueError('The emulator has been emulator.kill.')

        self.__tick += 1 + 0.004 * random.random() - 0.002
        for block in self.logic_blocks:
            if block.update_tile(self.__tick, kill_on_end) == 'emulator.kill':
                self.killed = True
                return

        displays = self.__find_objects_by_type(LogicDisplay)
        switches = self.__find_objects_by_type(SwitchBuild)
        if displays or switches:
            # Calculate the screen size and position
            screen_right_tile = -math.inf
            screen_left_tile = math.inf
            screen_top_tile = -math.inf
            screen_bottom_tile = math.inf
            for build in [*displays, *switches]:
                screen_right_tile = max(screen_right_tile, build['@x'] + build['@size'] / 2)
                screen_left_tile = min(screen_left_tile, build['@x'] - build['@size'] / 2)
                screen_top_tile = max(screen_top_tile, build['@y'] + build['@size'] / 2)
                screen_bottom_tile = min(screen_bottom_tile, build['@y'] - build['@size'] / 2)
            screen_width = int((screen_right_tile - screen_left_tile) * self.tile_px)
            screen_height = int((screen_top_tile - screen_bottom_tile) * self.tile_px)
            self.screen_left_tile = screen_left_tile
            self.screen_top_tile = screen_top_tile

            # Show or resize the window
            import pygame
            import pygame.display
            import pygame.freetype
            if not self.__has_screen:
                self.__has_screen = True
                pygame.init()
                pygame.freetype.init()
                self.screen = pygame.display.set_mode((screen_width, screen_height))
                self.__screen_size = (screen_width, screen_height)
                pygame.display.update()
            elif self.__screen_size != (screen_width, screen_height):
                self.screen = pygame.display.set_mode((screen_width, screen_height))
                self.__screen_size = (screen_width, screen_height)

            # Clear the screen
            self.screen.fill((176, 227, 136))

            def game_coord_to_screen_coord(xy: tuple[float, float]):
                return xy[0] * self.tile_px - screen_left_tile * self.tile_px, screen_top_tile * self.tile_px - xy[1] * self.tile_px

            # Render the displays
            for build in displays:
                left, top = game_coord_to_screen_coord((build['@x'] - build['@size'] / 2, build['@y'] + build['@size'] / 2))
                width = build['@size'] * self.tile_px

                build.draw()
                self.screen.fill((89, 63, 83), pygame.Rect((left, top), (width, width)))
                self.screen.blit(build.surface, pygame.Rect((left + self.display_border_px, top + self.display_border_px), (width - self.display_border_px * 2, width - self.display_border_px * 2)))

            # Render the switches
            for build in switches:
                left, top = game_coord_to_screen_coord((build['@x'] - build['@size'] / 2, build['@y'] + build['@size'] / 2))
                width = build['@size'] * self.tile_px

                self.screen.fill((180, 150, 180), pygame.Rect((left, top), (width, width)))
                border: Final = 4
                self.screen.fill((200, 200, 200), pygame.Rect((left + border, top + border), (width - border * 2, width - border * 2)))
                pygame.draw.circle(self.screen, (240, 240, 240) if build['@enabled'] else (120, 100, 120), (left + width / 2, top + width / 2), 8)

            pygame.display.update()
            self._update_window()

            # Move the player
            unit = self._get_player()
            if unit is not None:
                keys = pygame.key.get_pressed()
                if keys[pygame.K_a]:
                    unit["@x"] -= 0.1
                if keys[pygame.K_d]:
                    unit["@x"] += 0.1
                if keys[pygame.K_w]:
                    unit["@y"] += 0.1
                if keys[pygame.K_s]:
                    unit["@y"] -= 0.1

    def run_until_killed_or_end(self, max_steps: int):
        for _ in range(max_steps):
            self.update(kill_on_end=True)
            if self.killed:
                return
        else:
            raise ValueError('loop limit exceeded')


@dataclass(frozen=True)
class EmuYaml:
    buildings: dict[str, Senseable]
    default_links: dict[str, str]
    processor_links: dict[str, dict[str, str]]

    def list_links(self, processor_name: str):
        return {**self.default_links, **self.processor_links.get(processor_name, {})}


def parse_emu_yaml(text: str) -> EmuYaml:
    """
    Example:

    ```yaml
    message1:
      type: 'message'
      link: true

    display1:
      type: 'large-logic-display'
      '@x': 0
      '@y': 0
      link:
        processor1: display1
        processor2: display2
    ```
    """
    import yaml

    result = EmuYaml({}, {}, {})

    if text != '':
        data: dict[str, dict[str, Any]] = yaml.safe_load(text)
        assert isinstance(data, dict), f'{data} is not a dict'
        for k, v in data.items():
            assert isinstance(k, str), f'{k} is not a string'
            assert isinstance(v, dict), f'{v} is not a dict'
            assert 'type' in v and isinstance(v['type'], str), f'{v} does not have field "type" of type str'
            assert 'link' in v and (v['link'] == True or isinstance(v['link'], dict) and all([isinstance(k, str) and isinstance(x, str) for k, x in v['link'].items()])), f'{v} does not have field "link" of type `Literal[True] | dict[str, str]`'

            attrs = {k2: v2 for k2, v2 in v.items() if k2.startswith('@')}

            block_type: str = v['type']
            match v['type']:
                case ('memory-cell' | 'memory-bank') as memory_type:
                    result.buildings[k] = MemoryBuild(memory_type, attrs)
                case 'message':
                    message_block_name = k
                    result.buildings[k] = Message(lambda t: print(f'{message_block_name}: {t}'), attrs)
                case ('logic-display' | 'large-logic-display') as display_type:
                    result.buildings[k] = LogicDisplay(display_type, attrs)
                case 'switch':
                    result.buildings[k] = SwitchBuild(attrs)
                case _:
                    result.buildings[k] = Senseable(block_type, attrs)

            if v['link'] == True:
                result.default_links[k] = k
            else:
                for processor_name, link_name in v['link'].items():
                    if processor_name not in result.processor_links:
                        result.processor_links[processor_name] = {}
                    result.processor_links[processor_name][link_name] = k

    return result
