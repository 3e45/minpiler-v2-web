import sys
import typing
from collections import defaultdict

import networkx as nx

from minpiler import emulator
from minpiler.m_ast import AddressOf, Call, FrozenBuildContext, Instance, Instruction, Jump, Label, LocalName, LogicError, LongJump, MemoryOf, OperandValue, PrimitiveValue, ReadonlyName, UseDef


def _make_control_flow_graph(program: list[Instruction]):
    """
    Basic block: https://en.wikipedia.org/wiki/Basic_block
    Control-flow graph: https://en.wikipedia.org/wiki/Control-flow_graph
    """

    basic_blocks: list[list[Instruction]] = [[]]
    cfg = nx.DiGraph()

    def current_block():
        return len(basic_blocks) - 1

    def add_basic_block():
        basic_blocks.append([])
        block_id = current_block()
        cfg.add_node(block_id)
        return block_id

    labeled_jumps: list[tuple[int, Label]] = []
    label_to_block_id: dict[Label, int] = {}
    for ins in program:
        match ins:
            case LongJump():
                basic_blocks[-1].append(ins)
                for label in ins.label_set:
                    labeled_jumps.append((current_block(), label))
                add_basic_block()
            case Call(op="emulator.kill"):
                basic_blocks[-1].append(ins)
                add_basic_block()
            case Call(op="end"):
                basic_blocks[-1].append(ins)
                cfg.add_edge(current_block(), 0)
                add_basic_block()
            case Call():
                basic_blocks[-1].append(ins)
            case Jump():
                basic_blocks[-1].append(ins)
                i = current_block()
                labeled_jumps.append((i, ins.label))
                if ins.op != "always":
                    cfg.add_edge(i, add_basic_block())
                else:
                    add_basic_block()
            case Label():
                if len(basic_blocks[-1]) > 0:
                    cfg.add_edge(current_block(), add_basic_block())
                basic_blocks[-1].append(ins)
                label_to_block_id[ins] = current_block()
    cfg.add_edge(current_block(), 0)
    cfg.add_edge(-1, 0)  # start node: -1

    for block, label in labeled_jumps:
        cfg.add_edge(block, label_to_block_id[label])

    if len(basic_blocks) == 0:
        raise LogicError("The program does nothing")

    return basic_blocks, cfg


def _make_dominator_tree(cfg: nx.DiGraph, source: int):
    """
    Dominator tree: https://en.wikipedia.org/wiki/Dominator_(graph_theory)
    """
    dominator_tree = nx.DiGraph()
    for end, start in dict(nx.immediate_dominators(cfg, source)).items():
        dominator_tree.add_edge(start, end)
    return dominator_tree


def _get_use_def_targets(value: OperandValue) -> set[LocalName]:
    match value:
        case LocalName(): return {value}
        case ReadonlyName(): return {value.name}
        case Instance(): return set(value.attributes.values())
        case PrimitiveValue() | AddressOf() | MemoryOf() | Label(): return set()
        case _: raise LogicError(f'Bad argument value {value!r}')


def _uses(ins: Instruction):
    """https://en.wikipedia.org/wiki/Use-define_chain"""
    result: set[LocalName] = set()
    match ins:
        case Call():
            for value, use_def in zip(ins.args, ins.use_def):
                if use_def == UseDef.Use:
                    result.update(_get_use_def_targets(value))
        case Jump():
            for value in ins.args:
                result.update(_get_use_def_targets(value))
        case LongJump():
            result.update(_get_use_def_targets(ins.arg))
        case Label():
            pass
        case _:
            raise LogicError
    return result


def _defines(ins: Instruction):
    """https://en.wikipedia.org/wiki/Use-define_chain"""
    result: set[LocalName] = set()
    match ins:
        case Call():
            for value, use_def in zip(ins.args, ins.use_def):
                if use_def == UseDef.Def:
                    result.update(_get_use_def_targets(value))
        case Jump() | LongJump() | Label():
            pass
        case _:
            raise LogicError
    return result


def _replace_name_with_value(ins: Instruction, name: LocalName, new_value: PrimitiveValue | LocalName | ReadonlyName | Label):
    """
    Replace all uses of `name` in `ins` with `new_value`.
    """
    changed = False
    match ins:
        case Jump():
            for i in range(len(ins.args)):
                arg = ins.args[i]
                if isinstance(arg, LocalName) and arg == name or isinstance(arg, ReadonlyName) and arg.name == name:
                    ins.args[i] = new_value
                    changed = True
        case Call():
            for i in range(len(ins.args)):
                arg = ins.args[i]
                if (isinstance(arg, LocalName) and arg == name or isinstance(arg, ReadonlyName) and arg.name == name) and ins.use_def[i] == UseDef.Use:
                    ins.args[i] = new_value
                    changed = True
        case LongJump():
            if ins.arg == name:
                assert not isinstance(new_value, PrimitiveValue)
                ins.set_argument(new_value)  # this should not be change label_set
        case Label():
            pass
        case _:
            raise LogicError
    return changed


class Reach(defaultdict[LocalName, set[Instruction | typing.Literal['start']]]):
    def __init__(self, killed_names: set[LocalName]):
        super().__init__()
        self.killed_names = killed_names

    def __missing__(self, key: LocalName) -> set[Instruction | typing.Literal['start']]:
        value: set[Instruction | typing.Literal['start']] = set()
        if key not in self.killed_names:
            value.add('start')
        self[key] = value
        return value


def _find_reaching_definitions(instructions: list[Instruction]):
    """
    https://en.wikipedia.org/wiki/Reaching_definition
    """
    basic_blocks, cfg = _make_control_flow_graph(instructions)

    # reach[block][name] -> Instruction[]
    reach: dict[int, Reach] = {}

    # the start node -1 defines all variables (identical to `set name1 null; set name2 null; ...`)
    def search_from_start(node: int, killed_names: set[LocalName]):
        successor: int
        for successor in cfg.successors(node):
            if successor not in reach:
                reach[successor] = Reach(killed_names.copy())
            elif killed_names & reach[successor].killed_names < reach[successor].killed_names:
                reach[successor].killed_names &= killed_names
            else:
                continue
            killed_names_copy = killed_names.copy()
            for ins2 in basic_blocks[successor]:
                killed_names_copy.update(_defines(ins2))
            search_from_start(successor, killed_names_copy)
    search_from_start(-1, set())

    for i, block in enumerate(basic_blocks):
        gen: dict[LocalName, Instruction] = {}
        for ins in block:
            for name in _defines(ins):
                gen[name] = ins

        for name, ins in gen.items():
            closed = set()

            def search(node: int):
                if node in closed:
                    return
                closed.add(node)
                successor: int
                for successor in cfg.successors(node):
                    reach[successor][name].add(ins)
                    for ins2 in basic_blocks[successor]:
                        if name in _defines(ins2):
                            break
                    else:
                        search(successor)

            search(i)

    return reach


def _dump_blocks(basic_blocks: list[list[Instruction]], cfg: nx.DiGraph):
    object_id: dict[LocalName | Label, int] = defaultdict(lambda: len(object_id))

    def dump_argument(arg: OperandValue):
        match arg:
            case PrimitiveValue():
                return str(arg)
            case LocalName() | ReadonlyName():
                name = arg.name if isinstance(arg, ReadonlyName) else arg
                return name.name or f'Name#{object_id[name]!r}'
            case AddressOf():
                return f'address_of({arg.name!r})'
            case MemoryOf():
                return f'memory_of({arg.name!r})'
            case Label():
                return f'Label#{object_id[arg]!r}'
            case _:
                raise LogicError(f'Bad argument value {arg!r}')

    result: list[str] = []
    for i, block in enumerate(basic_blocks):
        result.append(f'[block {i}] -> {tuple(cfg.successors(i))}')
        for ins in block:
            match ins:
                case Call():
                    result.append(' '.join([ins.op, *map(dump_argument, ins.args)]))
                case Jump():
                    result.append(' '.join(['jump', dump_argument(ins.label), ins.op, *map(dump_argument, ins.args)]))
                case LongJump():
                    result.append(' '.join(['set', '@counter', dump_argument(ins.arg)]))
                case Label():
                    result.append(f'{object_id[ins]!r}:')
                case _:
                    raise LogicError(ins)
    return "\n".join(result)


def _show_graph(instructions: list[Instruction]):
    basic_blocks, cfg = _make_control_flow_graph(instructions)
    print("dominator tree:", file=sys.stderr)
    print(_make_dominator_tree(cfg, -1).edges, file=sys.stderr)

    def dump_block(i: int):
        return f'{i}:\n' + "\n".join([str(ins) for ins in basic_blocks[i]])

    G = nx.DiGraph()
    for a, b in cfg.edges:
        G.add_edge(dump_block(a), dump_block(b))
    nx.draw(G, with_labels=True, pos=nx.drawing.nx_agraph.graphviz_layout(G))
    import matplotlib.pyplot as plt
    plt.show()


def remove_jump_to_the_next_line(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    A
    jump label1 ...
    label1:
    B
    ```
    ⇓
    ```
    A
    B
    ```
    """

    changed = False
    while True:
        removed: set[int] = set()
        for i in range(len(instructions) - 1):
            jump = instructions[i]
            if not isinstance(jump, Jump):
                continue
            for j in range(i + 1, len(instructions)):
                if not isinstance(instructions[j], Label):
                    break
                if jump.label is instructions[j]:
                    removed.add(i)
                    break
        if not removed:
            break
        changed = True
        instructions = [ins for i, ins in enumerate(instructions) if i not in removed]
    return instructions, changed


def concatenate_prints(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    print "a"
    print "1"
    ```
    ↓
    ```
    print "a1"
    ```

    ```
    print 1
    ```
    ↓
    ```
    print 1
    ```

    ```
    print ""
    ```
    ↓
    ```
    ```
    """
    result: list[Instruction] = []

    for basic_block in _make_control_flow_graph(instructions)[0]:
        parts: list[tuple[Instruction, str]] = []

        def join():
            if len(parts) == 1:
                result.append(parts[0][0])
            elif len(parts) >= 2:
                result.append(Call(ctx, 'print', [PrimitiveValue(ctx, value="".join([item[1] for item in parts]))], [UseDef.Use]))
            parts.clear()

        for ins in basic_block:
            match ins:
                case Call(op='print', args=[PrimitiveValue(value=s)]):
                    parts.append((ins, str(emulator.LExecutor.Var(s, True))))
                case _:
                    join()
                    result.append(ins)
        join()

    return result, len(result) < len(instructions)


def dead_code_elimination(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    A
    jump label always
    B
    label:
    C
    ...
    ```
    ⇓
    ```
    A
    jump label always
    label:
    C
    ...
    ```
    """
    basic_blocks, cfg = _make_control_flow_graph(instructions)
    reachable_blocks: set[int] = nx.descendants(cfg, -1)
    result: list[Instruction] = []
    for i, block in enumerate(basic_blocks):
        if i in reachable_blocks:
            result.extend(block)
    return result, len(instructions) != len(result)


def constant_propagation_inside_basic_block(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    set b 2.0
    op add c b 1
    ...
    ```
    ⇓
    ```
    set b 2.0
    op add c 2.0 1
    ...
    ```
    """
    basic_blocks, _cfg = _make_control_flow_graph(instructions)
    changed = False

    # 1. for each group
    for block in basic_blocks:
        replacing: dict[LocalName, PrimitiveValue | Label] = {}
        for ins in block:
            # 3. replace <name> with <literal> until next definition of <name>
            for u in _uses(ins):
                if u in replacing:
                    changed = _replace_name_with_value(ins, u, replacing[u]) or changed
            for d in _defines(ins):
                if d in replacing:
                    replacing.pop(d)

            # 2. Find `set <name> <literal>` then
            if isinstance(ins, Call) and ins.op == "set" and isinstance(ins.args[0], LocalName) and isinstance(ins.args[1], PrimitiveValue | Label):  # set <name> <literal>
                replacing[ins.args[0]] = ins.args[1]
    return instructions, changed


def name_propagation_inside_basic_block(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    x = L.message1
    M.print_flush(y)
    ```
    ⇓
    ```
    M.print_flush(L.message1)
    ```
    """
    basic_blocks, _cfg = _make_control_flow_graph(instructions)
    changed = False

    # 1. for each group
    for block in basic_blocks:
        replacing: dict[LocalName, LocalName] = {}
        for ins in block:
            # 3. replace <name1> with <name2> until next definition of <name1> or <name2>
            for u in _uses(ins):
                if u in replacing:
                    changed = _replace_name_with_value(ins, u, replacing[u]) or changed
            for d in _defines(ins):
                if d in replacing:
                    replacing.pop(d)
                for k, v in list(replacing.items()):
                    if v == d:
                        replacing.pop(k)

            # 2. find `set <name1> <name2>` then
            if isinstance(ins, Call) and ins.op == "set" and isinstance(ins.args[0], LocalName) and isinstance(ins.args[1], LocalName | ReadonlyName):
                replacing[ins.args[0]] = ins.args[1] if isinstance(ins.args[1], LocalName) else ins.args[1].name
    return instructions, changed


def dead_store_elimination(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    set x ...
    set x 2
    ...
    ```
    ⇓
    ```
    set x 2
    ...
    ```

    ```
    set x 2
    ... (x is not used in ...)
    ```
    ⇓
    ```
    ...
    ```
    """

    changed = False
    basic_blocks, cfg = _make_control_flow_graph(instructions)

    # For each block
    for block_i, block in enumerate(basic_blocks):
        removed: list[Instruction] = []
        # find set <name> <any>
        for ins_i, ins in enumerate(block):
            if isinstance(ins, Call) and ins.op == "set" and isinstance(ins.args[0], LocalName):
                name = ins.args[0]
                for subsequent_instruction in block[ins_i + 1:]:
                    if name in _uses(subsequent_instruction):
                        break
                    if name in _defines(subsequent_instruction):
                        removed.append(ins)
                        break
                else:
                    # if `name` is not used nor redefined in the block then
                    # check all basic blocks that are reachable from the block

                    def f():
                        reachable_blocks: set[int] = nx.descendants(cfg, block_i) | {block_i}
                        for block2 in reachable_blocks:
                            for ins2 in basic_blocks[block2]:
                                if name in _uses(ins2):
                                    return False
                        return True
                    if f():
                        removed.append(ins)

        for ins in removed:
            if ins in block:
                block.remove(ins)
                changed = True
    return [ins for block in basic_blocks for ins in block], changed


def constant_propagation_between_basic_blocks(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    x = 1
    if ...:
        M.print(x)
    ```
    ⇓
    ```
    x = 1
    if ...:
        M.print(1)
    ```
    """
    basic_blocks, _cfg = _make_control_flow_graph(instructions)
    reach = _find_reaching_definitions(instructions)
    changed = False

    # Find a variable A in a basic block B
    # where last definition of A in B is an instruction F = `set A C`
    # where C is a primitive value.
    for i, block in enumerate(basic_blocks):
        last_definitions: dict[LocalName, Instruction] = {}
        for ins in block:
            for name in _defines(ins):
                last_definitions[name] = ins
        for name, ins in last_definitions.items():
            if isinstance(ins, Call) and ins.op == "set" and isinstance(ins.args[1], PrimitiveValue):  # set <name> <literal>
                A = name
                B = i
                C = ins.args[1]

                # Find a block D (D != B) where REACH(D) = {F}
                for D, reach_D in reach.items():
                    if D == B:
                        continue
                    if reach_D[A] == {ins}:
                        for ins2 in basic_blocks[D]:
                            if A in _defines(ins2):
                                break
                            changed = _replace_name_with_value(ins2, A, C) or changed

    return [ins for block in basic_blocks for ins in block], changed


def name_propagation_between_basic_blocks(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    x = L.message1
    if ...:
        M.print(x)
    ```
    ⇓
    ```
    x = L.message1
    if ...:
        M.print(L.message1)
    ```
    """
    basic_blocks, cfg = _make_control_flow_graph(instructions)
    reach = _find_reaching_definitions(instructions)
    changed = False

    def instructions_to_blocks(x: set[Instruction | typing.Literal['start']]) -> set[int]:
        result: set[int] = set()
        for v in x:
            if v == 'start':
                result.add(-1)
            else:
                for block_i, block in enumerate(basic_blocks):
                    if v in block:
                        result.add(block_i)
                        break
                else:
                    raise LogicError
        return result

    # Find a variable A in a basic block B
    # such that last definition of A in B is an instruction F = `set A C`
    # where C is a name
    # and the last definition of C in B (G) doesn't exist or exists before F
    for i, block in enumerate(basic_blocks):
        last_definitions: dict[LocalName, int] = {}
        for ins_i, ins in enumerate(block):
            for name in _defines(ins):
                last_definitions[name] = ins_i
        for name, ins_i in last_definitions.items():
            ins = block[ins_i]
            if isinstance(ins, Call) and ins.op == "set" and isinstance(ins.args[1], LocalName | ReadonlyName):  # set <name> <name>
                A = name
                B = i
                C = ins.args[1] if isinstance(ins.args[1], LocalName) else ins.args[1].name

                if C not in last_definitions or last_definitions[C] < ins_i:
                    G = block[last_definitions[C]] if C in last_definitions else None

                    # Find a block D (D != B) such that
                    # REACH(D) = {F} for A and
                    # B dom D for all H in (REACH(D) - {blockOf('start'), blockOf(G), D}) for name C where the root of the dominator tree is H
                    for D, reach_D in reach.items():
                        if D == B:
                            continue
                        if reach_D[A] == {ins}:
                            r: set[Instruction | typing.Literal['start']] = {'start'} if G is None else {'start', G}
                            # instruction H ---> block B ---> block D
                            if all([
                                D in nx.descendants(_make_dominator_tree(cfg, H), B)
                                for H in instructions_to_blocks(reach_D[C] - r) - {D}
                            ]):
                                for ins2 in basic_blocks[D]:
                                    if A in _defines(ins2):
                                        break
                                    changed = _replace_name_with_value(ins2, A, C) or changed

    return [ins for block in basic_blocks for ins in block], changed


def constant_folding(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    To help other optimization techniques, fold
    ```
    add a 1 2
    ```
    to
    ```
    set a 3
    ```
    """
    changed = False
    for i, ins in enumerate(instructions):
        if isinstance(ins, Call) and \
            (ins.op in emulator.unary_op_func or ins.op in emulator.binary_op_func) and \
            ins.op not in emulator.impure_operators and \
                all(map(lambda a: isinstance(a, PrimitiveValue), ins.args[1:])):  # add <name> <literal> <literal>
            literal_args: list[PrimitiveValue] = ins.args[1:]  # type: ignore
            instructions[i] = Call(ctx, 'set', [ins.args[0], PrimitiveValue(ctx, emulator.eval_op(ins.op, [emulator.LExecutor.Var(a.value, True) for a in literal_args]))], None)
            changed = True
    return instructions, changed


def remove_unused_labels(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    Remove unused labels to simplify the control-flow graph
    """
    used: set[Label] = set()
    for ins in instructions:
        match ins:
            case Call():
                used.update([arg for arg in ins.args if isinstance(arg, Label)])
            case Jump():
                used.add(ins.label)
                used.update([arg for arg in ins.args if isinstance(arg, Label)])
            case Label():
                pass
            case LongJump():
                used.update(ins.label_set)
            case _:
                raise LogicError

    result: list[Instruction] = []
    for ins in instructions:
        if not (isinstance(ins, Label) and ins not in used):
            result.append(ins)

    return result, len(result) != len(instructions)


def remove_jump_from_bottom_to_top(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    ```
    print 1
    jump 0 always
    ```
    ⇓
    ```
    print 1
    ```
    """
    if len(instructions) == 0:
        return instructions, False
    jump = instructions[-1]
    if not isinstance(jump, Jump) or jump.label != instructions[0]:
        return instructions, False
    return instructions[:-1], True


def basic_block_reordering(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    """
    also known as basic block layout optimization

    ```
    jump A
    B:
    <B>
    A:
    <A>
    jump B
    ```
    ⇓
    ```
    jump A
    A:
    <A>
    jump B
    B:
    <B>
    ```
    """

    # For a pair of two consecutive blocks (A, B),
    # if A and B are not directly connected and
    # there is a path P from A to B, and P doesn't have merging edges
    # we can move P between A and B.
    def f():
        nonlocal instructions
        basic_blocks, cfg = _make_control_flow_graph(instructions)

        for A, B in zip(range(0, len(basic_blocks) - 1), range(1, len(basic_blocks))):
            successors: tuple[int] = tuple(cfg.successors(A))
            if not (len(successors) == 1 and successors[0] != B and len(tuple(cfg.predecessors(successors[0]))) == 1):
                continue
            P: list[int] = [successors[0]]
            while True:
                successors = tuple(cfg.successors(P[-1]))
                if len(successors) != 1:
                    break
                if successors[0] == B:
                    result: list[Instruction] = []
                    for i in range(A + 1):
                        if i not in P:
                            result.extend(basic_blocks[i])
                    for i in P:
                        result.extend(basic_blocks[i])
                    for i in range(B, len(basic_blocks)):
                        if i not in P:
                            result.extend(basic_blocks[i])
                    instructions = result
                    return True
                if len(tuple(cfg.predecessors(successors[0]))) != 1:
                    break
                P.append(successors[0])
        return False

    # The reordering always reduces the number of jumps, so infinite loops should not occur.
    changed = False
    while f():
        changed = True

    return instructions, changed


def rewrite_longjump_to_jump(ctx: FrozenBuildContext, instructions: list[Instruction]) -> tuple[list[Instruction], bool]:
    result: list[Instruction] = []
    for ins in instructions:
        if isinstance(ins, LongJump) and isinstance(ins.arg, Label):
            result.append(Jump(ctx, ins.arg, 'always', []))
        else:
            result.append(ins)
    return result, False


def optimize(ctx: FrozenBuildContext, instructions: list[Instruction]):
    # Check LocalName.labels
    for ins in instructions:
        for name in _defines(ins):
            if name.label_set is None:
                continue
            label_set = name.label_set
            match ins:
                case Call(op='set', args=[name, rhs]):
                    match rhs:
                        case Label():
                            if rhs not in label_set:
                                raise ctx.CompileError(f'rhs={rhs!r} is not listed in lhs.label_set={label_set!r}, in {ins!r}.')
                        case LocalName() | ReadonlyName():
                            if isinstance(rhs, ReadonlyName):
                                rhs = rhs.name
                            if rhs.label_set is None:
                                raise ctx.CompileError(f'{rhs!r} is not of type Label, in {name!r}')
                            if label_set < rhs.label_set:
                                raise ctx.CompileError(f'rhs.label_set={rhs.label_set!r} is not a subset of lhs.label_set={label_set!r}, in {ins!r}')
                        case _:
                            raise ctx.CompileError(f"Only labels can be assigned to {name!r}: {ins!r}")
                case Label() | Jump() | LongJump(): raise LogicError  # Label, Jump and LongJump defines nothing
                case _: raise ctx.CompileError(f"Only labels can be assigned to {name!r}: {ins!r}")

    instructions, _ = remove_jump_to_the_next_line(ctx, instructions)
    instructions, _ = remove_unused_labels(ctx, instructions)

    # Optimization techniques other than remove_jump_to_the_next_line() cannot be applied to programs that manipulate @counter.
    changed = True
    while changed:
        changed = False
        for optimize in (
            dead_code_elimination,
            basic_block_reordering,
            constant_propagation_inside_basic_block,
            constant_propagation_between_basic_blocks,
            constant_folding,
            dead_store_elimination,
            name_propagation_inside_basic_block,
            name_propagation_between_basic_blocks,
            remove_jump_to_the_next_line,
            remove_unused_labels,
            remove_jump_from_bottom_to_top,
            rewrite_longjump_to_jump,
            concatenate_prints,
        ):
            instructions, _changed = optimize(ctx, instructions)
            changed = _changed or changed
    # print(_dump_blocks(*_make_control_flow_graph(instructions)), file=sys.stderr)
    # _show_graph(instructions)
    return instructions
