"""
m_parse is a module for parsing assembly code, used by the emulator and the decompiler.
"""

from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(frozen=True)
class Literal:
    value: float | int | str | None
    decopilation_hint: str | None = None

    def __str__(self):
        return json.dumps(self.value)


@dataclass(frozen=True)
class Name:
    name: str

    def __str__(self):
        return self.name


Value = Literal | Name


@dataclass(frozen=True)
class Call:
    op: str
    args: list[Value]

    def __str__(self):
        return f'{self.op}' + ''.join(map(lambda v: ' ' + str(v), self.args))


@dataclass(frozen=True)
class Jump:
    label: int
    op: str  # condition
    args: list[Value]

    def __str__(self):
        return f'jump {self.label} {self.op}' + ''.join(map(lambda v: ' ' + str(v), self.args))


Instruction = Call | Jump


def _find_all_positions(line: str, char: str):
    result: list[int] = []
    pos = -1
    while True:
        pos = line.find(char, pos + 1)
        if pos >= 0:
            result.append(pos)
        else:
            break
    return result


def _split_cmd(line: str):
    spc = _find_all_positions(line, ' ')
    quo = _find_all_positions(line, '"')
    for a, b in zip(quo[::2], quo[1::2]):
        spc = [p for p in spc if p < a or p > b]
    spc = [-1] + spc + [len(line)]
    return [line[a + 1:b] for a, b in zip(spc, spc[1:])]


assert _split_cmd('a b c') == ['a', 'b', 'c']
assert _split_cmd('op add a a 1') == ['op', 'add', 'a', 'a', '1']
assert _split_cmd('cmd') == ['cmd']
assert _split_cmd('"a" "b" "c"') == ['"a"', '"b"', '"c"']
assert _split_cmd('"a a" "b b" "c\nc"') == ['"a a"', '"b b"', '"c\nc"']


def _name_or_literal(line: str):
    if line == 'null':
        return Literal(None, 'None')
    if line == 'true':
        return Literal(1.0, 'True')
    if line == 'false':
        return Literal(0.0, 'False')
    if line[:1] == '"':
        assert line.endswith('"')
        return Literal(json.loads(line))
    try:
        return Literal(float(line), line)
    except ValueError:
        pass
    return Name(line)


def parse(lines: str) -> list[Instruction]:
    result: list[Instruction] = []
    for i, line in enumerate(lines.splitlines()):
        try:
            line = line.strip()
            if not line:
                continue

            cmd, *raw_args = _split_cmd(line)
            args = [_name_or_literal(a) for a in raw_args]
            if cmd == 'op':
                result.append(Call(f'{cmd} {raw_args[0]}', args[1:]))
            elif cmd == 'jump':
                result.append(Jump(int(raw_args[0]), raw_args[1], args[2:]))
            elif cmd == 'ulocate':
                result.append(Call(f'{cmd} {raw_args[0]} {raw_args[1]}', args[2:]))
            elif cmd in ('draw', 'control', 'ucontrol'):
                result.append(Call(f'{cmd} {raw_args[0]}', args[1:]))
            elif cmd in ('radar', 'uradar'):
                result.append(Call(f'{cmd} {raw_args[0]} {raw_args[1]} {raw_args[2]} {raw_args[3]}', args[4:]))
            elif cmd in ('read', 'write', 'print', 'drawflush', 'printflush', 'getlink', 'sensor', 'set', 'end', 'ubind', 'emulator.kill'):
                result.append(Call(cmd, args))
            else:
                raise ValueError(f'Unknown command {cmd}')
        except ValueError as e:
            raise ValueError(f"Could not parse the line {i}: {line}") from e
    return result
