from __future__ import annotations

import ast
import glob
import importlib
import importlib.machinery
import importlib.util
import inspect
import json
import re
import sys
import textwrap
from collections import defaultdict
from functools import reduce
from pathlib import Path
from typing import Any, Callable, Final, Literal, cast, overload

import networkx as nx

from minpiler import compiler_helper as helper
from minpiler import emulator, m_ast
from minpiler.compiler_helper import JumpPrecalculation
from minpiler.m_ast import BuildContext, FrozenBuildContext, Instruction, LogicError, Object, OperandValue


def operands_to_rvalues(x: list[m_ast.OperandValue]) -> list[m_ast.RValue]:
    return x  # type: ignore


def _jump_if(ctx: BuildContext, label: m_ast.Label, test: ast.AST) -> JumpPrecalculation:
    """
    jumps to `label` if the condition `test` is met.
    Pre-calculates the `test` if possible, and converts the combination of `and` and `or` operators into an optimal sequence of if statements.
    Writes the resulting instruction to `asm_out` and returns the result of dead code elimination.
    """
    match test:
        case ast.Constant():
            if emulator.LExecutor.Var(test.value, True).bool:
                ctx.asm_out('_jump_if').append(m_ast.Jump(ctx.freeze(), label, 'always', []))
                return JumpPrecalculation.always
            else:
                return JumpPrecalculation.never
        case ast.UnaryOp() if isinstance(test.op, ast.Not):
            # `jump if not a` => `jump unless a`
            return _jump_unless(ctx, label, test.operand)
        case ast.BoolOp() if isinstance(test.op, ast.Or):
            # `jump .label if a or b or c` =>
            # ```
            # jump .label if a
            # jump .label if b
            # jump .label if c
            # ```
            never = True
            for v in test.values:
                t = _jump_if(ctx, label, v)
                if t == JumpPrecalculation.always:
                    return JumpPrecalculation.always
                if t != JumpPrecalculation.never:
                    never = False
            if never:
                return JumpPrecalculation.never
            return JumpPrecalculation.runtime
        case ast.BoolOp() if isinstance(test.op, ast.And):
            # `jump .label if a and b and c` =>
            # ```
            # jump .label2 unless a
            # jump .label2 unless b
            # jump .label if c
            # label2:
            # ```
            always = True
            label2 = m_ast.Label(ctx.scope.processor)
            for v in test.values[:-1]:
                t = _jump_unless(ctx, label2, v)
                if t == JumpPrecalculation.always:
                    ctx.asm_out('_jump_if').append(label2)
                    return JumpPrecalculation.never
                if t != JumpPrecalculation.never:
                    always = False
            if _jump_if(ctx, label, test.values[-1]) != JumpPrecalculation.always:
                always = False
            ctx.asm_out('_jump_if').append(label2)
            if always:
                return JumpPrecalculation.always
            return JumpPrecalculation.runtime
        case ast.Compare() if len(test.ops) == 1:
            a_val = translate_node(ctx, test.left, as_operand=True)
            b_val = translate_node(ctx, test.comparators[0], as_operand=True)
            asm, precalculation = helper.jump_if_binary_operator(ctx, label, test.ops[0], a_val, b_val)
            ctx.asm_out('_jump_if').extend(asm)
            return precalculation
        case ast.Compare() if len(test.ops) >= 2:
            # `jump label if a() <=> b() <=> c() <=> d()` =>
            # ```
            # a2 = a()
            # b2 = b()
            # jump label2 unless a2 <=> b2
            # c2 = c()
            # jump label2 unless b2 <=> c2
            # d2 = d()
            # jump label if c2 <=> d2
            # label2:
            # ```
            always = True
            label2 = m_ast.Label(ctx.scope.processor)
            left = translate_node(ctx, test.left, as_operand=True)
            for op, right_ast in zip(test.ops[:-1], test.comparators[:-1]):
                right = translate_node(ctx, right_ast, as_operand=True)
                asm, t = helper.jump_if_binary_operator(ctx, label2, helper.reverse_comparison_operator(ctx, op, test.lineno, test.col_offset), left, right)
                ctx.asm_out('_jump_if').extend(asm)
                if t == JumpPrecalculation.always:
                    ctx.asm_out('_jump_if').append(label2)
                    return JumpPrecalculation.never
                if t != JumpPrecalculation.never:
                    always = False
                left = right
            right = translate_node(ctx, test.comparators[-1], as_operand=True)
            asm, t = helper.jump_if_binary_operator(ctx, label, test.ops[-1], left, right)
            if t != JumpPrecalculation.always:
                always = False
            ctx.asm_out('_jump_if').extend(asm)
            ctx.asm_out('_jump_if').append(label2)
            if always:
                return JumpPrecalculation.always
            return JumpPrecalculation.runtime
        case _:
            # `jump if a` => `jump if a != False`
            ctx.asm_out('_jump_if').append(m_ast.Jump(ctx.freeze(), label, 'notEqual', [translate_node(ctx, test, as_operand=True), m_ast.PrimitiveValue(ctx.freeze(), False)]))
            return JumpPrecalculation.runtime


def _jump_unless(ctx: BuildContext, label: m_ast.Label, test: ast.AST) -> JumpPrecalculation:
    """
    jumps to `label` unless the condition `test` is met.
    Pre-calculates the `test` if possible, and converts the combination of `and` and `or` operators into an optimal sequence of if statements.
    Writes the resulting instruction to `asm_out` and returns the result of dead code elimination.
    """
    match test:
        case ast.Constant():
            if emulator.LExecutor.Var(test.value, True).bool:
                return JumpPrecalculation.never
            else:
                ctx.asm_out('_jump_unless').append(m_ast.Jump(ctx.freeze(), label, 'always', []))
                return JumpPrecalculation.always
        case ast.UnaryOp(op=ast.Not()):
            # `jump unless not a` => `jump if a`
            return _jump_if(ctx, label, test.operand)
        case ast.BoolOp(op=ast.Or()):
            # `jump unless a or b or c` => `jump if not a and not b and not c`
            a = {"lineno": test.lineno, "col_offset": test.col_offset}
            return _jump_if(ctx, label, ast.BoolOp(**a, op=ast.And(**a), values=[ast.UnaryOp(**a, op=ast.Not(**a), operand=v) for v in test.values]))
        case ast.BoolOp(op=ast.And()):
            # `jump unless a and b and c` => `jump if not a or not b or not c`
            a = {"lineno": test.lineno, "col_offset": test.col_offset}
            return _jump_if(ctx, label, ast.BoolOp(**a, op=ast.Or(**a), values=[ast.UnaryOp(**a, op=ast.Not(**a), operand=v) for v in test.values]))
        case ast.Compare() if len(test.ops) == 1:
            # `jump unless a <=> b` => `jump if a not(<=>) b`
            left = translate_node(ctx, test.left, as_operand=True)
            right = translate_node(ctx, test.comparators[0], as_operand=True)
            asm, t = helper.jump_if_binary_operator(ctx, label, helper.reverse_comparison_operator(ctx, test.ops[0], test.lineno, test.col_offset), left, right)
            ctx.asm_out('_jump_unless').extend(asm)
            return t
        case ast.Compare() if len(test.ops) >= 2:
            # `jump label unless a() <=> b() <=> c() <=> d()` =>
            # ```
            # a2 = a()
            # b2 = b()
            # jump label unless a2 <=> b2
            # c2 = c()
            # jump label unless b2 <=> c2
            # d2 = d()
            # jump label unless c2 <=> d2
            # ```
            never = True
            left = translate_node(ctx, test.left, as_operand=True)
            for op, right_ast in zip(test.ops[:-1], test.comparators[:-1]):
                right = translate_node(ctx, right_ast, as_operand=True)
                asm, t = helper.jump_if_binary_operator(ctx, label, helper.reverse_comparison_operator(ctx, op, test.lineno, test.col_offset), left, right)
                if t == JumpPrecalculation.always:
                    return JumpPrecalculation.always
                if t != JumpPrecalculation.never:
                    never = False
                ctx.asm_out('_jump_unless').extend(asm)
                left = right
            right = translate_node(ctx, test.comparators[-1], as_operand=True)
            asm, t = helper.jump_if_binary_operator(ctx, label, helper.reverse_comparison_operator(ctx, test.ops[-1], test.lineno, test.col_offset), left, right)
            ctx.asm_out('_jump_unless').extend(asm)
            if t != JumpPrecalculation.never:
                never = False
            if never:
                return JumpPrecalculation.never
            return JumpPrecalculation.runtime
        case _:
            # `jump unless a` => `jump a == False`
            ctx.asm_out('_jump_unless').append(m_ast.Jump(ctx.freeze(), label, 'equal', [translate_node(ctx, test, as_operand=True), m_ast.PrimitiveValue(ctx.freeze(), False)]))
            return JumpPrecalculation.runtime


def _import_top_level(ctx: BuildContext, module_name: str) -> m_ast.Scope:
    """Imports a non-dotted module"""
    assert "." not in module_name

    def create_module(filepath: Path, *, skipped: bool):
        module = ctx.scope.add_sub_scope(None, m_ast.Scope(repr_name=module_name, kind=m_ast.Scope.Module(filepath=filepath, processor_name=ctx.scope.processor, skipped_parsing=skipped), local_name_suffix=ctx.get_unique_identifier(module_name)))
        if skipped:
            ctx.modules[filepath] = module
            ctx.modules_initialized.add(filepath)
        return module

    # Find the module from sys.path and the parent directory of the script file
    parent_path: Final = str(Path(ctx.scope.filepath).parent)
    module_spec = importlib.machinery.PathFinder.find_spec(module_name, [*sys.path, parent_path])
    if module_spec is not None:
        if module_spec.origin is None:
            raise ctx.CompileError(f"Could not find a module {module_name}. Please create __init__.py if there aren't.")
        module_path = module_spec.origin  # 'package/__init__.py'

        # Check the cache
        module_path = Path(module_path).resolve().absolute()
        if module_path in ctx.modules:
            return ctx.modules[module_path]

        code: Final = module_path.read_text(encoding='utf-8')

        # Load only files including substring `from minpiler.std`
        if 'minpiler.std' not in code:
            return create_module(module_path, skipped=True)

        module_scope: Final = create_module(module_path, skipped=False)
        sub_context = BuildContext(module_scope, code)
        ctx.copy_to(sub_context)
        ctx.asm_out("_import").extend(translate_file(sub_context, code))
        return module_scope

    # Ignore modules imported by BuiltinImporter and FrozenImporter
    for finder in sys.meta_path:
        module_spec = finder.find_spec(module_name, None)
        if module_spec is not None:
            return create_module(Path("unknown") if module_spec.origin is None else Path(module_spec.origin), skipped=True)
    else:
        raise ctx.CompileError(f'Could not find package "{module_name!r}" from "{parent_path!r}"')


def _import_submodule(ctx: BuildContext, package: m_ast.Scope, submodule_name: str) -> m_ast.Scope:
    """Imports a submodule of a package"""
    assert isinstance(package.kind, m_ast.Scope.Module)

    def create_module(filepath: Path, *, skipped: bool):
        module = package.add_sub_scope(submodule_name, m_ast.Scope(repr_name=submodule_name, kind=m_ast.Scope.Module(filepath=module_path, processor_name=ctx.scope.processor, skipped_parsing=skipped), local_name_suffix=ctx.get_unique_identifier(submodule_name)))
        if skipped:
            ctx.modules[filepath] = module
            ctx.modules_initialized.add(filepath)
        return module

    if package.kind.filepath.name != "__init__.py":
        assert package.kind.skipped_parsing
        raise ctx.CompileError(f"{package} is not a package. Please create __init__.py.")

    module_paths = (
        (package.kind.filepath.parent / submodule_name / "__init__.py").resolve().absolute(),
        ((package.kind.filepath.parent / submodule_name).with_suffix(".py")).resolve().absolute(),
    )
    if module_paths[0].exists():
        module_path = module_paths[0]
    elif module_paths[1].exists():
        module_path = module_paths[1]
    else:
        raise ctx.CompileError(f'Files "{module_paths[0]!r}" and "{module_paths[1]!r}" does not exist.')

    if module_path in ctx.modules:
        return ctx.modules[module_path]

    code: Final = module_path.read_text(encoding='utf-8')

    # Load only files including substring `from minpiler.std`
    if 'minpiler.std' not in code:
        return create_module(module_path, skipped=True)

    module = create_module(module_path, skipped=False)
    sub_context = BuildContext(module, code)
    ctx.copy_to(sub_context)
    ctx.asm_out("_import").extend(translate_file(sub_context, code))
    return module


def _import(ctx: BuildContext, dotted_package_name: str, *, return_rightmost: bool = False) -> m_ast.Scope:
    """
    Provides the same functionality as __import__() (return_rightmost=False) or importlib.importmodule() (return_rightmost=True)
    """
    parts = dotted_package_name.split(".")
    root = _import_top_level(ctx, parts[0])
    rightmost = reduce(lambda p, s: _import_submodule(ctx, p, s), parts[1:], root)
    return rightmost if return_rightmost else root


def _unpack(ctx: BuildContext, targets_: list[ast.Name], value: ast.expr) -> None:
    if len(targets_) == 1 and targets_[0].id in ctx.scope.typedef_declarations:
        # Ignore
        # ```
        # # minpiler.typedef T
        # T = TypeVar("T")
        # ```
        return None

    # Parse the right-hand side
    if any([t.id in ctx.scope.constexpr_declarations for t in targets_]):
        # Parse as a constexpr if there is at least one constexpr target
        with ctx.set(constexpr=True):
            values = translate_node(ctx, value, as_r_values=True)
    else:
        values = translate_node(ctx, value, as_r_values=True)

    # Parse the left-hand side
    targets: list[str | m_ast.LocalName | m_ast.SharedName | None] = []  # constexpr or instance => str, else => Name
    for i, (t, v) in enumerate(zip(targets_, values)):
        if t.id in ctx.scope.typedef_declarations:
            targets.append(None)
        elif t.id in ctx.scope.constexpr_declarations:
            if t.id in ctx.scope.locals_:
                raise ctx.CompileError(f'{t.id} is defined as constexpr and cannot be reassigned')
            targets.append(t.id)
        elif isinstance(v, m_ast.Instance):
            if t.id in ctx.scope.locals_:
                var_type = ctx.scope.get(ctx, t.id)
                if not isinstance(var_type, m_ast.Instance) or var_type != v:
                    raise ctx.CompileError(f'{v!r} is not assignable to variable {t.id} of type {var_type}. Instance reassignments are not allowed.')
            targets.append(t.id)
        else:
            targets.append(ctx.scope.lvalue(ctx, t.id, False))

    # Return if there is no target
    if all(map(lambda t: t is None, targets)):
        return

    # Check the number of elements
    if len(targets) != len(values):
        raise ctx.CompileError(f"The number of targets and values doesn't match: {len(targets)} != {len(values)}")

    # Check if there are swaps, e.g. `a, b, c = b, c, a`
    G = nx.DiGraph()
    for t, v in zip(targets, values):
        if t is None:
            continue
        if isinstance(v, m_ast.LocalName):
            G.add_edge(t, v)
        if isinstance(v, m_ast.ReadonlyName):
            G.add_edge(t, v.name)

    # Insert temporary variables if there are swaps
    cycles: list[list[m_ast.LocalName]] = list(nx.simple_cycles(G))
    if len(cycles) != 0:
        names_in_cycles = {n for c in cycles for n in c}
        for i, v in enumerate(values):
            if isinstance(v, m_ast.LocalName) and v in names_in_cycles:
                tmp = m_ast.LocalName(prefix='unpacking_tmp', processor=ctx.scope.processor, do_not_optimize_out=True)
                helper.assign(ctx, tmp, v)
                values[i] = tmp

    for t, v in zip(targets, values):
        if t is None:
            continue
        if isinstance(v, m_ast.Instance):
            assert isinstance(t, str)
            ctx.scope.set_local(t, v)
        elif isinstance(t, str):
            if not (isinstance(v, m_ast.PrimitiveValue | m_ast.MemoryOf | m_ast.AddressOf) or (isinstance(v, m_ast.LocalName) and v.is_link_name)):
                raise ctx.CompileError(f"{v} is not a constant value and cannot be assigned to a constexpr variable {t}")
            ctx.scope.set_local(t, v)
        else:
            helper.assign(ctx, t, v, merge_names=True)

    return


def _annotate_local_name(ctx: BuildContext, node: ast.AnnAssign):
    match node.annotation:
        case None: pass
        case ast.Attribute(value=ast.Name(id='sync'), attr='SharedInt' | 'SharedFloat' | 'SharedBool'):
            # x: sync.SharedInt
            match node.target:
                case ast.Name(): ctx.scope.lvalue(ctx, node.target.id, is_shared_name=True)
                case _: raise ctx.CompileError(f'{ast.dump(node.target)} cannot be annotated.')
        case ast.Subscript(value=ast.Name(id='ConstExpr')) | ast.Name(id='ConstExpr'):
            # x: ConstExpr[T]
            match node.target:
                case ast.Name(): ctx.scope.constexpr_declarations.add(node.target.id)
                case _: raise ctx.CompileError(f'{ast.dump(node.target)} cannot be annotated.')


def _translate_assign(ctx: BuildContext, target: ast.expr, value: ast.expr) -> Object | None:
    asm = ctx.asm_out('__assign')
    match target:
        case ast.Name():
            _unpack(ctx, [target], value)
            return None
        case ast.Tuple():
            if not all(isinstance(n, ast.Name) for n in target.elts):
                raise ctx.CompileError('targets have to be names')
            _unpack(ctx, [n for n in target.elts if isinstance(n, ast.Name)], value)
            return None
        case ast.Subscript():
            cell = translate_node(ctx, target.value, as_operand=True)
            index_val = translate_node(ctx, target.slice, as_operand=True)
            value_val = translate_node(ctx, value, as_operand=True)
            asm.append(m_ast.Call(ctx.freeze(), 'write', [value_val, cell, index_val], None))
        case ast.Attribute(value=ast.Name(id=value_ident)):
            instance = ctx.scope.get(ctx, value_ident)
            if not isinstance(instance, m_ast.Instance):
                raise ctx.CompileError(f'{instance!r} is not an instance')
            helper.assign(ctx, instance.get_attr(ctx, target.attr), translate_node(ctx, value, as_operand=True))
        case _:
            raise ctx.CompileError(f'Unsupported assignment target {ast.dump(target)}')
    return None


def _translate_decorators(ctx: BuildContext, decorators: list[ast.expr]) -> tuple[str | None, bool, tuple[str, tuple[str, ...]] | None]:
    marker: str | None = None
    is_staticmethod = False
    result: tuple[str, tuple[str, ...]] | None = None

    def get_decorator_name(e: ast.expr):
        f = translate_node(ctx, e)
        if not isinstance(f, m_ast.LocalName | m_ast.InlineFuncDef | m_ast.MacroDef | m_ast.ParameterizedProcessor) or f.marker is None:
            raise ctx.CompileError(f'{f!r} is not a decorator')
        return f.marker

    for d in decorators:
        with ctx.set(node=d, constexpr=True):
            match d:
                case ast.Call(func=ast.Name(id='_builtin')):
                    if marker is not None:
                        raise ctx.CompileError('Multiple @_builtin cannot be applied to an identifier')
                    if d.keywords:
                        raise ctx.CompileError('Keywords are not supported.')
                    if len(d.args) != 1 or not (isinstance(d.args[0], ast.Constant) and isinstance(d.args[0].value, str)):
                        raise ctx.CompileError('Invalid arguments.')
                    marker = d.args[0].value
                case ast.Name(id='staticmethod'):
                    if is_staticmethod:
                        raise ctx.CompileError('Multiple @staticmethod cannot be applied to an identifier')
                    is_staticmethod = True
                case ast.Call(func=ast.Name(id='_overwrite')):
                    pass  # ignore
                case ast.Call():
                    if result is not None:
                        raise ctx.CompileError('Multiple decorators cannot be applied to an identifier')
                    d_args: list[str] = []
                    for a in d.args:
                        d_arg = translate_node(ctx, a, as_operand=True)
                        if not isinstance(d_arg, m_ast.PrimitiveValue) or not isinstance(d_arg.value, str):
                            raise ctx.CompileError(f'{d_arg} is not a string')
                        d_args.append(d_arg.value)
                    result = (get_decorator_name(d.func), tuple(d_args))
                case _:
                    if result is not None:
                        raise ctx.CompileError('Multiple decorators cannot be applied to an identifier')
                    result = (get_decorator_name(d), ())
    return marker, is_staticmethod, result


def _translate_function_def(ctx: BuildContext, node: ast.FunctionDef, is_method: bool = False) -> Object | None:
    if node.name == '_builtin':  # ignore def _builtin
        return None
    marker, is_staticmethod, decorator = _translate_decorators(ctx, node.decorator_list)
    if marker is not None and not decorator:
        ctx.scope.set_local(node.name, m_ast.LocalName(prefix=marker, marker=marker, processor=ctx.scope.processor))
        return None
    if not is_method and is_staticmethod:
        raise ctx.CompileError(f'@staticmethod cannot be applied to a non-method function: {node.name}')

    def check_unsupported_arguments(args: ast.arguments, allow_vararg: bool = False, allow_kwarg: bool = False):
        if args.posonlyargs != []:
            raise ctx.CompileError('posonlyargs are not supported')
        if args.kwonlyargs != []:
            raise ctx.CompileError('kwonlyargs are not supported')
        if args.kw_defaults != []:
            raise ctx.CompileError('kw_defaults are not supported')
        if args.kwarg is not None and not allow_kwarg:
            raise ctx.CompileError('kwarg is not supported')
        if args.defaults != []:
            raise ctx.CompileError('defaults are not supported')
        if args.vararg is not None and not allow_vararg:
            raise ctx.CompileError('vararg is not supported')

    match decorator:
        case ('Processors.add', ()):
            # ======== Processor Definition ========
            if is_method and not is_staticmethod:
                raise ctx.CompileError('Non-inline methods are not supported')
            check_unsupported_arguments(node.args)
            if node.args.args != []:
                raise ctx.CompileError('Processor definition cannot have parameters')
            _add_processor(ctx, m_ast.ParameterizedProcessor(node, ctx.scope, marker=marker), [])
            return None
        case ('Processors.parameterized', ()):
            # ======== Parameterized Processor Definition ========
            if is_method and not is_staticmethod:
                raise ctx.CompileError('Non-inline methods are not supported')
            check_unsupported_arguments(node.args)
            ctx.scope.set_local(node.name, m_ast.ParameterizedProcessor(node, ctx.scope, marker=marker))
            return None

    if isinstance(ctx.scope, m_ast.Scope.InlineFunctionFrame):
        raise ctx.CompileError(f'inline functions can not have inner functions: {node.name!r}')

    match decorator:
        case ('macro', (macro_file, macro_function_name)):
            # ======== Macro Definition ========
            if is_method and not is_staticmethod:
                raise ctx.CompileError('Non-inline methods are not supported')
            check_unsupported_arguments(node.args)
            ctx.scope.set_local(node.name, m_ast.MacroDef(ctx.freeze(), node.args.args, macro_file, macro_function_name, syntactic=False, marker=marker))
            return None
        case ('syntactic_macro', (macro_file, macro_function_name)):
            # ======== Syntactic Macro Definition ========
            if is_method and not is_staticmethod:
                raise ctx.CompileError('Non-inline methods are not supported')
            check_unsupported_arguments(node.args, allow_vararg=True, allow_kwarg=True)
            ctx.scope.set_local(node.name, m_ast.MacroDef(ctx.freeze(), node.args.args, macro_file, macro_function_name, syntactic=True, marker=marker))
            return None
        case ('inline', ()):
            # ======== Inline Function Definition ========
            check_unsupported_arguments(node.args, allow_vararg=True)
            inline_func_def = m_ast.InlineFuncDef(ctx.freeze(), node, ctx.scope, marker=marker)
            if is_method and not is_staticmethod:
                ctx.scope.set_local(node.name, m_ast.MethodWrapper(inline_func_def))
            else:
                ctx.scope.set_local(node.name, inline_func_def)
            return None
        case None:
            # ======== Function Definition ========
            if is_method and not is_staticmethod:
                raise ctx.CompileError('Non-inline methods are not supported')
            check_unsupported_arguments(node.args)
            asm: Final[list[m_ast.Instruction]] = []

            with ctx.set(output=asm):
                n_args = len(node.args.args)
                unique_name = ctx.get_unique_identifier(node.name)
                fdef = m_ast.FuncDef(unique_name, n_args, [m_ast.LocalName(prefix=f'{unique_name}__arg', do_not_optimize_out=True, processor=ctx.scope.processor)
                                                           for _ in range(n_args)], m_ast.Label(ctx.scope.processor), m_ast.LocalName(prefix=f'{unique_name}__return_addr', label_set=set(), processor=ctx.scope.processor))
                ctx.scope.set_local(node.name, fdef)

                end_label = m_ast.Label(ctx.scope.processor)
                asm.append(m_ast.Jump(ctx.freeze(), end_label, 'always', []))  # skip function body
                asm.append(fdef.start_label)

                # with a sub scope
                child_scope = ctx.scope.add_sub_scope(None, m_ast.Scope(repr_name=node.name, kind=m_ast.Scope.FunctionFrame(background=ctx.scope, marker=None, function_definition=fdef), local_name_suffix=ctx.get_unique_identifier(node.name)))
                for a, n in zip(node.args.args, fdef.args):
                    child_scope.set_local(a.arg, n)
                with ctx.set(scope=child_scope):
                    for stmt in node.body:
                        translate_node(ctx, stmt)

                # If the last line of the function body is a return statement, create_return() is not needed.
                return_stmt = fdef.create_return()
                if asm[-1] != return_stmt:
                    asm.append(return_stmt)

                asm.append(end_label)
                fdef.asm = asm

            return None
        case _:
            raise ctx.CompileError(f'Invalid use of a decorator: {decorator!r}')


def _add_processor(ctx: BuildContext, base: m_ast.ParameterizedProcessor, args: list[m_ast.Object]):
    processor_name = ctx.get_unique_identifier(base.expr.name)
    print(f'Compiling processor {processor_name}', file=sys.stderr)
    processor_asm: Final[list[m_ast.Instruction]] = []

    processor_scope = base.scope.add_sub_scope(None, m_ast.Scope(repr_name=processor_name, kind=m_ast.Scope.ProcessorFrame(background=base.scope, processor_name=processor_name, asm=processor_asm), local_name_suffix=''))
    for k, v in zip(base.expr.args.args, args):
        processor_scope.set_local(k.arg, v)

    with ctx.set(scope=processor_scope, output=processor_asm):
        for stmt in base.expr.body:
            translate_node(ctx, stmt)


def _expand_inline_func(ctx: BuildContext, inline_func: m_ast.InlineFuncDef, args: list[m_ast.RValue]) -> m_ast.Object | None:
    function_def = inline_func.function_def
    inline_func_scope = ctx.scope.add_sub_scope(None, m_ast.Scope(repr_name=function_def.name, kind=m_ast.Scope.InlineFunctionFrame(background=inline_func.context_scope, processor_name=ctx.scope.processor), local_name_suffix=ctx.get_unique_identifier(function_def.name)))
    asm = ctx.asm_out('Calling an inline function')

    # Assign values to the parameters
    if function_def.args.vararg is None:
        for param, value in zip(function_def.args.args, args):
            # Optimization:
            # - if the argument is a variable, share the entity with the caller.
            # - if the argument is a primitive value, replace all of the use of the variable with the value.
            match value:
                case m_ast.LocalName():
                    inline_func_scope.set_local(param.arg, m_ast.ReadonlyName(value))
                case m_ast.ReadonlyName() | m_ast.PrimitiveValue() | m_ast.EnumValue() | m_ast.Instance():
                    inline_func_scope.set_local(param.arg, value)
                case _:
                    name = m_ast.LocalName(prefix=param.arg, processor=ctx.scope.processor)
                    inline_func_scope.set_local(param.arg, name)
                    asm.append(m_ast.Call(ctx.freeze(), 'set', [name, value], None))
    else:
        inline_func_scope.set_local(function_def.args.vararg.arg, m_ast.Tuple.wrap(args))

    with ctx.set(scope=inline_func_scope, ctx=inline_func.ctx):
        last_stmt = function_def.body[-1]
        if not isinstance(last_stmt, ast.Return):
            for stmt in function_def.body:
                translate_node(ctx, stmt)
            return None
        else:
            for stmt in function_def.body[:-1]:
                translate_node(ctx, stmt)
            if last_stmt.value is None:
                return None
            else:
                dst = translate_node(ctx, last_stmt.value, as_operands=True)
                return m_ast.Tuple.wrap(dst)


def _translate_class_def(ctx: BuildContext, node: ast.ClassDef) -> Object | None:
    if isinstance(ctx.scope.kind, m_ast.Scope.InlineFunctionFrame):
        raise ctx.CompileError('Inline functions can not have inner classes')

    # Ignore classes with @_builtin
    marker, is_staticmethod, decorator = _translate_decorators(ctx, node.decorator_list)
    if is_staticmethod:
        raise ctx.CompileError('@staticmethod cannot be applied to a class definition')
    if marker is not None:
        ctx.scope.add_sub_scope(node.name, m_ast.Scope(repr_name=node.name, kind=m_ast.Scope.Class(background=ctx.scope, marker=marker), local_name_suffix=ctx.get_unique_identifier(node.name)))
        return None
    if decorator is not None:
        raise ctx.CompileError(f'Unsupported decorator for a function: {decorator!r}')

    if not (node.decorator_list == []):
        raise ctx.CompileError('Decorator lists are not supported')
    if not (node.keywords == []):
        raise ctx.CompileError('Keywords are not supported')

    class_scope = ctx.scope.add_sub_scope(node.name, m_ast.Scope(repr_name=node.name, kind=m_ast.Scope.Class(background=ctx.scope, marker=None), local_name_suffix=ctx.get_unique_identifier(node.name)))
    with ctx.set(scope=class_scope):
        if node.bases == []:
            for stmt in node.body:
                match stmt:
                    case ast.FunctionDef():
                        _translate_function_def(ctx, stmt, is_method=True)
                    case ast.ClassDef():
                        _translate_class_def(ctx, stmt)
                    case ast.Pass():
                        pass
                    case ast.Expr() if isinstance(stmt.value, ast.Constant) and isinstance(stmt.value.value, str):
                        pass  # doc string
                    case _:
                        raise ctx.CompileError(f'Expression {stmt!r} is not supported in class definitions: {ast.dump(stmt)!r}')
        elif len(node.bases) == 1 and isinstance(node.bases[0], ast.Name) and node.bases[0].id == 'Const':
            for stmt in node.body:
                if isinstance(stmt, ast.Assign):
                    if not (len(stmt.targets) == 1):
                        raise ctx.CompileError('the number of targets must be 1')
                    if not (isinstance(stmt.targets[0], ast.Name)):
                        raise ctx.CompileError('the target must be a name')
                    with ctx.set(constexpr=True):
                        class_scope.set_local(stmt.targets[0].id, translate_node(ctx, stmt.value, as_operand=True))
                else:
                    raise ctx.CompileError(f'Expression {stmt!r} is not supported in {node.bases[0].id!r}: {ast.dump(stmt)!r}')
        else:
            raise ctx.CompileError(f'Base classes {[ast.dump(v) for v in node.bases]!r} are not supported.')
    ctx.scope.set_local(node.name, class_scope)
    return None


def _translate_node(ctx: BuildContext, node: ast.AST) -> Object | None:
    """Returns (dst (literal values or variables), assembly code)"""
    with ctx.set(node=node):
        match node:
            case ast.Constant():
                def translate_const():
                    if node.value is not None and not isinstance(node.value, (str, bool, int, float)):
                        raise ctx.CompileError(f'{node.value} is not supported.')
                    return m_ast.PrimitiveValue(ctx.freeze(), node.value)
                return translate_const()
            case ast.Name():
                def translate_name() -> Object | None:
                    if node.id in ctx.scope:
                        return helper.deref(ctx, ctx.scope.get(ctx, node.id))
                    match node.id:
                        case 'print':
                            raise ctx.CompileError(f'''{node.id} is not defined. Use M.print() and M.print_flush() to print a message to a message block.''')
                        case _:
                            raise ctx.CompileError(f'''\
{node.id} is not defined.
If you want to get a reference to a link, prefix "L." to the variable.

```
from minpiler.std import L

L.cell1[1] = 10
```

If you want to define a variable, assign values or `use_float()` to the variable first.

```
from minpiler.std import M, use_float

x = 1
M.print(x)

y = use_float()
if y is None:
y = 1
```
''')
                return translate_name()
            case ast.Tuple():
                def translate_tuple():
                    assert isinstance(node, ast.Tuple)
                    return m_ast.Tuple.wrap(translate_node(ctx, v, as_operand=True) for v in node.elts)
                return translate_tuple()
            case ast.Slice():
                def translate_slice():
                    return m_ast.Slice(slice(
                        None if node.lower is None else helper.as_integer(ctx, translate_node(ctx, node.lower, as_operand=True)),
                        None if node.upper is None else helper.as_integer(ctx, translate_node(ctx, node.upper, as_operand=True)),
                        None if node.step is None else helper.as_integer(ctx, translate_node(ctx, node.step, as_operand=True)),
                    ))
                return translate_slice()
            case ast.Subscript():
                def translate_subscript() -> Object | None:
                    array_val: Final = translate_node(ctx, node.value)
                    if isinstance(array_val, m_ast.Tuple):
                        # tuple.__getitem__
                        index = translate_node(ctx, node.slice)
                        match index:
                            case m_ast.PrimitiveValue(value=(int() | float()) as i) if abs(i - round(i)) < 0.00001:
                                if len(array_val.values) <= i:
                                    raise ctx.CompileError(f'IndexError: {array_val!r}[{i}]')
                                return array_val.values[round(i)]
                            case m_ast.Slice(obj=s):
                                return m_ast.Tuple(array_val.values[s])
                            case _:
                                raise ctx.CompileError(f'{index!r} is not an integer or a slice')
                    else:
                        # Memory access
                        index_val: Final = translate_node(ctx, node.slice, as_operand=True)
                        dst: Final = m_ast.LocalName(prefix="read", processor=ctx.scope.processor)
                        ctx.asm_out('Subscript').append(m_ast.Call(ctx.freeze(), 'read', [dst, helper.as_operand(ctx, array_val), index_val], None))
                        return dst
                return translate_subscript()
            case ast.UnaryOp():
                def translate_unary_op():
                    val: Final = translate_node(ctx, node.operand, as_operand=True)
                    return helper.operator(ctx, *helper.dump_unary_operator(ctx, node.op, val))
                return translate_unary_op()
            case ast.BinOp():
                def translate_bin_op():
                    op_name = helper.dump_binary_operator(ctx, node.op)
                    left_val: Final = translate_node(ctx, node.left, as_operand=True)
                    right_val: Final = translate_node(ctx, node.right, as_operand=True)
                    return helper.operator(ctx, op_name, [left_val, right_val])
                return translate_bin_op()
            case ast.Compare():
                def translate_compare() -> Object | None:
                    # a < b
                    if len(node.ops) == 1:
                        left = translate_node(ctx, node.left, as_operand=True)
                        right = translate_node(ctx, node.comparators[0], as_operand=True)
                        if isinstance(node.ops[0], ast.IsNot):
                            dst = helper.operator(ctx, 'equal', [helper.operator(ctx, 'strictEqual', [left, right]), m_ast.PrimitiveValue(ctx.freeze(), 0)])
                        else:
                            dst = helper.operator(ctx, helper.dump_comparison_operator(ctx, node.ops[0]), [left, right])
                        return dst

                    # a < b < c
                    end_label = m_ast.Label(ctx.scope.processor)
                    dst = m_ast.LocalName(prefix='compare', processor=ctx.scope.processor)
                    left = translate_node(ctx, node.left, as_operand=True)
                    for op, comparator in zip(node.ops, node.comparators):
                        right = translate_node(ctx, comparator, as_operand=True)
                        if isinstance(op, ast.IsNot):
                            helper.operator(ctx, 'equal', [helper.operator(ctx, 'strictEqual', [left, right]), m_ast.PrimitiveValue(ctx.freeze(), 0)], dst=dst)
                        else:
                            helper.operator(ctx, helper.dump_comparison_operator(ctx, op), [left, right], dst=dst)
                        ctx.asm_out('Compare').extend(helper.jump_if_binary_operator(ctx, end_label, ast.Eq(lineno=node.lineno, col_offset=node.col_offset), dst, m_ast.PrimitiveValue(ctx.freeze(), False))[0])
                        left = right
                    ctx.asm_out('Compare').append(end_label)
                    return dst
                return translate_compare()
            case ast.BoolOp():
                def translate_bool_op() -> Object | None:
                    node_eq = ast.copy_location(ast.Eq(), node)
                    node_noteq = ast.copy_location(ast.NotEq(), node)
                    match node.op:
                        case ast.And():
                            op, shortcut_condition = ('land', node_eq)
                        case ast.Or():
                            op, shortcut_condition = ('or', node_noteq)
                        case _:
                            raise ctx.CompileError(f'Unsupported boolean operator {node.op}')
                    end_label: Final = m_ast.Label(ctx.scope.processor)
                    dst: Final = m_ast.LocalName(prefix=op, processor=ctx.scope.processor)

                    val = translate_node(ctx, node.values[0], as_operand=True)
                    asm = ctx.asm_out('BoolOp')
                    asm.append(m_ast.Call(ctx.freeze(), 'set', [dst, val], None))
                    jump_asm, precalculation = helper.jump_if_binary_operator(ctx, end_label, shortcut_condition, val, m_ast.PrimitiveValue(ctx.freeze(), False))
                    if precalculation == JumpPrecalculation.always:
                        return dst
                    asm.extend(jump_asm)

                    bool_value = m_ast.LocalName(prefix=op, processor=ctx.scope.processor)
                    for value in node.values[1:]:
                        val = translate_node(ctx, value, as_operand=True)
                        helper.operator(ctx, op, [dst, val], dst=bool_value)
                        asm.append(m_ast.Call(ctx.freeze(), 'set', [dst, val], None))
                        jump_asm, precalculation = helper.jump_if_binary_operator(ctx, end_label, shortcut_condition, bool_value, m_ast.PrimitiveValue(ctx.freeze(), False))
                        if precalculation == JumpPrecalculation.always:
                            asm.append(end_label)
                            return dst
                        asm.extend(jump_asm)
                    asm.append(end_label)
                    return dst
                return translate_bool_op()
            case ast.Expr():
                def translate_expr():
                    return translate_node(ctx, node.value)
                return translate_expr()
            case ast.AnnAssign():
                def translate_ann_assign() -> Object | None:
                    _annotate_local_name(ctx, node)
                    if node.value is None:
                        return None
                    return _translate_assign(ctx, node.target, node.value)
                return translate_ann_assign()
            case ast.If():
                def translate_if() -> Object | None:
                    end_label: Final = m_ast.Label(ctx.scope.processor)
                    else_label: Final = m_ast.Label(ctx.scope.processor) if node.orelse else end_label

                    asm_cond: Final[list[m_ast.Instruction]] = []
                    with ctx.set(output=asm_cond):
                        t: Final = _jump_unless(ctx, else_label, node.test)

                    asm_body: Final[list[m_ast.Instruction]] = []
                    with ctx.set(output=asm_body):
                        if t != JumpPrecalculation.always:
                            for stmt in node.body:
                                translate_node(ctx, stmt)

                    asm_jump_to_end: Final[list[m_ast.Instruction]] = []
                    with ctx.set(output=asm_jump_to_end):
                        if t == JumpPrecalculation.runtime:
                            asm_jump_to_end.append(m_ast.Jump(ctx.freeze(), end_label, 'always', []))

                    asm_orelse: Final[list[m_ast.Instruction]] = []
                    with ctx.set(output=asm_orelse):
                        if t != JumpPrecalculation.never:
                            for stmt in node.orelse:
                                translate_node(ctx, stmt)

                    # optimize `if ...: M.jump .l`
                    if len(asm_body) == 1 and len(asm_orelse) == 0 and isinstance(asm_body[0], m_ast.Jump) and asm_body[0].op == 'always':
                        _jump_if(ctx, asm_body[0].label, node.test)
                        return None

                    ctx.asm_out('If').extend([*asm_cond, *asm_body, *asm_jump_to_end, else_label, *asm_orelse, end_label])
                    return None
                return translate_if()
            case ast.IfExp():
                def translate_if_exp() -> Object | None:
                    asm = ctx.asm_out('IfExp')
                    else_label: Final = m_ast.Label(ctx.scope.processor)
                    end_label: Final = m_ast.Label(ctx.scope.processor)
                    dst: Final = m_ast.LocalName(prefix='ifexp', processor=ctx.scope.processor)
                    precalculation = _jump_unless(ctx, else_label, node.test)
                    if precalculation == JumpPrecalculation.always:
                        result = translate_node(ctx, node.orelse, as_operand=True)
                        asm.extend([else_label, end_label])
                        return result
                    elif precalculation == JumpPrecalculation.never:
                        result = translate_node(ctx, node.body, as_operand=True)
                        asm.extend([else_label, end_label])
                        return result
                    else:
                        asm.append(m_ast.Call(ctx.freeze(), 'set', [dst, translate_node(ctx, node.body, as_operand=True)], None))
                        asm.append(m_ast.Jump(ctx.freeze(), end_label, 'always', []))
                        asm.append(else_label)
                        asm.append(m_ast.Call(ctx.freeze(), 'set', [dst, translate_node(ctx, node.orelse, as_operand=True)], None))
                        asm.append(end_label)
                        return dst
                return translate_if_exp()
            case ast.While():
                def translate_while() -> Object | None:
                    asm = ctx.asm_out('While')
                    continue_target: Final = m_ast.Label(ctx.scope.processor)
                    else_label: Final = m_ast.Label(ctx.scope.processor)
                    break_target = m_ast.Label(ctx.scope.processor)
                    ctx.scope.break_target_stack.append(break_target)
                    ctx.scope.continue_target_stack.append(continue_target)
                    try:
                        if len(node.body) == 1 and len(node.orelse) == 0 and isinstance(node.body[0], ast.Pass):
                            # Optimize `while ...: pass`
                            asm.append(continue_target)                                                       # continue:
                            _jump_if(ctx, continue_target, node.test)  # goto continue if test
                        else:
                            asm.append(continue_target)                                                       # continue:
                            _jump_unless(ctx, else_label, node.test)   # goto else if not test
                            for stmt in node.body:
                                translate_node(ctx, stmt)
                            asm.append(m_ast.Jump(ctx.freeze(), continue_target, 'always', []))                             # goto continue
                            asm.append(else_label)                                                            # else:
                            for stmt in node.orelse:
                                translate_node(ctx, stmt)
                            asm.append(break_target)                                                          # break:
                    finally:
                        ctx.scope.break_target_stack.pop()
                        ctx.scope.continue_target_stack.pop()

                    return None
                return translate_while()
            case ast.Return():
                def translate_return() -> Object | None:
                    asm = ctx.asm_out('Return')
                    result: Final[list[m_ast.OperandValue]] = []
                    fdef: Final = ctx.scope.get_current_func()
                    if fdef is None:
                        raise ctx.CompileError('Returning outside function context')
                    if node.value is not None:
                        for index, value in enumerate(translate_node(ctx, node.value, as_operands=True)):
                            result.append(value)
                            if index >= len(fdef.resmap):
                                if index != len(fdef.resmap):
                                    raise ctx.CompileError('assertion error')
                                fdef.resmap.append(m_ast.LocalName(prefix='return', do_not_optimize_out=True, processor=ctx.scope.processor))
                            assert isinstance(value, m_ast.OperandValue)
                            asm.append(m_ast.Call(ctx.freeze(), 'set', [fdef.resmap[index], value], None))
                    asm.append(fdef.create_return())
                    return m_ast.Tuple.wrap(result)
                return translate_return()
            case ast.Import():
                def translate_import() -> Object | None:
                    for name in node.names:
                        if name.asname:
                            # import a.b.c as x
                            ctx.scope.set_local(name.asname, _import(ctx, name.name, return_rightmost=True))
                        else:
                            # import a.b.c
                            ctx.scope.set_local(name.name.split(".")[0], _import(ctx, name.name))
                    return None
                return translate_import()
            case ast.ImportFrom():
                def translate_import_from() -> Object | None:
                    if node.module is None:
                        return None
                    module: m_ast.Scope = _import(ctx, node.module, return_rightmost=True)
                    assert isinstance(module.kind, m_ast.Scope.Module)
                    if module.kind.filepath.name != "__init__.py" and module.kind.skipped_parsing:
                        return None
                    for name in node.names:
                        if name.name == '*':
                            raise ctx.CompileError('`import *` is not implemented')
                        if name.name in module:
                            # from ... import variable
                            ctx.scope.set_local(name.asname if name.asname else name.name, module.get(ctx, name.name))
                        else:
                            # from ... import submodule
                            ctx.scope.set_local(name.asname if name.asname else name.name, _import_submodule(ctx, module, name.name))
                    return None
                return translate_import_from()
            case ast.Call():
                def translate_call() -> Object | None:
                    assert isinstance(node, ast.Call)
                    if node.keywords:
                        raise ctx.CompileError('Keyword arguments are not supported')

                    asm = ctx.asm_out('Call')
                    func = translate_node(ctx, node.func)

                    # Functions
                    match func:
                        case m_ast.FuncDef():
                            args = [translate_node(ctx, arg, as_operand=True) for arg in node.args]
                            if any(map(lambda v: isinstance(v, m_ast.EnumValue), args)):
                                raise ctx.CompileError(f'Enum values exists only in compile-time so you can not pass them to non-inline functions.')
                            if len(args) < func.n_args:
                                raise ctx.CompileError(f'Insufficient arguments for function {func.name!r}')
                            for fa, sa in zip(func.args, args):
                                asm.append(m_ast.Call(ctx.freeze(), 'set', [fa, sa], None))
                            return_address = m_ast.Label(ctx.scope.processor)
                            assert func.return_addr.label_set is not None
                            func.return_addr.label_set.add(return_address)
                            asm.append(m_ast.Call(ctx.freeze(), 'set', [func.return_addr, return_address], None))
                            asm.append(m_ast.Jump(ctx.freeze(), func.start_label, 'always', []))
                            asm.append(return_address)

                            return m_ast.Tuple.wrap(func.resmap)

                        # Inline functions
                        case m_ast.InlineFuncDef():
                            return _expand_inline_func(ctx, func, [translate_node(ctx, arg, as_r_value=True) for arg in node.args])

                        # Class.__init__
                        case m_ast.Scope(kind=m_ast.Scope.Class()):
                            init = func.get(ctx, '__init__')
                            if not isinstance(init, m_ast.MethodWrapper):
                                raise ctx.CompileError(f'{init!r} is not a method')
                            instance = m_ast.Instance(func, ctx.get_unique_identifier(func.repr_name))
                            _expand_inline_func(ctx, init.func, [instance, *[translate_node(ctx, arg, as_r_value=True) for arg in node.args]])
                            return instance

                        # Bound method
                        case m_ast.BoundMethod():
                            return _expand_inline_func(ctx, func.func, [func.self_, *[translate_node(ctx, arg, as_r_value=True) for arg in node.args]])

                        # Macros
                        case m_ast.MacroDef():
                            unique_module_name = ctx.get_unique_identifier(func.module_name)

                            # https://stackoverflow.com/a/67692/10710682
                            so = list(func.module_path.parent.glob(f'{glob.escape(func.module_path.name)}.*.so'))
                            if len(so) == 0:
                                spec = importlib.util.spec_from_file_location(unique_module_name, func.module_path.with_suffix(".py"))
                            else:
                                spec = importlib.util.spec_from_file_location(unique_module_name, so[0])

                            if spec is None or spec.loader is None or spec.origin is None:
                                raise ctx.CompileError(f'Failed to import {func.module_path}')
                            origin = Path(spec.origin).resolve().absolute()
                            if origin in ctx.macro_modules:
                                macro_module = ctx.macro_modules[origin]
                            else:
                                macro_module = importlib.util.module_from_spec(spec)
                                spec.loader.exec_module(macro_module)
                                ctx.macro_modules[origin] = macro_module

                            if func.syntactic:
                                macro_fn: Callable[..., Any] = getattr(macro_module, func.function_name)
                                if not callable(macro_fn):
                                    raise ctx.CompileError(f'{macro_fn!r} is not a callable')

                                # Type check arguments
                                args_unchecked = node.args.copy()
                                params = inspect.signature(macro_fn).parameters
                                for param in params.values():
                                    def type_check(arg: ast.expr):
                                        if param.annotation == inspect._empty:  # untyped
                                            return
                                        try:
                                            if not isinstance(arg, cast(Any, param.annotation)):
                                                raise ctx.CompileError(f'Argument {ast.dump(arg)} is incompatible with {param.annotation!r}')
                                        except TypeError:  # catch `TypeError: typing.Any cannot be used with isinstance()`
                                            pass
                                    if param.kind in (inspect._ParameterKind.POSITIONAL_ONLY, inspect._ParameterKind.POSITIONAL_OR_KEYWORD):
                                        try:
                                            arg = args_unchecked.pop(0)
                                        except IndexError:
                                            raise ctx.CompileError(f'An insufficient number of positional arguments were supplied to {func.function_name}: parameters = {params!r}, arguments = {node.args!r}')
                                        type_check(arg)
                                    elif param.kind == inspect._ParameterKind.VAR_POSITIONAL:
                                        while args_unchecked:
                                            arg = args_unchecked.pop(0)
                                            type_check(arg)

                                macro_output_obj: Object | None = macro_fn(*node.args, ctx=ctx)
                                if macro_output_obj is not None and not isinstance(macro_output_obj, Object):
                                    raise ctx.CompileError('Syntactic macros must return a m_ast.Object or None')
                                return macro_output_obj
                            else:
                                constexpr_args: list[float | int | bool | str | None] = []
                                args = [translate_node(ctx, arg, as_operand=True) for arg in node.args]
                                for arg, param in zip(args, func.params):
                                    match param.annotation:
                                        case ast.Subscript(value=ast.Name(id='ConstExpr'), slice=slice):
                                            if not isinstance(arg, m_ast.PrimitiveValue):
                                                raise ctx.CompileError(f'The parameter `{param.arg}` requires a constant expression: {arg!r}')
                                            match slice:
                                                case ast.Name(id='int'):
                                                    if not isinstance(arg.value, int | float):
                                                        raise ctx.CompileError(f'The parameter `{param.arg}` requires an integer: {arg!r}')
                                                    constexpr_args.append(int(arg.value))
                                                case _:
                                                    constexpr_args.append(arg.value)
                                        case _:
                                            constexpr_args.append(None)
                                macro_output_str: str = getattr(macro_module, func.function_name)(*constexpr_args, ctx=ctx.freeze())
                                if not isinstance(macro_output_str, str):
                                    raise ctx.CompileError(f'Macro {func.module_path}#{func.function_name} returned {macro_output_str}')
                                try:
                                    macro_output_str = f'def {func.function_name}({", ".join([a.arg for a in func.params])}):\n{textwrap.indent(macro_output_str, "    ")}'
                                    body = ast.parse(macro_output_str).body
                                except SyntaxError as err:
                                    raise ctx.CompileError(f'Error parsing the macro {func.function_name}():\n{type(err).__name__}: {err}\nThe program generated:\n{macro_output_str}')
                                assert len(body) == 1 and isinstance(body[0], ast.FunctionDef)
                                # FIXME: filepath=ctx.scope.filepath
                                wrapper = ctx.scope.add_sub_scope(None, m_ast.Scope(repr_name=func.function_name, kind=m_ast.Scope.MacroFrame(filepath=ctx.scope.filepath, processor_name=ctx.scope.processor), local_name_suffix=ctx.get_unique_identifier(func.function_name)))
                                return _expand_inline_func(ctx, m_ast.InlineFuncDef(ctx.freeze(), body[0], wrapper), operands_to_rvalues(args))

                        case _:
                            raise ctx.CompileError(f'{func!r} is not a callable.')
                return translate_call()
            case ast.Assign():
                def translate_assign() -> Object | None:
                    if len(node.targets) != 1:
                        raise ctx.CompileError('Only single target can be used in assignment')
                    return _translate_assign(ctx, node.targets[0], node.value)
                return translate_assign()
            case ast.Attribute():
                def translate_attribute() -> Object | None:
                    asm = ctx.asm_out('Attribute')
                    value: Final = translate_node(ctx, node.value)

                    match value:
                        case m_ast.Scope(kind=m_ast.Scope.Class(marker='L')): return m_ast.LocalName(node.attr, processor=ctx.scope.processor, is_link_name=True)
                        case m_ast.Scope(kind=m_ast.Scope.Class(marker='at')): return m_ast.LocalName('@' + node.attr.replace('_', '-'), processor=ctx.scope.processor)
                        case m_ast.Scope(kind=m_ast.Scope.Class(marker='enum')): return m_ast.EnumValue(node.attr)
                        case m_ast.Scope(kind=m_ast.Scope.Class(marker='label')):
                            if node.attr not in ctx.scope.labels:
                                ctx.scope.labels[node.attr] = m_ast.Label(ctx.scope.processor)
                            asm.append(ctx.scope.labels[node.attr])
                            return None
                        case m_ast.Scope(kind=m_ast.Scope.Class(marker='jump')):
                            if node.attr not in ctx.scope.labels:
                                ctx.scope.labels[node.attr] = m_ast.Label(ctx.scope.processor)
                            asm.append(m_ast.Jump(ctx.freeze(), ctx.scope.labels[node.attr], 'always', []))
                            return None
                        case m_ast.Scope():  # value.__dict__.__getitem__
                            if isinstance(value.kind, m_ast.Scope.Module) and node.attr not in value:
                                if value.filepath.resolve().absolute() not in ctx.modules_initialized:
                                    raise ctx.CompileError(f'Partially initialized module {json.dumps(value.repr_name)} has no attribute {json.dumps(node.attr)!r} (most likely due to a circular import)')
                                raise ctx.CompileError(f'Module {json.dumps(value.repr_name)} has no attribute {json.dumps(node.attr)!r}')
                            return value.get(ctx, node.attr)
                        case m_ast.LocalName(marker=str()):
                            raise ctx.CompileError(f'{value!r} does not have the attribute {json.dumps(node.attr)!r}')
                        case m_ast.Instance():
                            if node.attr in value.attributes:
                                # instance.attr
                                return value.get_attr(ctx, node.attr)
                            else:
                                # instance.method
                                class_attribute = value.class_.get(ctx, node.attr)
                                if isinstance(class_attribute, m_ast.MethodWrapper):
                                    # Bind self
                                    return m_ast.BoundMethod(value, class_attribute.func)
                                else:
                                    return class_attribute
                        case _:
                            # <senseable>.<name>
                            if not isinstance(value, m_ast.OperandValue):
                                raise ctx.CompileError(f'{value!r} is not a value')
                            dst: Final = m_ast.LocalName(prefix='sensor', debug=f'{value!r}.{node.attr}', processor=ctx.scope.processor)
                            asm.append(m_ast.Call(ctx.freeze(), 'sensor', [dst, value, m_ast.LocalName('@' + node.attr.replace('_', '-'), processor=ctx.scope.processor)], [m_ast.UseDef.Def, m_ast.UseDef.Use, m_ast.UseDef.Use]))
                            return dst
                return translate_attribute()
            case ast.AugAssign():
                def translate_aug_assign() -> Object | None:
                    asm = ctx.asm_out('AugAssign')
                    match node.op:
                        case ast.Add(): op = 'add'
                        case ast.Sub(): op = 'sub'
                        case ast.Mult(): op = 'mul'
                        case ast.Div(): op = 'div'
                        case ast.FloorDiv(): op = 'idiv'
                        case ast.Mod(): op = 'mod'
                        case ast.Pow(): op = 'pow'
                        case ast.LShift(): op = 'shl'
                        case ast.RShift(): op = 'shr'
                        case ast.BitOr(): op = 'or'
                        case ast.BitXor(): op = 'xor'
                        case ast.BitAnd(): op = 'and'
                        case _: raise ctx.CompileError(f'Unsupported augmented assignment {node.op!r}')
                    match node.target:
                        case ast.Name():
                            operand_val = translate_node(ctx, node.value, as_operand=True)
                            t = ctx.scope.lvalue(ctx, node.target.id, False)
                            if isinstance(t, m_ast.SharedName):
                                read: m_ast.LocalName = helper.deref(ctx, t)
                                asm.append(m_ast.Call(ctx.freeze(), f'op {op}', [read, read, operand_val], [m_ast.UseDef.Def, m_ast.UseDef.Use, m_ast.UseDef.Use]))
                                helper.assign(ctx, t, read)
                                return None
                            else:
                                asm.append(m_ast.Call(ctx.freeze(), f'op {op}', [t, t, operand_val], [m_ast.UseDef.Def, m_ast.UseDef.Use, m_ast.UseDef.Use]))
                                return None
                        case ast.Subscript():
                            cell = translate_node(ctx, node.target.value, as_operand=True)
                            index_val = translate_node(ctx, node.target.slice, as_operand=True)
                            operand_val = translate_node(ctx, node.value, as_operand=True)
                            op_output = m_ast.LocalName(prefix='write', processor=ctx.scope.processor)
                            cell = translate_node(ctx, node.target.value, as_operand=True)
                            asm.extend([
                                m_ast.Call(ctx.freeze(), 'read', [op_output, cell, index_val], None),
                                m_ast.Call(ctx.freeze(), f'op {op}', [op_output, op_output, operand_val], [m_ast.UseDef.Def, m_ast.UseDef.Use, m_ast.UseDef.Use]),
                                m_ast.Call(ctx.freeze(), 'write', [op_output, cell, index_val], None),
                            ])
                            return None
                        case _:
                            raise ctx.CompileError(f'Unsupported assignment target {node.target!r}')
                return translate_aug_assign()
            case ast.For():
                def translate_for() -> Object | None:
                    asm = ctx.asm_out('For')

                    if not isinstance(node.target, ast.Name):
                        raise ctx.CompileError(f'Unsupported loop counter variable {node.target!r}')

                    def expand_body(break_target: m_ast.Label, continue_target: m_ast.Label):
                        ctx.scope.break_target_stack.append(break_target)
                        ctx.scope.continue_target_stack.append(continue_target)
                        try:
                            for stmt in node.body:
                                translate_node(ctx, stmt)
                        finally:
                            ctx.scope.break_target_stack.pop()
                            ctx.scope.continue_target_stack.pop()

                    else_label: Final = m_ast.Label(ctx.scope.processor)
                    break_target = m_ast.Label(ctx.scope.processor)
                    match node.iter:
                        case ast.Call():  # for _ in range(...)
                            call = node.iter
                            match call.func:
                                case ast.Name(id="range"):
                                    if call.keywords != []:
                                        raise ctx.CompileError(f'keyword arguments for range() are not supported.')
                                    args = [translate_node(ctx, a, as_operand=True) for a in call.args]
                                    match len(args):
                                        case 1:
                                            arg_start, arg_stop, arg_step = m_ast.PrimitiveValue(ctx.freeze(), 0), args[0], m_ast.PrimitiveValue(ctx.freeze(), 1)
                                        case 2:
                                            arg_start, arg_stop, arg_step = args[0], args[1], m_ast.PrimitiveValue(ctx.freeze(), 1)
                                        case 3:
                                            arg_start, arg_stop, arg_step = args
                                        case _:
                                            raise ctx.CompileError(f'range() takes 1-3 arguments but {len(args)} were passed')

                                    for_range_iter = m_ast.LocalName(prefix='for_range_iter', processor=ctx.scope.processor)
                                    asm.append(m_ast.Call(ctx.freeze(), 'set', [for_range_iter, arg_start], None))                            # for_range_iter = {{start}}
                                    if isinstance(arg_stop, m_ast.PrimitiveValue):
                                        stop = arg_stop
                                    else:
                                        stop = m_ast.LocalName(prefix='stop', processor=ctx.scope.processor)
                                        asm.append(m_ast.Call(ctx.freeze(), 'set', [stop, arg_stop], None))                                       # stop = {{stop}}
                                    if isinstance(arg_step, m_ast.PrimitiveValue):
                                        step = arg_step
                                    else:
                                        step = m_ast.LocalName(prefix='step', processor=ctx.scope.processor)
                                        asm.append(m_ast.Call(ctx.freeze(), 'set', [step, arg_step], None))                                       # step = {{step}}
                                    loop_label = m_ast.Label(ctx.scope.processor)
                                    asm.append(loop_label)                                                                # loop:
                                    target = ctx.scope.lvalue(ctx, node.target.id, False)
                                    helper.assign(ctx, target, for_range_iter)  # target = for_range_iter

                                    incr = m_ast.Label(ctx.scope.processor)
                                    incr_end = m_ast.Label(ctx.scope.processor)
                                    asm2, _ = helper.jump_if_binary_operator(ctx, incr, ast.Gt(lineno=node.lineno), step, m_ast.PrimitiveValue(ctx.freeze(), 0))  # if (step > 0) goto incr
                                    asm.extend(asm2)
                                    asm2, _ = helper.jump_if_binary_operator(ctx, else_label, ast.LtE(lineno=node.lineno), helper.deref(ctx, target), stop)
                                    asm.extend(asm2)
                                    asm.append(m_ast.Jump(ctx.freeze(), incr_end, 'always', []))                                             # goto incr_end
                                    asm.append(incr)                                                                      # incr:
                                    asm.append(m_ast.Jump(ctx.freeze(), else_label, 'greaterThanEq', [helper.deref(ctx, target), stop]))                   # if (target >= stop) goto else
                                    asm.append(incr_end)                                                                       # incr_end:

                                    continue_target = m_ast.Label(ctx.scope.processor)
                                    expand_body(break_target, continue_target)                                            # {{body}}
                                    asm.append(continue_target)                                                           # continue:
                                    asm.append(m_ast.Call(ctx.freeze(), 'op add', [for_range_iter, for_range_iter, step], [m_ast.UseDef.Def, m_ast.UseDef.Use, m_ast.UseDef.Use]))              # pre_target_val += step
                                    asm.append(m_ast.Jump(ctx.freeze(), loop_label, 'always', []))                                      # goto loop
                                    asm.append(else_label)                                                                # else:
                                    for stmt in node.orelse:
                                        translate_node(ctx, stmt)
                                    asm.append(break_target)                                                              # break:

                                case ast.Name(id="unrolled"):
                                    if call.keywords != []:
                                        raise ctx.CompileError(f'Keyword arguments for unrolled() are not supported.')
                                    match call.args:
                                        case [ast.Call(func=ast.Name(id='range'), args=args, keywords=keywords)]:
                                            if keywords != []:
                                                raise ctx.CompileError(f'Keyword arguments are not supported.')
                                            if not (1 <= len(args) <= 3):
                                                raise ctx.CompileError(f'The number of arguments of range() in unrolled() must be 1-3')
                                            with ctx.set(constexpr=True):
                                                args_evaluated = [translate_node(ctx, arg) for arg in args]
                                            args_evaluated_literal: list[int] = []
                                            for x in args_evaluated:
                                                args_evaluated_literal.append(helper.as_integer(ctx, x))
                                            iterator = range(*args_evaluated_literal)
                                            if len(iterator) > 1000:
                                                raise ctx.CompileError(f'The number of elements in the iterator to be unrolled is too large: len = {len(iterator)}')
                                            # TODO: mark `expr.target.id` and force it to be unique

                                            for i in iterator:
                                                continue_target = m_ast.Label(ctx.scope.processor)
                                                ctx.scope.unrolled_local_stack.append((node.target.id, m_ast.PrimitiveValue(ctx.freeze(), i)))
                                                expand_body(break_target, continue_target)                                            # {{body}}
                                                ctx.scope.unrolled_local_stack.pop()
                                                asm.append(continue_target)                                                           # continue:

                                            asm.append(else_label)                                                                # else:
                                            for stmt in node.orelse:
                                                translate_node(ctx, stmt)
                                            asm.append(break_target)
                                        case [(ast.Tuple() | ast.List()) as t]:
                                            values = [translate_node(ctx, item, as_operand=True) for item in t.elts]
                                            if not values:
                                                raise ctx.CompileError('Tuple must not be empty')

                                            for i in values:
                                                continue_target = m_ast.Label(ctx.scope.processor)
                                                ctx.scope.unrolled_local_stack.append((node.target.id, i))
                                                expand_body(break_target, continue_target)                                            # {{body}}
                                                ctx.scope.unrolled_local_stack.pop()
                                                asm.append(continue_target)                                                           # continue:

                                            asm.append(else_label)                                                                # else:
                                            for stmt in node.orelse:
                                                translate_node(ctx, stmt)
                                            asm.append(break_target)
                                        case _:
                                            raise ctx.CompileError(f'The argument of unrolled() must be a range() or a tuple or a list.')
                                case _:
                                    raise ctx.CompileError(f'Unsupported iterator {ast.dump(call)}')
                            return None
                        case ast.Tuple() | ast.List():  # for _ in [...]
                            raise ctx.CompileError(f'Support for `for` loops over a tuple or a list is dropped as it was hard to optimize. Instead, define a function and call it multiple times with different arguments.')
                        case _:  # def (*args): for x in args: ...
                            value = translate_node(ctx, node.iter)
                            if not isinstance(value, m_ast.Tuple):
                                raise ctx.CompileError(f'Unsupported iterator {value!r}')
                            # unroll
                            for v in value.values:                                                                   # {{% for arg in args %}}
                                unrolled_continue_target: Final = m_ast.Label(ctx.scope.processor)
                                ctx.scope.set_local(node.target.id, m_ast.ReadonlyName(v) if isinstance(v, m_ast.LocalName) else v)  # target = arg
                                expand_body(break_target, unrolled_continue_target)                                  # {{body}}
                                asm.append(unrolled_continue_target)                                                 # unrolled_continue:
                                # {{% endfor %}}
                            for stmt in node.orelse:
                                translate_node(ctx, stmt)
                            asm.append(break_target)                                                                 # break:
                            return None
                return translate_for()
            case ast.Pass():
                return None
            case ast.FunctionDef():
                return _translate_function_def(ctx, node)
            case ast.ClassDef():
                return _translate_class_def(ctx, node)
            case ast.Nonlocal():
                def translate_nonlocal() -> Object | None:
                    if isinstance(ctx.scope.kind, m_ast.Scope.Module | m_ast.Scope.MacroFrame):
                        raise ctx.CompileError(f'Nonlocal declaration not allowed at {ctx.scope.kind.__class__.__name__.lower()} level')
                    for name in node.names:
                        ctx.scope.kind.nonlocals.add(name)
                    return None
                return translate_nonlocal()
            case ast.Global():
                def translate_global() -> Object | None:
                    if isinstance(ctx.scope.kind, m_ast.Scope.Module | m_ast.Scope.MacroFrame):
                        raise ctx.CompileError(f'Global declaration not allowed at {ctx.scope.kind.__class__.__name__.lower()} level')
                    for name in node.names:
                        ctx.scope.kind.globals.add(name)
                    return None
                return translate_global()
            case ast.JoinedStr():
                raise ctx.CompileError('f-strings can only be used as arguments of M.print(). asm(), and ident().')
            case ast.Break():
                def translate_break() -> Object | None:
                    if len(ctx.scope.break_target_stack) == 0:
                        raise ctx.CompileError('break statements can not be used here')
                    ctx.asm_out('Break').append(m_ast.Jump(ctx.freeze(), ctx.scope.break_target_stack[-1], 'always', []))
                    return None
                return translate_break()
            case ast.Continue():
                def translate_continue() -> Object | None:
                    if len(ctx.scope.break_target_stack) == 0:
                        raise ctx.CompileError('continue statements can not be used here')
                    ctx.asm_out('Continue').append(m_ast.Jump(ctx.freeze(), ctx.scope.continue_target_stack[-1], 'always', []))
                    return None
                return translate_continue()
            case ast.Match():
                def translate_match() -> Object | None:
                    jumps: Final[list[m_ast.Instruction]] = []
                    bodies: Final[list[m_ast.Instruction]] = []
                    with ctx.set(output=jumps):
                        subject = translate_node(ctx, node.subject, as_operand=True)
                    end_label = m_ast.Label(ctx.scope.processor)
                    for case in node.cases:
                        def flatten_pattern(pattern: ast.pattern) -> list[ast.MatchValue | ast.MatchAs | ast.MatchSingleton]:
                            """MatchOr(A, MatchOr(B, C)) -> [A, B, C]"""
                            match pattern:
                                case ast.MatchValue():
                                    return [pattern]
                                case ast.MatchAs():
                                    return [pattern]
                                case ast.MatchOr():
                                    return [match_value for child in pattern.patterns for match_value in flatten_pattern(child)]
                                case ast.MatchSingleton():
                                    return [pattern]
                                case _:
                                    raise ctx.CompileError(f'Unsupported pattern: {ast.dump(case.pattern)}')

                        if case.guard is not None:
                            raise ctx.CompileError(f'guard is not supported: {ast.dump(case.guard)}')

                        label = m_ast.Label(ctx.scope.processor)
                        always_matches = False
                        can_match = False
                        for value in flatten_pattern(case.pattern):
                            match value:
                                case ast.MatchValue() | ast.MatchSingleton():
                                    if isinstance(value, ast.MatchValue):
                                        with ctx.set(output=jumps):
                                            x = translate_node(ctx, value.value, as_operand=True)
                                    else:
                                        x = m_ast.PrimitiveValue(ctx.freeze(), value.value)  # True | False | None
                                    asm2, precalculation = helper.jump_if_binary_operator(ctx, label, ast.Is(lineno=case.pattern.lineno), subject, x)
                                    jumps.extend(asm2)
                                    can_match = can_match or (precalculation != JumpPrecalculation.never)
                                    always_matches = always_matches or (precalculation == JumpPrecalculation.always)
                                case ast.MatchAs():
                                    if value.name is not None or value.pattern is not None:
                                        raise ctx.CompileError(f'Unsupported pattern: {ast.dump(case.pattern)}')
                                    jumps.append(m_ast.Jump(ctx.freeze(), label, 'always', []))  # `case _:`
                                    can_match = True
                                    always_matches = True
                                case _:
                                    raise LogicError
                        if can_match:
                            bodies.append(label)
                            with ctx.set(output=bodies):
                                for stmt in case.body:
                                    translate_node(ctx, stmt)
                            bodies.append(m_ast.Jump(ctx.freeze(), end_label, 'always', []))
                        if always_matches:
                            break
                    else:
                        jumps.append(m_ast.Jump(ctx.freeze(), end_label, 'always', []))
                    ctx.asm_out('Match').extend([*jumps, *bodies, end_label])
                    return None

                return translate_match()
        raise ctx.CompileError(f'Unsupported statement {node!r}')


@overload
def translate_node(ctx: BuildContext, node: ast.AST, *, as_operand: Literal[True]) -> OperandValue: ...


@overload
def translate_node(ctx: BuildContext, node: ast.AST, *, as_operands: Literal[True]) -> list[OperandValue]: ...


@overload
def translate_node(ctx: BuildContext, node: ast.AST, *, as_r_value: Literal[True]) -> m_ast.RValue: ...


@overload
def translate_node(ctx: BuildContext, node: ast.AST, *, as_r_values: Literal[True]) -> list[m_ast.RValue]: ...


@overload
def translate_node(ctx: BuildContext, node: ast.AST) -> Object | None: ...


def translate_node(ctx: BuildContext, node: ast.AST, *, as_operand: bool = False, as_operands: bool = False, as_r_value: bool = False, as_r_values: bool = False):
    """Translate an AST node in Python into an AST node in the intermediate language (m_ast)."""
    with ctx.set(node=node):
        if as_operand:
            return helper.as_operand(ctx, _translate_node(ctx, node))
        elif as_operands:
            return helper.as_operands(ctx, _translate_node(ctx, node))
        elif as_r_value:
            return helper.as_r_value(ctx, _translate_node(ctx, node))
        elif as_r_values:
            return helper.as_r_values(ctx, _translate_node(ctx, node))
        else:
            return _translate_node(ctx, node)


def translate_file(ctx: BuildContext, code: str) -> list[Instruction]:
    """
    Translate a Python file into an intermediate language instructions.
    This function returns only the instructions corresponding to the global statements.
    """
    ctx.modules[ctx.scope.filepath] = ctx.scope
    try:
        for typename in re.findall(r'#\s?minpiler.typedef (\w+)', code):
            ctx.scope.typedef_declarations.add(typename)
            ctx.scope.set_local(typename, m_ast.Typename())

        # import builtins
        if '# minpiler.nobuiltins' not in code:
            builtins_module = _import(ctx, 'minpiler.std._builtins', return_rightmost=True)
            assert builtins_module is not None
            for name in "abs,divmod,pow,max,min,float,int,bool".split(","):
                ctx.scope.set_local(name, builtins_module.get(ctx, name))

        for stmt in ast.parse(code, str(ctx.scope.filepath.resolve().absolute())).body:
            with ctx.set(node=stmt):
                translate_node(ctx, stmt)

        return ctx.asm_out("translate").collect()
    finally:
        ctx.modules_initialized.add(ctx.scope.filepath.resolve().absolute())


class Result(dict[str, m_ast.Dump]):
    def __str__(self):
        if len(self) == 1:
            return str(self['__main__'])
        t = ''
        for k, v in self.items():
            t += f'# Processor {json.dumps(k)}\n{v}\n'
        return t

    def print_stat(self):
        t = ''
        for k, v in self.items():
            memory_builds = {l for l in m_ast.list_memory_names(v.instructions)}
            if memory_builds:
                t += f'- {k}: {memory_builds}\n'
        if t != '':
            print(f'Memory blocks:\n{t}', file=sys.stderr)


def build(code: str, filepath: Path, use_emulator_instructions: bool, optimize: Callable[[FrozenBuildContext, list[Instruction]], list[Instruction]]) -> Result:
    global_scope = m_ast.Scope(repr_name="__main__", kind=m_ast.Scope.Module(filepath=filepath.resolve().absolute(), processor_name="__main__", skipped_parsing=False), local_name_suffix='')

    # Transform Python scripts to list[m_ast.Instruction]
    program: dict[str, list[m_ast.Instruction]] = defaultdict(lambda: [], {'__main__': translate_file(BuildContext(global_scope, code), code)})
    for k, v in global_scope.collect_subprocessor_code().items():
        program[k] += v
    # print(global_scope.print_tree())

    # Transform list[m_ast.Instruction] to str with Dump()
    print("Optimizing...", file=sys.stderr)
    memory_names = {mem for instructions in program.values() for mem in m_ast.list_memory_names(instructions)}

    # optimize the program
    program = {k: optimize(FrozenBuildContext(k, Path("[[optimizer]]"), 0, None), v) for k, v in program.items()}
    for k, v in program.items():
        m_ast.allocate_memory_addresses(v, memory_names)
    program = {k: optimize(FrozenBuildContext(k, Path("[[optimizer]]"), 0, None), v) for k, v in program.items()}  # optimize again

    return Result({
        k: m_ast.Dump(v, use_emulator_instructions, k)
        for k, v in program.items()
    })
