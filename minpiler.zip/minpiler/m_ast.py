"""
m_ast is a module that defines classes to be used for intermediate representations of the compilation process.
The intermediate representation of the program is list[Instruction] = list[Call | Label | Jump], and after the entire program is converted to the intermediate representation, it is converted to assembly code by the Dump class.
`OperandValue` is used for the arguments of the Call, Label, or Jump class, and are also converted into pieces of assembly code by the Dump class.
`Object` is a superset of OperandValue and contains data structures that exist only at compile time.
"""

from __future__ import annotations

import ast
import contextlib
import dataclasses
import enum
import itertools
import json
import logging
import re
import typing
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType

from minpiler import emulator


class CompileError(Exception):
    def __init__(self, message: str, filepath: Path | None, lineno: int | None, code: str | None):
        super().__init__(message)
        self.message = f'{message}\n  in "{filepath.resolve().absolute() if filepath is not None else "unknown"}", ' + (f'line {lineno}' if lineno is not None else '')
        self.stack: list[tuple[Path | None, int | None]] = [(filepath, lineno)]
        self.peek: str | None = None

        if code is not None and filepath is not None and lineno is not None:
            self.peek = '----------------\n'
            self.peek += '\n'.join(code.split('\n')[lineno - 1:lineno])
            if len(self.peek) > 200:
                self.peek = self.peek[:200] + '...'
            self.peek += '\n----------------'

    def __str__(self):
        return self.message + '\n' + (self.peek or '')


class LogicError(Exception):
    pass


@dataclass(frozen=True)
class FrozenBuildContext:
    processor: str
    filepath: Path
    __lineno: int
    code: str | None

    def CompileError(self, msg: str):
        return CompileError(msg, self.filepath, self.__lineno, self.code)


class BuildContext:
    class AssemblyOutput:
        """
        Defer throwing the error until it is actually needed
        """

        def __init__(self, out: CompileError | list[Instruction]) -> None:
            self.__out = out

        def append(self, x: Instruction):
            if isinstance(self.__out, CompileError):
                raise self.__out
            self.__out.append(x)

        def extend(self, x: typing.Iterable[Instruction]):
            if isinstance(self.__out, CompileError):
                raise self.__out
            self.__out.extend(x)

        def last(self):
            if isinstance(self.__out, CompileError):
                raise self.__out
            return self.__out[-1]

        def collect(self):
            if isinstance(self.__out, CompileError):
                raise self.__out
            return self.__out.copy()

    def __init__(self, scope: Scope, code: str) -> None:
        # Variables shared between files
        self.get_unique_identifier: GetUniqueIdentifier = GetUniqueIdentifier()
        self.modules: dict[Path, Scope] = {}  # sys.modules
        self.modules_initialized: set[Path] = set()  # variable to find circular imports
        self.macro_modules: dict[Path, ModuleType] = {}  # sys.modules for macros

        # Variables independent for each file
        self.__scope = scope
        self.__asm_out: list[Instruction] | None = []  # None if constexpr
        self.__node: ast.AST | None = None
        self.__code = code

    def copy_to(self, x: BuildContext):
        x.get_unique_identifier = self.get_unique_identifier
        x.modules = self.modules
        x.macro_modules = self.macro_modules

    def freeze(self) -> FrozenBuildContext:
        return FrozenBuildContext(self.scope.processor, self.scope.filepath, self.__node.lineno if self.__node is not None else 0, self.__code)

    @property
    def scope(self) -> Scope: return self.__scope

    def CompileError(self, msg: str):
        return CompileError(msg, self.scope.filepath, self.__node.lineno if self.__node is not None else 0, self.__code)

    def asm_out(self, usage: str):
        return BuildContext.AssemblyOutput(self.CompileError(f'{usage} is not allowed in a constant expression') if self.__asm_out is None else self.__asm_out)

    @contextlib.contextmanager
    def set(self, *, output: list[Instruction] | None = None, constexpr: bool = False, scope: Scope | None = None, node: ast.AST | None = None, ctx: FrozenBuildContext | None = None):
        if getattr(node, "lineno", None) is None:
            node = None
        x = self.__asm_out, self.scope, self.__node, self.__code
        if output is not None:
            self.__asm_out = output
        if constexpr:
            self.__asm_out = None
        if scope is not None:
            self.__scope = scope
        if node is not None:
            self.__node = node
        if ctx is not None:
            self.__code = ctx.code
            assert ctx.filepath == self.scope.filepath, f'{ctx.filepath} != {self.scope.filepath}'
            if node is None:
                self.__node = None
        try:
            yield
        except CompileError as err:
            _, parent_scope, parent_node, _ = x
            if parent_node is not None:
                last_filename, last_lineno = err.stack[-1]
                if last_filename != parent_scope.filepath or last_lineno != parent_node.lineno:
                    err.message += f'\n  in "{parent_scope.filepath.resolve().absolute()}", line {parent_node.lineno}'
                    err.stack.append((parent_scope.filepath, parent_node.lineno))
            raise err
        finally:
            self.__asm_out, self.__scope, self.__node, self.__code = x


class PrimitiveValue:
    def __init__(self, ctx: FrozenBuildContext, value: float | int | bool | str | None) -> None:
        self.value = value
        match value:
            case None: self.__str = 'null'
            case False: self.__str = 'false'
            case True: self.__str = 'true'
            case int() | float(): self.__str = str(self.value)
            case str(): self.__str = '"' + ''.join(map(lambda char: '\\n' if char == '\n' else char, value)) + '"'
            case _: raise ctx.CompileError(f'Unsupported constant {self.value!r}')

    def __repr__(self): return f'PrimitiveValue(value={json.dumps(self.value)})'
    def __str__(self): return self.__str


@dataclass(frozen=True)
class Tuple:
    """
    () == None
    (x,) == x
    PrimitiveValue(None) != None
    """

    @staticmethod
    def wrap(values: typing.Iterable[RValue]) -> RValue | Tuple:
        values = tuple(values)
        if len(values) == 1:
            return values[0]
        else:
            return Tuple(tuple(values))

    values: tuple['RValue', ...]

    def __post_init__(self):
        assert len(self.values) != 1


@dataclass(frozen=True)
class EnumValue:
    """Inline functions only"""
    value: str

    def __str__(self):
        return self.value


@dataclass
class SharedName:
    """
    A variable shared between processors.
    SharedName() instances will be replaced by their addresses in __dump_argument().
    """
    _: dataclasses.KW_ONLY
    prefix: str
    memory: 'LocalName' | None = None
    index: int | None = None

    def __eq__(self, other: SharedName) -> bool: # type: ignore
        if not isinstance(other, SharedName):
            raise TypeError(f'{other} is not a SharedName')
        assert (self.memory is None and self.index is None) or (self.memory is not None and self.index is not None)
        if self.index is None:
            return self is other
        else:
            return self.memory == other.memory and self.index == other.index

    def __hash__(self) -> int:
        return id(self)

    def __eq__(self, other: SharedName) -> int:
        return self is other


@dataclass
class MemorySlice:
    """
    A pair of a memory build and its addresses.
    """
    size: int
    _: dataclasses.KW_ONLY
    memory: 'LocalName' | None = None
    index: int | None = None


@dataclass
class Slice:
    obj: slice


@dataclass
class MemoryOf:
    name: SharedName | MemorySlice
    _: dataclasses.KW_ONLY
    processor: str


@dataclass
class AddressOf:
    ctx: FrozenBuildContext
    name: SharedName | MemorySlice
    _: dataclasses.KW_ONLY
    processor: str


@dataclass
class LocalName:
    # if None be named automatically as f'_{escape(self.prefix)}{count}'
    name: str | None = None
    prefix: str = 'r'
    do_not_optimize_out: bool = False  # prevent `def f(): return 1; a = f()` from being optimized to `def f(): a = 1; f()`
    debug: str | None = None
    marker: str | None = None  # a name defined with @_builtin('<marker>') has a marker `<marker>`.
    label_set: set[Label] | None = None  # If self.label_set is not None, then only labels can be assigned to this name, and the label must be an item of self.label_set.
    _: dataclasses.KW_ONLY
    processor: str
    is_link_name: bool = False

    def __repr__(self) -> str:
        args = 'prefix=' + json.dumps(self.prefix) if self.name is None else json.dumps(self.name)
        if self.do_not_optimize_out:
            args += ', do_not_optimize_out=True'
        if self.debug is not None:
            args += f', debug={self.debug}'
        if self.marker is not None:
            args += f', marker={self.marker}'
        if self.is_link_name:
            args += f', is_link_name={self.is_link_name}'
        return f'LocalName({args}, processor={self.processor})'

    def __hash__(self) -> int:
        if self.name is None:
            return hash((1, id(self)))
        else:
            return hash((0, self.name, self.processor))

    def __eq__(self, other: LocalName) -> bool:
        if not isinstance(other, LocalName):
            raise TypeError(f'{other} is not a LocalName')
        if self.name is None:
            return self is other
        else:
            return self.name == other.name and self.processor == other.processor


@dataclass(frozen=True)
class Typename:
    pass


@dataclass(frozen=True)
class ReadonlyName:
    """
    r-value reference variables, e.g. arguments of inline functions, or targets of for loops
    """
    name: LocalName

    def __repr__(self) -> str:
        return f'readonly {self.name!r}'


class Label:
    """
    Label() represents a label used to specify a jump destination. It will eventually be replacedby the corresponding number of lines.
    """

    def __init__(self, processor: str) -> None:
        self.processor = processor
        self.line: int | None = None

    def __repr__(self) -> str:
        return f'Label(processor="{self.processor}", id="{hex(id(self))[2:]}")' if self.line is None else f'Label(line={self.line})'

    def __hash__(self):
        return id(self)


@dataclass(frozen=True)
class Instance:
    class_: Scope
    local_name_prefix: str
    attributes: dict[str, LocalName] = field(default_factory=dict)

    def __repr__(self):
        return f'class instance {json.dumps(self.local_name_prefix)}'

    def __post_init__(self):
        assert isinstance(self.class_.kind, Scope.Class)

    def get_attr(self, ctx: BuildContext, attr: str):
        if attr not in self.attributes:
            self.attributes[attr] = LocalName(prefix=ctx.get_unique_identifier(f'{self.local_name_prefix}__{attr}'), processor=ctx.scope.processor)
        return self.attributes[attr]


OperandValue = PrimitiveValue | LocalName | ReadonlyName | EnumValue | Label | AddressOf | MemoryOf
RValue = PrimitiveValue | LocalName | ReadonlyName | EnumValue | Label | AddressOf | MemoryOf | Instance


class ProcessorNameAndFilepath(typing.Protocol):
    processor: str
    filepath: Path


class UseDef(enum.Enum):
    """https://en.wikipedia.org/wiki/Use-define_chain"""
    Use = enum.auto()  # The value of the variable will be used, but the value of the variable will not change.
    Def = enum.auto()  # The value of the variable may change.


class Call:
    @typing.overload
    def __init__(self, ctx: FrozenBuildContext, op: typing.Literal['set', 'write', 'read'], args: list[OperandValue], use_def: None) -> None:
        """automatically fill in the use_def parameter"""
        ...

    @typing.overload
    def __init__(self, ctx: FrozenBuildContext, op: str, args: list[OperandValue], use_def: list[UseDef]) -> None:
        ...

    def __init__(self, ctx: FrozenBuildContext, op: str, args: list[OperandValue], use_def: list[UseDef] | None) -> None:
        if use_def is None:
            match op:
                case 'set': use_def = [UseDef.Def, UseDef.Use]
                case 'write': use_def = [UseDef.Use, UseDef.Use, UseDef.Use]
                case 'read': use_def = [UseDef.Def, UseDef.Use, UseDef.Use]
                case _: raise LogicError

        assert len(args) == len(use_def)

        if op == 'set' and isinstance(args[0], LocalName) and args[0] == LocalName('@counter', processor=ctx.processor):
            raise ctx.CompileError('`set @counter ...` is not allowed because it makes optimization difficult')
        if any(map(lambda a: isinstance(a, EnumValue), args)):
            raise ctx.CompileError('EnumValue is not a value. It can only be used inside f-strings.')

        self.use_def: typing.Final = use_def
        self.op: typing.Final = op
        self.args = args

        for arg in self.args:
            if isinstance(arg, Label) and arg.processor != ctx.processor:
                raise ctx.CompileError(f'Inter-processor jumps are not supported')

    def __repr__(self):
        return f'Call({self.op!r}, {self.args!r})'


class Jump:
    def __init__(self, ctx: FrozenBuildContext, label: Label, op: str, args: list[OperandValue]) -> None:
        self.label: typing.Final = label
        self.op: typing.Final = op
        self.args = args

        for arg in (self.label, *self.args):
            if isinstance(arg, Label) and arg.processor != ctx.processor:
                raise ctx.CompileError(f'Inter-processor jumps are not supported')

    def __repr__(self): return f'Jump({self.label!r}, {self.op!r}, {self.args!r})'


class LongJump:
    """
    `set @counter <label>`
    """
    arg: Label | LocalName

    def __init__(self, arg: Label | LocalName | ReadonlyName) -> None:
        self.set_argument(arg)

    def set_argument(self, arg: Label | LocalName | ReadonlyName):
        match arg:
            case Label():
                self.arg = arg
            case LocalName():
                assert arg.label_set is not None
                self.arg = arg
            case ReadonlyName():
                assert arg.name.label_set is not None
                self.arg = arg.name
            case _:
                raise LogicError

    @property
    def label_set(self) -> set[Label]:
        match self.arg:
            case Label():
                return {self.arg}
            case LocalName():
                assert self.arg.label_set is not None
                return self.arg.label_set
            case ReadonlyName():
                assert self.arg.name.label_set is not None
                return self.arg.name.label_set
            case _:
                raise LogicError

    def __repr__(self): return f'LongJump({self.arg!r})'


Instruction = Call | Label | Jump | LongJump


@dataclass
class FuncDef:
    # immutable
    name: str
    n_args: int
    args: list[LocalName]
    start_label: Label
    return_addr: LocalName
    resmap: list[LocalName] = field(default_factory=list)

    # mutable
    asm: list[Instruction] = field(default_factory=list)
    referenced: bool = False  # output the code only when the function is referenced

    def create_return(self):
        return LongJump(self.return_addr)

    def __repr__(self) -> str:
        return f'FuncDef({json.dumps(self.name)})'


class FunctionNodeVisitor(ast.NodeVisitor):
    def __init__(self, f: typing.Callable[[ast.AST], None]) -> None:
        super().__init__()
        self.f = f

    def visit(self, node: ast.AST):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            return
        self.f(node)
        super().generic_visit(node)


class InlineFuncDef:
    def __init__(self, ctx: FrozenBuildContext, function_def: ast.FunctionDef, context_scope: Scope, marker: str | None = None):
        self.function_def: typing.Final = function_def
        self.context_scope: typing.Final = context_scope
        self.ctx = ctx
        self.marker = marker

        def assert_no_return(node: ast.AST):
            if isinstance(node, ast.Return):
                raise ctx.CompileError(f'Inline functions may have at most one return statement and the return statement must be at the end of the function body.')

        for stmt in self.function_def.body[:-1] if isinstance(self.function_def.body[-1], ast.Return) else self.function_def.body:
            FunctionNodeVisitor(assert_no_return).visit(stmt)

        if self.function_def.args.vararg is not None:
            if len(self.function_def.args.args) != 0:
                raise ctx.CompileError('Inline functions with both positional arguments and variable length arguments are not supported.')

    def __repr__(self) -> str:
        return f'InlineFuncDef({json.dumps(self.function_def.name)})'


class MacroDef:
    def __init__(self, ctx: FrozenBuildContext, params: list[ast.arg], module_name: str, function_name: str, syntactic: bool, *, marker: str | None = None):
        self.ctx = ctx
        self.params = params
        self.module_name = module_name
        self.function_name = function_name
        self.module_path = (ctx.filepath.parent / self.module_name).absolute()
        self.syntactic = syntactic
        self.marker = marker
        if not self.module_path.with_suffix(".py").exists() and not self.module_path.with_suffix(".c").exists():
            raise ctx.CompileError(f'{self.module_path} does not exist')


@dataclass
class ParameterizedProcessor:
    expr: ast.FunctionDef
    scope: Scope
    marker: str | None = None


@dataclass(frozen=True)
class BoundMethod:
    self_: Instance
    func: InlineFuncDef


@dataclass(frozen=True)
class MethodWrapper:
    func: InlineFuncDef


class ScopeType(enum.Enum):
    """
    ```
    x = 1  # MainProcessor

    class A:
        ...  # MainProcessor

    def f(): ...  # SharedFunction

    @inline
    def f(): ...  # SharedFunction

    @Processors.add
    def processor1(): ...  # SubProcessor
    ```
    """

    MainProcessor = enum.auto()
    SubProcessor = enum.auto()
    SharedFunction = enum.auto()


class GetUniqueIdentifier:
    def __init__(self):
        self.counter: typing.DefaultDict[str, int] = defaultdict(lambda: 0)

    def __call__(self, name: str):
        self.counter[name] += 1
        return name if self.counter[name] == 1 else f'{name}__{self.counter[name] - 1}'


@dataclass(frozen=True)
class Scope:
    class Names(dict[str, 'Object']):
        def __getitem__(self, k: str) -> 'Object':
            item = super().__getitem__(k)
            if isinstance(item, FuncDef):
                item.referenced = True
            return item

    @dataclass(frozen=True)
    class Module:  # doesn't have a parent
        _: dataclasses.KW_ONLY
        filepath: Path
        processor_name: str  # a module can be loaded separately for different processors
        skipped_parsing: bool

    @dataclass(frozen=True)
    class Class:  # has a parent
        _: dataclasses.KW_ONLY
        background: 'Scope'
        marker: str | None  # @_builtin
        nonlocals: set[str] = field(default_factory=set)  # nonlocal statements
        globals: set[str] = field(default_factory=set)  # global statements

    @dataclass(frozen=True)
    class ProcessorFrame:  # has a parent, can have nonlocal and global statements
        _: dataclasses.KW_ONLY
        background: 'Scope'
        processor_name: str
        asm: list[Instruction]
        nonlocals: set[str] = field(default_factory=set)   # nonlocal statements
        globals: set[str] = field(default_factory=set)  # global statements

    @dataclass(frozen=True)
    class FunctionFrame:  # has a parent, can have nonlocal and global statements
        _: dataclasses.KW_ONLY
        background: 'Scope'
        marker: str | None  # @_builtin
        function_definition: FuncDef
        nonlocals: set[str] = field(default_factory=set)  # nonlocal statements
        globals: set[str] = field(default_factory=set)  # global statements

    @dataclass(frozen=True)
    class InlineFunctionFrame:  # has a parent, can have nonlocal and global statements
        _: dataclasses.KW_ONLY
        background: 'Scope'
        nonlocals: set[str] = field(default_factory=set)  # nonlocal statements
        globals: set[str] = field(default_factory=set)  # global statements
        processor_name: str  # inline functions can be executed from different processors

    @dataclass(frozen=True)
    class MacroFrame:
        _: dataclasses.KW_ONLY
        filepath: Path
        processor_name: str

    _: dataclasses.KW_ONLY

    repr_name: str
    kind: Module | Class | ProcessorFrame | InlineFunctionFrame | FunctionFrame | MacroFrame
    local_name_suffix: str

    children: list[Scope] = field(default_factory=list)  # keeps all scopes in a tree structure to collect the generated code
    # self.children[i].kind.background == self is not always true
    break_target_stack: list[Label] = field(default_factory=list)
    continue_target_stack: list[Label] = field(default_factory=list)
    unrolled_local_stack: list[tuple[str, OperandValue]] = field(default_factory=list)
    locals_: Names = field(default_factory=Names)  # f_locals and __dict__
    labels: dict[str, Label] = field(default_factory=dict)  # M.jump and M.label
    typedef_declarations: set[str] = field(default_factory=set)  # minpiler.typedef
    constexpr_declarations: set[str] = field(default_factory=set)  # ConstExpr[T]

    def __repr__(self):
        return f'{self.kind.__class__.__name__.lower()} {json.dumps(self.repr_name)}'

    @property
    def filepath(self) -> Path:
        s = self
        while not isinstance(s.kind, Scope.Module | Scope.MacroFrame):
            s = s.kind.background
        return s.kind.filepath

    @property
    def processor(self) -> str:
        s = self
        while not isinstance(s.kind, Scope.Module | Scope.MacroFrame):
            if isinstance(s.kind, Scope.ProcessorFrame | Scope.InlineFunctionFrame):
                return s.kind.processor_name
            s = s.kind.background
        return s.kind.processor_name

    def get(self, ctx: BuildContext, key: str) -> 'Object':
        for k, v in self.unrolled_local_stack:
            if k == key:
                result = v
                break
        else:
            if not isinstance(self.kind, Scope.Module | Scope.MacroFrame) and key in self.kind.nonlocals:
                if self.kind.background is None:
                    raise ctx.CompileError(f'{self} does not have a parent scope')
                result = self.kind.background.get(ctx, key)
            elif not isinstance(self.kind, Scope.Module | Scope.MacroFrame) and key in self.kind.globals:
                parent = self
                while not isinstance(parent.kind, Scope.Module | Scope.MacroFrame):
                    parent = parent.kind.background
                result = parent.locals_[key]
            elif key in self.locals_:
                result = self.locals_[key]
            elif not isinstance(self.kind, Scope.Module | Scope.MacroFrame) and self.kind.background is not None:
                result = self.kind.background.get(ctx, key)
            else:
                raise ctx.CompileError(f'variable {key} does not exist in {self}')
        if isinstance(result, LocalName) and result.processor != self.processor and result.marker is None:
            raise ctx.CompileError(
                f'local variables cannot be accessed from a different processor: {result} is defined in the processor {result.processor} but is accessed from the processor {self.processor}.\n' +
                'To share a variable between processors, annotate it with ConstExpr[T], sync.SharedFloat, sync.SharedInt, etc.',
            )
        return result

    def set_local(self, key: str, value: Object):
        assert not (isinstance(value, Scope) and isinstance(value.kind, Scope.ProcessorFrame | Scope.InlineFunctionFrame | Scope.FunctionFrame | Scope.MacroFrame))
        self.locals_[key] = value

    def add_sub_scope(self, local_name: str | None, s: Scope):
        """local_name=None if the scope is a frame / invisible from the user"""
        self.children.append(s)
        if local_name is not None:
            self.set_local(s.repr_name, s)
        return s

    def collect_subprocessor_code(self, processor_name: str = '__main__') -> dict[str, list[Instruction]]:
        """
        This function returns the implementations of the referenced functions and defined processors.
        By not generating code for functions that were not used, the number of lines of assembly code output is reduced.
        """
        result: dict[str, list[Instruction]] = defaultdict(lambda: [])

        for v in self.locals_.values():
            if isinstance(v, FuncDef) and v.referenced:
                result[processor_name] += v.asm

        for child in self.children:
            if isinstance(child.kind, Scope.ProcessorFrame):
                assert child.kind.processor_name not in result, "Processor names must be unique"
                result[child.kind.processor_name] = child.kind.asm
                for k, v in child.collect_subprocessor_code(child.kind.processor_name).items():
                    result[k] += v
            else:
                for k, v in child.collect_subprocessor_code(processor_name).items():
                    result[k] += v

        return result

    def print_tree(self) -> str:
        import textwrap
        t = f'{self!r}(processor={self.processor}):\n'
        for c in self.children:
            t += textwrap.indent(c.print_tree(), '  ')
        return t

    def lvalue(self, ctx: BuildContext, name: str, is_shared_name: bool) -> LocalName | SharedName:
        if name in self.constexpr_declarations:
            raise ctx.CompileError(f'{name!r} is defined as both a local variable and a constexpr variable')

        def f():
            if not isinstance(self.kind, Scope.Module | Scope.MacroFrame) and (name in self.kind.nonlocals or name in self.kind.globals):
                var = self.get(ctx, name)
                if not isinstance(var, (LocalName, SharedName)):
                    raise ctx.CompileError(f'{name!r}: {var!r} is not a l-value')
                return var
            elif name in self.locals_:
                var = self.locals_[name]
                if not isinstance(var, (LocalName, SharedName)):
                    raise ctx.CompileError(f'{name!r}: {var!r} is not a l-value')
                return var
            elif is_shared_name:
                shared_var = SharedName(prefix=name)
                self.locals_[name] = shared_var
                return shared_var
            else:
                # Define a local variable with an unique name
                if self.local_name_suffix != '':
                    local_var = LocalName(f'{name}__{self.local_name_suffix}', processor=self.processor)
                elif re.match(r'^[\w\-]+\d+$', name) is not None:  # add a suffix if the name is linkname-like
                    local_var = LocalName(f'{name}__', processor=self.processor)
                else:
                    local_var = LocalName(name, processor=self.processor)
                self.locals_[name] = local_var
                return local_var

        result = f()
        if is_shared_name and not isinstance(result, SharedName):
            raise ctx.CompileError(f'{name!r} is defined as both a local variable and a shared variable')
        return result

    def __contains__(self, key: str) -> bool:
        for k, _v in self.unrolled_local_stack:
            if k == key:
                return True
        if key in self.locals_:
            return True
        if not isinstance(self.kind, Scope.Module | Scope.MacroFrame) and self.kind.background is not None:
            return self.kind.background.__contains__(key)
        return False

    def get_current_func(self) -> FuncDef | None:
        if isinstance(self.kind, Scope.FunctionFrame):
            return self.kind.function_definition
        elif not isinstance(self.kind, Scope.Module | Scope.MacroFrame):
            self.kind.background.get_current_func()
        return None


Object = PrimitiveValue | EnumValue | ReadonlyName | Tuple | LocalName | SharedName | MemorySlice | AddressOf | MemoryOf | Scope | Label | FuncDef | InlineFuncDef | MacroDef | Typename | ParameterizedProcessor | Slice | MethodWrapper | Instance | BoundMethod


def list_memory_names(instructions: list[Instruction]):
    links: set[str] = set()

    def add_link(arg: OperandValue):
        if isinstance(arg, LocalName) and arg.name is not None and re.match(r'^(cell|bank)\d+$', arg.name):
            links.add(arg.name)

    for ins in instructions:
        match ins:
            case Call(): list(map(add_link, ins.args))
            case Jump(): list(map(add_link, ins.args))
            case LongJump(): add_link(ins.arg)
            case Label(): pass
            case _: raise LogicError(ins)
    return links


def allocate_memory_addresses(instructions: list[Instruction], reserved_memory_names: set[str]):
    """
    Allocate memory addresses for SharedName and Slice, and replace AddressOf and MemoryOf with PrimitiveValue.
    """
    allocated_before: tuple[int, int] | None = None  # (bank_id, address)

    def malloc(size: int) -> tuple[str, int]:
        """
        Allocates consecutive memory addresses of size `size` and returns the starting address.
        """
        nonlocal allocated_before

        assert 1 <= size <= 512
        if allocated_before is not None and size <= 512 - allocated_before[1]:
            start = allocated_before[1]
            allocated_before = (allocated_before[0], allocated_before[1] + size)
            return f'bank{allocated_before[0]}', start

        for i in itertools.count((0 if allocated_before is None else allocated_before[0]) + 1):
            if f'bank{i}' not in reserved_memory_names:
                allocated_before = (i, size)
                return f'bank{i}', 0

        raise LogicError

    def process_argument(arg: OperandValue) -> OperandValue:
        match arg:
            case AddressOf(name=(SharedName() | MemorySlice()) as n) | MemoryOf(name=(SharedName() | MemorySlice()) as n):
                assert (n.memory is None and n.index is None) or (n.memory is not None and n.index is not None)
                if n.memory is None:
                    memory_name, memory_address = malloc(n.size if isinstance(n, MemorySlice) else 1)
                    n.memory = LocalName(memory_name, processor=arg.processor)
                    n.index = memory_address
                if isinstance(arg, AddressOf):
                    return PrimitiveValue(arg.ctx, n.index)
                else:
                    return n.memory
            case _:
                return arg

    for ins in instructions:
        match ins:
            case Call(): list(map(process_argument, ins.args))
            case Jump(): list(map(process_argument, ins.args))
            case LongJump(): process_argument(ins.arg)
            case Label(): pass
            case _: raise LogicError(ins)

    for ins in instructions:
        match ins:
            case Call(): ins.args = list(map(process_argument, ins.args))
            case Jump(): ins.args = list(map(process_argument, ins.args))
            case LongJump(): pass
            case Label(): pass
            case _: raise LogicError(ins)


class Dump:
    '''Converts instructions to a string. The result can be got by __str__().'''

    def __init__(self, instructions: list[Instruction], use_emulator_instructions: bool, processor_name: str) -> None:
        # Filter out and index labels
        filtered: list[Instruction] = []
        for ins in instructions:
            if isinstance(ins, Label):
                ins.line = len(filtered)
            elif not use_emulator_instructions and isinstance(ins, Call) and ins.op.startswith('emulator.'):
                continue
            else:
                filtered.append(ins)
        self.instructions = filtered
        del filtered

        self.result: list[str] = []
        self.name_suffix_count = defaultdict(int)

        for ins in self.instructions:
            match ins:
                case Call(): self.result.append(' '.join([ins.op, *map(self.__dump_argument, ins.args)]))
                case Jump(): self.result.append(' '.join(['jump', str(self.__resolve_jump(ins.label)), ins.op, *map(self.__dump_argument, ins.args)]))
                case LongJump(): self.result.append(' '.join(['set', '@counter', self.__dump_argument(ins.arg)]))
                case _: raise LogicError(ins)

        num_lines = len(str(self).splitlines())
        if num_lines > emulator.LExecutor.max_instructions:
            logging.warning(f'The number of instructions in the processor {processor_name} ({num_lines}) exceeds max_instructions ({emulator.LExecutor.max_instructions!r})')

    def __str__(self):
        return '\n'.join(self.result) + '\n'

    def __resolve_jump(self, label: Label) -> int:
        if label.line is None:
            raise LogicError(f'a jump call pointing to an undefined label')
        if label.line >= len(self.instructions):  # Jump to the top of the program if the label is on the bottom of the program
            return 0
        return label.line

    def __dump_argument(self, arg: OperandValue) -> str:
        match arg:
            case PrimitiveValue():
                return str(arg)
            case LocalName() | ReadonlyName():
                name = arg.name if isinstance(arg, ReadonlyName) else arg
                if name.name is None:
                    prefix = re.sub(r'[^\w]', '_', name.prefix)
                    name.name = f'_{prefix}__{self.name_suffix_count[prefix]}'
                    self.name_suffix_count[prefix] += 1
                return name.name
            case Label():
                return str(self.__resolve_jump(arg))
            case _:  # AddressOf | MemoryOf
                raise LogicError(f'Bad argument value {arg!r}')
