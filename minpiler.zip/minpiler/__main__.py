from minpiler import cmdline

cmdline.run()
